package br.livetouch.livecom.itaubba;

import android.content.res.Configuration;

import br.livetouch.db.DatabaseHelper;
import br.livetouch.livecom.Config;
import br.livetouch.livecom.LivecomApplication;
import br.livetouch.livecom.itaubba.utils.LocaleUtils;
import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 18/07/2017.
 */

public class ItaubbaAplication extends LivecomApplication {

    private ItaubbaDataBaseHelper dataBaseHelper;

    @Override
    public void onCreate() {
        super.onCreate();

        // seta idioma para o mesmo do device ou escolhido pelo usuario.
        Configuration configuration = getBaseContext().getResources().getConfiguration();
        LocaleUtils.updateConfig(this, configuration);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        LocaleUtils.updateConfig(this, newConfig);
    }

    @Override
    public String getGCMProjectNumber() {
        return "";
    }

    @Override
    public String getPushProject() {
        return "";
    }

    @Override
    public String getTag() {
        return "itaubba";
    }

    @Override
    public int getLogoAlert() {
        return R.mipmap.ic_launcher;
    }

    @Override
    public int getBuildConfig_VERSION_CODE() {
        return BuildConfig.VERSION_CODE;
    }

    @Override
    public String getBuildConfig_VERSION_NAME() {
        return BuildConfig.VERSION_NAME;
    }

    @Override
    public String getBuildConfig_HASH_COMMIT() {
        return "";
    }

    @Override
    public String getGoogleAnalyticsTrackingId() {
        if (StringUtils.equalsIgnoreCase(BuildConfig.BUILD_TYPE, "debug")){
            return GoogleAnalytics.GA_KEY_DEBUG;
        } else {
            return GoogleAnalytics.GA_KEY;
        }
    }

    @Override
    public String getCrashlyticsKey() {
        return CRASHLYTICS_LIVETOUCH_KEY;
    }

    @Override
    public String getBuildFlavor() {
        return BuildConfig.FLAVOR;
    }

    @Override
    public String getPrefsKey() {
        return super.getPrefsKey();
    }

    @Override
    public String getBuildType() {
        return BuildConfig.BUILD_TYPE;
    }

    @Override
    public Config getConfig() {
        return new ItaubbaConfig();
    }

    @Override
    public DatabaseHelper getDatabaseHelper() {
        if (dataBaseHelper != null){
            return dataBaseHelper;
        } else {
            return dataBaseHelper = new ItaubbaDataBaseHelper();
        }
    }
}
