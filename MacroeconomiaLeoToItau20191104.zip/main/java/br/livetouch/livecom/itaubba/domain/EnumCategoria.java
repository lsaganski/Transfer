package br.livetouch.livecom.itaubba.domain;

public enum EnumCategoria {
    VIDEO(2), PODCAST(109);

    public int getCod() {
        return cod;
    }

    int cod;

    EnumCategoria(int cod) {
        this.cod = cod;
    }
}
