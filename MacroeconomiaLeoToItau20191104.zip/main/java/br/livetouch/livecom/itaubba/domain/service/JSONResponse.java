package br.livetouch.livecom.itaubba.domain.service;

import java.util.List;

import br.livetouch.exception.DomainException;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.domain.Badges;
import br.livetouch.livecom.domain.Notifications;
import br.livetouch.livecom.domain.User;
import br.livetouch.livecom.domain.exceptions.ForaHorarioException;
import br.livetouch.livecom.domain.exceptions.LogoutException;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.Post;
import br.livetouch.utils.JSONUtils;
import br.livetouch.utils.LogUtil;
import br.livetouch.utils.StringUtils;

/**
 * Created by livetouch on 09/08/17.
 */

public class JSONResponse<T>{


    public String json;
    public String status;
    public String mensagem;
    public String errorCode;
    public Post post;
    public Post result;
    public User user;
    public Notifications notifications;
    public Badges badges;
    public List<Categoria> categorias;
    public List<Arquivo> listFiles;
    public List<Post> posts;

    public JSONResponse() {
    }

    public boolean isOk() {
        return "OK".equalsIgnoreCase(this.status);
    }

    public static JSONResponse create(String json) throws DomainException {
        if(StringUtils.isNotEmpty(json)) {
            try {
                JSONResponse e = (JSONResponse) JSONUtils.fromJSON(json, JSONResponse.class);
                e.json = json;
                e.checkError();
                return e;
            } catch (Exception var2) {
                LogUtil.logError(var2.getMessage(), var2);
                throw var2;
            }
        } else {
            throw new DomainException("Ocorreu um erro na requisição");
        }
    }

    public void checkError() throws DomainException {
        if(this.errorCode != null) {
            if("logout".equals(this.errorCode) || "senha".equals(this.errorCode)) {
                User.setSenhaPrefs((String)null);
                throw new LogoutException(this.mensagem);
            }

            if("horario".equals(this.errorCode)) {
                throw new ForaHorarioException(this.mensagem);
            }
        }

        if(!this.isOk()) {
            LogUtil.logError("JSON INVALIDO sem status/mensagen: " + this.json);
            throw new DomainException(StringUtils.isNotEmpty(this.mensagem)?this.mensagem:"Retorno inválido do servidor.");
        }
    }

    public String toString() {
        return this.json;
    }


}
