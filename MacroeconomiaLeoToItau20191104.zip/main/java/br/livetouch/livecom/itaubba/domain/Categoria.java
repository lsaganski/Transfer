package br.livetouch.livecom.itaubba.domain;

import android.content.Context;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.livetouch.db.Ignore;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.utils.ListUtils;

/*
 * Created by empresa on 29/08/2017.
 */

public class Categoria extends br.livetouch.livecom.domain.Categoria implements Serializable {

    public Long idPai;

    public Categoria() {}

    public Categoria(String nome) {
        super(nome);
    }

    public Categoria(long id) {
        super(id);
    }

    @Ignore
    @SerializedName("subcategorias")
    public List<SubCategoria> subCategorias = new ArrayList<>();

    @Ignore
    public Categoria categoriaPai;

    public boolean hasSubCategorias(){
        return ListUtils.isNotEmpty(subCategorias);
    }

    public static List<Object> addCategoriasToObjectList(List<Categoria> categorias) {
        List<Object> objectList = new ArrayList<>();
        if (ListUtils.isNotEmpty(categorias)){
            for (Categoria categoria : categorias){

                // Add Categoria
                objectList.add(categoria);

                if (categoria.hasSubCategorias()) {
                    // Add SubCategorias
                    objectList.addAll(categoria.subCategorias);
                }

            }
        }
        return objectList;
    }

    public static List<Object> addAuditoriasToObjectList(Context context, List<SubCategoria> subCategorias) {
        List<Object> objectList = new ArrayList<>();
        if (ListUtils.isNotEmpty(subCategorias)) {

            // add item "todas"
            SubCategoria sub = new SubCategoria(context.getString(R.string.todas));
            objectList.add(0, sub);

            for (int i = 0; i < subCategorias.size(); i++) {
                SubCategoria subCategoria = subCategorias.get(i);

                // Add SubCategoria Editoria
                subCategoria.isEditoria = true;
                objectList.add(i + 1, subCategoria);
            }
        }
        return objectList;
    }
}
