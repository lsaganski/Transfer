package br.livetouch.livecom.itaubba.domain;

import java.io.Serializable;

/*
 * Created by empresa on 12/09/2017.
 */

public class PostInfo implements Serializable {
    public static final String KEY = PostInfo.class.getSimpleName();

    public static final int PAGE_SIZE = 10;
    public static final String POST_ID = "postId";
    public static final String TYPE_ADAPTER = "TYPE_ADAPTER";
    public static final int TYPE_DESTAQUE_ADAPTER = 100;

    private Categoria categoria;
    private SubCategoria subCategoria;

    private String title;
    private String query;

    private boolean isMidias;
    private boolean isDestaque;
    private boolean isMenuFavorito;
    private boolean isMenuCategorias;
    private boolean isMenuHome;

    private Long excludePostId;

    private int maxRows;

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public SubCategoria getSubCategoria() {
        return subCategoria;
    }

    public void setSubCategoria(SubCategoria subCategoria) {
        this.subCategoria = subCategoria;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isMenuFavorito() {
        return isMenuFavorito;
    }

    public void setMenuFavorito(boolean menuFavorito) {
        isMenuFavorito = menuFavorito;
    }

    public boolean isMenuHome() {
        return isMenuHome;
    }

    public void setMenuHome(boolean menuHome) {
        isMenuHome = menuHome;
    }

    public boolean isMenuCategorias() {
        return isMenuCategorias;
    }

    public void setMenuCategorias(boolean menuCategorias) {
        isMenuCategorias = menuCategorias;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public boolean isDestaque() {
        return isDestaque;
    }

    public void setDestaque(boolean destaque) {
        isDestaque = destaque;
    }

    public Long getExcludePostId() {
        return excludePostId;
    }

    public void setExcludePostId(Long excludePostId) {
        this.excludePostId = excludePostId;
    }

    public int getMaxRows() {
        return maxRows;
    }

    public void setMaxRows(int maxRows) {
        this.maxRows = maxRows;
    }

    public void setMidias(boolean midias) {
        isMidias = midias;
    }

    public boolean isMidias() {
        return isMidias;
    }
}
