package br.livetouch.livecom.itaubba.domain;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.livetouch.utils.ListUtils;


public class SubCategoria implements Serializable {
    public static final String KEY = SubCategoria.class.getSimpleName();

    public Long id;
    public String nome;
    public boolean menu;
    public boolean isEditoria;

    public Categoria categoriaPai;

    public Categoria categoria;

    @SerializedName("subcategorias")
    public List<SubCategoria> editorias = new ArrayList<>();

    public SubCategoria(String nome) {
        this.nome = nome;
    }

    public boolean hasEditoria() {
        return ListUtils.isNotEmpty(editorias);
    }
}
