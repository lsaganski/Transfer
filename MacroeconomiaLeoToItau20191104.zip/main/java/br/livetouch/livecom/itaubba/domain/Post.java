package br.livetouch.livecom.itaubba.domain;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import br.livetouch.db.Entity;
import br.livetouch.db.Ignore;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.domain.Destaque;
import br.livetouch.utils.DateUtils;
import br.livetouch.utils.ListUtils;
import br.livetouch.utils.StringUtils;

/*
 * Created by livetouch on 09/08/17.
 */

public class Post extends Entity implements Serializable {
    public static final String KEY = Post.class.getSimpleName();
    private static final long serialVersionUID = 1L;

    public Long idCategoria;
    public Long id;
    public String dataPubStr;
    public String dataStr;
    public Long timestamp;
    public String titulo;
    public String mensagem;
    public String categoriaNome;
    private String resumo;
    public boolean lido;
    public Long currentTimestamp;

    @Ignore
    public int adapterType;

    @SerializedName("checkDestaque")
    public String isPostDestaque;

    @Ignore
    public Long usuarioId;

    @Ignore
    public Categoria categoria;

    public String usuarioLogin;
    public String usuarioNome;

    public boolean isfavorito;

    @Ignore
    @SerializedName("webview")
    public boolean isWebview;

    @Ignore
    @SerializedName("html")
    public boolean isHtml;

    public String urlVideo;
    public String urlSite;

    @Ignore
    public Destaque destaque;

    @Ignore
    public List<Arquivo> arquivos = new ArrayList<>();

    // DADOS LOCAIS
    public String dateddMMYYYY;
    public String timeHHmm;
    public long numeroDeImagens;
    public int indimg1;
    public int indimg2;
    public String arquivoIds;
    public Long timestampPub;
    public int diaDoMes;
    public int mes;
    public int ano;


    public String getResumo() {
        return resumo != null ? resumo : "";
    }

    @Override
    public String toString() {
        return "Post [id=" + id + ", titulo=" + titulo + "]";
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public void contaImagens() {
        numeroDeImagens = (long) 0;
        indimg1 = (int) -1;
        indimg2 = (int) -1;
        if (ListUtils.isNotEmpty(arquivos)) {
            for (int j = 0; j < arquivos.size(); j++) {
                Arquivo a = arquivos.get(j);
                if (a.isImage()) {
                    numeroDeImagens++;
                    if (indimg1 < 0) {
                        indimg1 = (int) j;
                    } else if (indimg2 < 0) {
                        indimg2 = (int) j;
                    }
                }
            }
        }
    }

    public String getCategoriaNome() {
        if (StringUtils.isNotEmpty(categoriaNome)) {
            return categoriaNome;
        } else if (categoria != null) {
            return categoriaNome = categoria.getNome();
        }
        return "";
    }

    public String getCategoriaPaiName() {
        if (categoria == null){
            return "";
        }
        return getLastCategoriaPaiName(categoria.nome, categoria.categoriaPai);
    }

    private String getLastCategoriaPaiName(String name, Categoria categoriaPai) {
        if (categoriaPai == null || categoriaPai.nome == null){
            return name;
        }
        return getLastCategoriaPaiName(categoriaPai.nome, categoriaPai.categoriaPai);
    }

    public void gerarDadosLocais(){

        // Dados gerados localmente
        Long mTimestamp = this.timestampPub != null ? this.timestampPub : this.timestamp;
        if(mTimestamp != null) {
            java.util.Date dateandTime = new java.util.Date(mTimestamp);
            this.timeHHmm = DateUtils.toString(dateandTime, "HH:mm", Locale.getDefault());
            this.dateddMMYYYY = DateUtils.toString(dateandTime, "dd/MM/yyyy", Locale.getDefault());
            this.diaDoMes = Integer.valueOf(DateUtils.toString(dateandTime, "dd", Locale.getDefault()));
            this.mes = Integer.valueOf(DateUtils.toString(dateandTime, "MM", Locale.getDefault()));
            this.ano = Integer.valueOf(DateUtils.toString(dateandTime, "yyyy", Locale.getDefault()));
        }

        this.contaImagens();

        // fix temporario para nome dos arquivos no post
        if (ListUtils.isNotEmpty(arquivos)) {
            for (Arquivo a : arquivos) {
                a.nome = a.file;
            }
        }
    }

    @Override
    public long save() {
        return super.save();
    }

    // Post destaque
    public boolean isPostDestaque() {
        return "1".equals(isPostDestaque);
    }

    public void updatePostInList(List<Post> posts) {
        if (ListUtils.isNotEmpty(posts)) {
            for (int i = 0; i < posts.size(); i++) {
                if (posts.get(i).id.longValue() == this.id.longValue()) {
                    posts.set(i, this);
                }
            }
        }
    }

    public int getPositionFromList(List<Post> posts) {
        if (ListUtils.isNotEmpty(posts)) {
            int indexOf = posts.indexOf(this);
            return indexOf < 0 ? 0 : indexOf;
        }
        return 0;
    }

    // documentos Anexados
    public List<Arquivo> getArquivosDoc(){
        List<Arquivo> mArquivos = new ArrayList<>();
        if (ListUtils.isNotEmpty(arquivos)) {
            for (Arquivo a : arquivos) {
                if (a.isPdf() || a.isGoogleDocument()) {
                    mArquivos.add(a);
                }
            }
        }
        return mArquivos;
    }

    // Videos Anexados
    public List<Arquivo> getArquivosVideos(){
        List<Arquivo> mVideos = new ArrayList<>();
        if (ListUtils.isNotEmpty(arquivos)) {
            for (Arquivo a : arquivos) {
                if (a.isArquivoVideo()) {
                    mVideos.add(a);
                }
            }
        }
        return mVideos;
    }

    // Imagens Anexadas
    public List<Arquivo> getArquivosImagens(){
        List<Arquivo> mImagens = new ArrayList<>();
        if (ListUtils.isNotEmpty(arquivos)) {
            for (Arquivo a : arquivos) {
                if (a.isImage()) {
                    mImagens.add(a);
                }
            }
        }
        return mImagens;
    }

    // video anexado
    public boolean hasVideo() {
        if (ListUtils.isNotEmpty(arquivos)){
            for (Arquivo a : arquivos){
                if (a.isVideo()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isPodcast() {
        return categoria != null && categoria.getId() == (EnumCategoria.PODCAST.cod);
    }

    // imagen anexada
    public boolean hasImage() {
        return numeroDeImagens > 0;
    }

    public String getThumbVideo(){
        if (ListUtils.isNotEmpty(arquivos)){
            for (Arquivo a : arquivos){
                if (a.isVideo() && StringUtils.isNotEmpty(a.urlThumb)){
                    return a.urlThumb;
                }
            }
        }
        return "";
    }

    public String getUrlPodCast() {
        if (destaque != null && StringUtils.isNotEmpty(destaque.title))
            return destaque.title;
        return null;
    }

    public String getThumb(){
        if (ListUtils.isNotEmpty(arquivos) && hasImage()){
            return arquivos.get(indimg1).url;
        }
        return "";
    }

    public Arquivo getFirstVideo() {
        for (Arquivo a: this.arquivos){
            if (a.isVideo()){
                return a;
            }
        }
        return null;
    }
}
