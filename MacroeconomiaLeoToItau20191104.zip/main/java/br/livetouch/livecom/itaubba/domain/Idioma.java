package br.livetouch.livecom.itaubba.domain;

import java.io.Serializable;

/**
 * Created by livetouch on 02/08/17.
 */

public class Idioma implements Serializable{

    public Long id;
    public String nome;
    public String code;

    public Categoria categoria;
    public Idioma idioma;
}
