package br.livetouch.livecom.itaubba.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.livetouch.livecom.domain.*;

/**
 * Created by livetouch on 09/08/17.
 */

public class Mural extends br.livetouch.livecom.domain.Mural implements Serializable {

    public List<Post> posts = new ArrayList();
    public Badges badges;

    public Mural() {
    }

}
