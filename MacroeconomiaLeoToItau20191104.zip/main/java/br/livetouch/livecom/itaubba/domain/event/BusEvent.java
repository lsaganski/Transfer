package br.livetouch.livecom.itaubba.domain.event;

import java.io.Serializable;

import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.Post;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.domain.SubCategoria;

/*
 * Created by livetouch on 03/08/17.
 */

public class BusEvent {

    public BusEvent() {
    }

    public static class StartTutorialEvent implements Serializable {
        public StartTutorialEvent() {
        }
    }

    public static class UpdateLanguageEvent implements Serializable {
        public UpdateLanguageEvent() {
        }
    }

    public static class FiltroPostEvent implements Serializable {
        public Categoria categoria;
        public SubCategoria subCategoria;
        public PostInfo postInfo;

        public FiltroPostEvent(PostInfo postInfo) {
            this.postInfo = postInfo;
        }

        public FiltroPostEvent(Categoria categoria) {
            this.categoria = categoria;
        }

        public FiltroPostEvent(SubCategoria subCategoria) {
            this.subCategoria = subCategoria;
        }
    }

    public static class PostUpdateEvent implements Serializable {
        public Post post;

        public PostUpdateEvent(Post post) {
            this.post = post;
        }
    }

    public static class trackGAEvent implements Serializable {
        public boolean isHomePage;
        public boolean isResultFragment;
        public boolean isBookmarkFragment;
        public boolean isCategoryFragment;
        public trackGAEvent() {}
    }

    public static class ActivityShareClicked {
        public String appName;

        public ActivityShareClicked(String appName) {
            this.appName = appName;
        }
    }
}
