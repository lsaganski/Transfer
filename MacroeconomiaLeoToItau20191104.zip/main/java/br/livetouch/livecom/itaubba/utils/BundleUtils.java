package br.livetouch.livecom.itaubba.utils;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.Pair;

import java.io.Serializable;
import java.util.ArrayList;

import br.livetouch.utils.LogUtil;

public class BundleUtils {

    @SafeVarargs
    public static void fillBundle(Bundle bundle, Pair<String, Object>... args) {
        for (Pair<String, Object> pair : args){
            fillBundle(bundle, pair);
        }
    }

    private static void fillBundle(Bundle bundle, ArrayList<Pair<String, Object>> args) {
        for (Pair<String, Object> pair : args){
            fillBundle(bundle, pair);
        }
    }

    public static void fillBundle(Bundle bundle, Pair<String, Object> arg) {
        if (bundle == null){
            return;
        }
        try {
            Object value = arg.second;
            if (value == null) {
                bundle.putSerializable(arg.first, null);
            } else if (value instanceof Integer) {
                bundle.putInt(arg.first, (Integer) value);
            } else if (value instanceof Long) {
                bundle.putLong(arg.first, (Long) value);
            } else if (value instanceof String) {
                bundle.putString(arg.first, (String) value);
            } else if (value instanceof CharSequence) {
                bundle.putCharSequence(arg.first, (CharSequence) value);
            } else if (value instanceof Float) {
                bundle.putFloat(arg.first, (Float) value);
            } else if (value instanceof Double) {
                bundle.putDouble(arg.first, (Double) value);
            } else if (value instanceof Serializable) {
                bundle.putSerializable(arg.first, (Serializable) value);
            } else if (value instanceof Parcelable) {
                bundle.putParcelable(arg.first, (Parcelable) value);
            }
        } catch (Exception e) {
            LogUtil.logError(e.getMessage(), e);
        }
    }
}
