package br.livetouch.livecom.itaubba.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Bundle;

import java.util.List;

import br.livetouch.activity.BaseActivity;
import br.livetouch.livecom.activity.VideoViewActivity;
import br.livetouch.livecom.activity.WebViewActivity;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.activity.PdfActivity;
import br.livetouch.livecom.utils.AlertUtils;
import br.livetouch.utils.NetworkUtils;

/**
 * Created by Avell 1513 on 03/01/2017.
 */

public class LivecomUtils {

    public static boolean isMyApplicationTaskOpen(Context context) {
        String packageName = context.getPackageName();

        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> recentTasks = activityManager.getRunningTasks(2147483647);
        if (recentTasks != null && recentTasks.size() > 0) {
            for (ActivityManager.RunningTaskInfo runningTaskInfo : recentTasks) {
                String pack = runningTaskInfo.baseActivity.getPackageName();
                if (pack.equals(packageName)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static void tryOpenAnexoOnApp(BaseActivity activity, Arquivo arquivo) {
        boolean isOffLine = !NetworkUtils.isNetworkAvailable(activity);
        if (isOffLine){
            showAlertOffLine(activity);
            return;
        }

        boolean isVideo = arquivo != null && arquivo.isVideo();
        boolean isDoc = arquivo != null && arquivo.isGoogleDocument();
        boolean isPdf = arquivo != null && arquivo.isPdf();

        if (isPdf) {
            tryOpenPdf(activity, arquivo);
        } else if (isDoc) {
            tryOpenDoc(activity, arquivo);
        }else if(isVideo){
            tryOpenVideo(activity, arquivo);
        }
    }

    private static void tryOpenPdf(BaseActivity activity, Arquivo arquivo) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Arquivo.TAG, arquivo);
        activity.show(PdfActivity.class, bundle);
    }

    private static void tryOpenDoc(BaseActivity activity, Arquivo arquivo) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Arquivo.TAG, arquivo);
        activity.show(WebViewActivity.class, bundle);
    }

    private static void tryOpenVideo(BaseActivity activity, Arquivo arquivo) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(Arquivo.TAG, arquivo);
        activity.show(VideoViewActivity.class, bundle);
    }

    private static void showAlertOffLine(final Activity context) {
        String msg = context.getString(R.string.msg_erro_rede);
        AlertUtils.alertNoCancel(context, msg, null);
    }
}
