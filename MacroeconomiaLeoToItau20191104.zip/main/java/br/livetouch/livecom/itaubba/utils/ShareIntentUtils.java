package br.livetouch.livecom.itaubba.utils;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import br.livetouch.exception.DomainException;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.activity.BaseActivity;
import br.livetouch.livecom.itaubba.activitychooser.MaterialActivityChooserBuilder;

/*
 * Created by empresa on 25/10/2017.
 */

public class ShareIntentUtils {

    private BaseActivity activity;

    private static String title;
    private static String text;
    private static Uri uri;

    private static final String TEXT_PLAIN_TYPE = "text/plain";
    private static final String MESSAGE_TYPE = "message/rfc822";
    private static final String URI_STREAM = "application/pdf";

    private IntentCallBack intentCallBack;

    public ShareIntentUtils setIntentCallBack(IntentCallBack intentCallBack) {
        this.intentCallBack = intentCallBack;
        return this;
    }

    private ShareIntentUtils(BaseActivity activity) {
        this.activity = activity;
    }

    public interface IntentCallBack {
        void OnError(String message);
    }

    public static ShareIntentUtils with(BaseActivity activity) {
        return new ShareIntentUtils(activity);
    }

    public void share(String text, String url) {
        ShareIntentUtils.title = text;
        ShareIntentUtils.text = text + " " + url;

        // mostra bottom sheet
        showChooser(activity);
    }

    public void share(String text, Uri uri) {
        ShareIntentUtils.title = text;
        ShareIntentUtils.uri = uri;

        // mostra bottom sheet
        showChooserToFile(activity);
    }

    public void openPodcastIntent(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setPackage(getPackageFromUrl(url));
            activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            if (intentCallBack != null)
                intentCallBack.OnError(e.getMessage());
        }
    }

    private String getPackageFromUrl(String url) throws DomainException {
        try {
            List<AppParams> podcastApps = getPodcastApps();
            for (AppParams appParams : podcastApps) {
                if (url.contains(appParams.urlString)) {
                    Intent intentForPackage = activity.getPackageManager().getLaunchIntentForPackage(appParams.packageString);
                    if (intentForPackage != null)
                        return appParams.packageString;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        throw new DomainException(activity.getString(R.string.msg_error_app_podcast));

    }

    private static void showChooser(BaseActivity activity) {
        new MaterialActivityChooserBuilder(activity)
                .withIntent(getDefaultShareIntent())
                .withSecondaryIntent(getSecondaryShareIntent(), getPackagesToShare())
                .removePackages(getPackagesToDelete())
                .withTitle(activity.getString(R.string.share_title))
                .show();
    }

    private static void showChooserToFile(BaseActivity activity) {
        new MaterialActivityChooserBuilder(activity)
                .withIntent(getDefaultShareIntent())
                .withSecondaryIntent(getFileShareIntent(), getPackagesToShare())
                .removePackages(getPackagesToDelete())
                .withTitle(activity.getString(R.string.share_title))
                .show();
    }

    @NonNull
    private static Intent getDefaultShareIntent() {
        Intent shareTextIntent = new Intent(Intent.ACTION_SEND);
        shareTextIntent.setType(TEXT_PLAIN_TYPE);
        shareTextIntent.putExtra(Intent.EXTRA_TEXT, text);
        shareTextIntent.putExtra(Intent.EXTRA_SUBJECT, title);
        shareTextIntent.putExtra(Intent.EXTRA_TITLE, title);
        return shareTextIntent;
    }

    @NonNull
    private static Intent getSecondaryShareIntent() {
        Intent shareTextIntent = new Intent(Intent.ACTION_SEND);
        shareTextIntent.setType(MESSAGE_TYPE);
        shareTextIntent.putExtra(Intent.EXTRA_TEXT, text);
        shareTextIntent.putExtra(Intent.EXTRA_SUBJECT, title);
        shareTextIntent.putExtra(Intent.EXTRA_TITLE, title);
        return shareTextIntent;
    }

    @NonNull
    private static Intent getFileShareIntent() {
        Intent shareTextIntent = new Intent(Intent.ACTION_SEND);
        shareTextIntent.setType(URI_STREAM);
        shareTextIntent.putExtra(Intent.EXTRA_STREAM, uri);
        shareTextIntent.putExtra(Intent.EXTRA_SUBJECT, title);
        shareTextIntent.putExtra(Intent.EXTRA_TITLE, title);
        return shareTextIntent;
    }

    private static String[] getPackagesToShare() {
        List<String> packages = new ArrayList<>();
        packages.add("com.google.android.gm");
        packages.add("com.microsoft.office.outlook");
        packages.add("br.livetouch.livecom.livetouch");
        packages.add("com.google.android.email");
        packages.add("com.facebook.katana");
        packages.add("com.whatsapp");
        packages.add("mms");
        packages.add("android.email");

        return packages.toArray(new String[0]);
    }

    private static String[] getPackagesToDelete() {
        List<String> packages = new ArrayList<>();
        packages.add("com.facebook.orca");
        packages.add("com.facebook.mlite");
        packages.add("com.samsung.android.sconnect");
        packages.add("com.sec.chaton");
        packages.add("com.twitter.android");
        packages.add("com.twitter.android.lite");
        packages.add("com.google.android.talk");
        return packages.toArray(new String[0]);
    }

    private List<AppParams> getPodcastApps() {
        List<AppParams> params = new ArrayList<>();
        params.add(new AppParams("com.spotify.music", "open.spotify.com"));
        params.add(new AppParams("com.soundcloud.android", "soundcloud.com"));
        params.add(new AppParams("com.android.chrome", "open.spotify.com"));
        params.add(new AppParams("com.android.chrome", "soundcloud.com"));
        return params;
    }

    private class AppParams {

        String packageString;
        String urlString;

        AppParams(String packageString, String urlString) {
            this.packageString = packageString;
            this.urlString = urlString;
        }
    }

    /*public void onClickCompartilhar(@NonNull Post post) {
        String textPost = post.titulo;
        String linkPost = textPost + " - " + "https://macroeconomiahomolog.livetouchdev.com.br/pages/post.htm?id=" + post.id;

        Intent emailIntent = new Intent();
        emailIntent.setAction(Intent.ACTION_SEND);
        emailIntent.putExtra(Intent.EXTRA_TEXT, linkPost);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, textPost);
        emailIntent.setType("message/rfc822");

        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");

        Intent openInChooser = Intent.createChooser(emailIntent, getContext().getString(R.string.share_title));

        PackageManager pm = getPackageManager();
        List<ResolveInfo> resInfo = pm.queryIntentActivities(sendIntent, 0);
        List<LabeledIntent> intentList = new ArrayList<>();
        for (int i = 0; i < resInfo.size(); i++) {
            ResolveInfo info = resInfo.get(i);
            String packageName = info.activityInfo.packageName;
            if (packageName.contains("android.email")) {
                emailIntent.setPackage(packageName);
            } else if (packageName.contains("livecom") || packageName.contains("twitter") || packageName.contains("facebook") || packageName.contains("whatsapp") || packageName.contains("mms") || packageName.contains("android.gm")) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(packageName, info.activityInfo.name));
                intent.setPackage(packageName);
                intent.setAction(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_TEXT, linkPost);
                intent.putExtra(Intent.EXTRA_SUBJECT, textPost);
                String type = packageName.contains("android.gm") ? "message/rfc822" : "text/plain";
                intent.setType(type);
                intentList.add(new LabeledIntent(intent, packageName, info.loadLabel(pm), info.icon));
            }
        }

        // convert intentList to array
        LabeledIntent[] extraIntents = intentList.toArray(new LabeledIntent[intentList.size()]);
        openInChooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extraIntents);

        startActivityForResult(openInChooser, Itaubba.SHARE_CODE);


//            Intent launchIntent = null;
//
//            if (url.contains("open.spotify.com"))
//                launchIntent = activity.getPackageManager().getLaunchIntentForPackage("com.spotify.music");
//            else if (url.contains("soundcloud.com"))
//                launchIntent = activity.getPackageManager().getLaunchIntentForPackage("com.soundcloud.android");
//
//            if (launchIntent == null) {
//                if (intentCallBack != null)
//                    intentCallBack.OnError(activity.getString(R.string.msg_error_app_podcast));
//                return;
//            }
//
//            Uri uri = Uri.parse(url);
//            launchIntent.setAction(Intent.ACTION_VIEW);
//            launchIntent.setDataAndType(uri, activity.getContentResolver().getType(uri));
//            activity.startActivity(launchIntent);


    }*/
}
