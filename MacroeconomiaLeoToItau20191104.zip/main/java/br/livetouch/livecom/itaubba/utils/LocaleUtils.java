package br.livetouch.livecom.itaubba.utils;

import android.app.Application;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.view.ContextThemeWrapper;

import java.util.Locale;

import br.livetouch.utils.LogUtil;
import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 21/07/2017.
 */

public class LocaleUtils {

    public static void updateConfig(ContextThemeWrapper wrapper) {
        Locale locale = getDefaultLocale();
        if (locale != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            Configuration configuration = new Configuration();
            configuration.setLocale(locale);
            wrapper.applyOverrideConfiguration(configuration);
        }
    }

    public static void updateConfig(Application app, Configuration configuration) {
        Locale locale = getDefaultLocale();
        if (locale != null && Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1) {
            //Wrapping the configuration to avoid Activity endless loop
            Configuration config = new Configuration(configuration);
            // We must use the now-deprecated config.locale and res.updateConfiguration here,
            // because the replacements aren't available till API level 24 and 17 respectively.
            config.locale = locale;
            Resources res = app.getBaseContext().getResources();
            res.updateConfiguration(config, res.getDisplayMetrics());
        }
    }

    public static void setPrefsLanguage(String language) {
        LogUtil.log("save idioma prefs : " + language);

        // salvo idioma nas prefs
        PrefsUtil.setUserLanguage(language);

        //seto Locale com idioma salvo
        saveLocaleByLanguage(language);
    }

    private static Locale getDefaultLocale() {
        String defaultLanguage = getDefaultLanguage();
        try {
            if (StringUtils.isNotEmpty(defaultLanguage)) {
                return saveLocaleByLanguage(defaultLanguage);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // se usuario nao selecionou idioma entao pego o mesmo do device (portugues || ingles)
    public static String getDefaultLanguage() {

        //Busco idioma nas Prefs
        String userLanguage = PrefsUtil.getUserLanguage();
        if (StringUtils.isNotEmpty(userLanguage)){
            return userLanguage;
        } else {

            //Busco idioma no Device
            Locale locale = Locale.getDefault();
            String language = locale.getLanguage();
            String country = locale.getCountry();
            return language.toLowerCase() + "-" + country.toLowerCase();
        }
    }

    // tem que passar 'pt-br'
    private static Locale saveLocaleByLanguage(String defaultLanguage){
        if (StringUtils.isNotEmpty(defaultLanguage)) {
            String[] locale = defaultLanguage.split("-");
            String language = locale[0];
            String country = locale[1];

            Locale mLocale = new Locale(language, country);
            Locale.setDefault(mLocale);

            return mLocale;
        }

        return null;
    }
}
