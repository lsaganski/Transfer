package br.livetouch.livecom.itaubba.utils;

import android.graphics.Typeface;

import br.livetouch.utils.AndroidUtils;

/**
 * Created by empresa on 18/07/2017.
 */

public class TypeFaceUtils {

    public static Typeface getTypeFace(String font){
        Typeface fromAsset = null;
        try {
            fromAsset = Typeface.createFromAsset(AndroidUtils.getContext().getAssets(), "fonts/"+font);
        }catch (Exception e){
            e.printStackTrace();
        }
        return fromAsset;
    }

    public static Typeface getTypeFaceOpenSansLight(){
        Typeface typeFace = TypeFaceUtils.getTypeFace("OpenSans-Light.ttf");
        if (typeFace != null){
            return typeFace;
        } else {
            return Typeface.defaultFromStyle(Typeface.NORMAL);
        }
    }

    public static Typeface getTypeFaceOpenSansSemiBold(){
        Typeface typeFace = TypeFaceUtils.getTypeFace("OpenSans-Semibold.ttf");
        if (typeFace != null){
            return typeFace;
        } else {
            return Typeface.defaultFromStyle(Typeface.NORMAL);
        }
    }
}
