package br.livetouch.livecom.itaubba.utils;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Message;
import android.view.View;
import android.webkit.ClientCertRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import br.livetouch.utils.LogUtil;

/*
 * Created by empresa on 19/10/2017.
 */

public class WebViewLoader {

    private boolean javaScriptEnabled;

    private boolean zoomControls;

    private UrlLoadingCallback urlLoadingCallback;

    private LoadCallback loadCallback;

    public interface UrlLoadingCallback {
        void OverrideUrlLoading(String url);
    }

    public interface LoadCallback {
        void OnPageStarted();
        void OnFinish();
        void OnError(Exception e);
    }

    public WebViewLoader setUrlLoadingCallback(UrlLoadingCallback urlLoadingCallback) {
        this.urlLoadingCallback = urlLoadingCallback;
        return this;
    }

    public WebViewLoader setLoadCallback(LoadCallback loadCallback) {
        this.loadCallback = loadCallback;
        return this;
    }

    public WebViewLoader setJavaScriptEnabled(boolean javaScriptEnabled) {
        this.javaScriptEnabled = javaScriptEnabled;
        return this;
    }

    public WebViewLoader setZoomControls(boolean zoomControls) {
        this.zoomControls = zoomControls;
        return this;
    }


    private WebViewLoader(WebView webView) {
        this.webView = webView;
    }

    private WebView webView;

    public static WebViewLoader with(WebView webView) {
        return new WebViewLoader(webView);
    }

    public void loadFromURl(String url) {
        try {
            setUpWebView();
            webView.loadUrl(url);
        } catch (Exception e) {
            e.printStackTrace();
            if (loadCallback != null)
                loadCallback.OnError(e);
        }
    }

    public void loadFromData(String data) {
        try {
            setUpWebView();
            webView.loadData(data, "text/html; text/css; charset=UTF-8", "utf-8");
        } catch (Exception e) {
            e.printStackTrace();
            if (loadCallback != null)
                loadCallback.OnError(e);
        }
    }

    private WebViewClient webViewCliente() {
        return new WebViewClient() {

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                if (errorResponse != null){
                    LogUtil.logError(errorResponse.toString());
                }
            }

            @Override
            public void onFormResubmission(WebView view, Message dontResend, Message resend) {
                super.onFormResubmission(view, dontResend, resend);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                super.onReceivedSslError(view, handler, error);
                if (error != null && handler != null){
                    handler.proceed();
                    LogUtil.logError(error.toString());
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, String url) {
                LogUtil.logError("< url : "+url);
                if (urlLoadingCallback != null)
                    urlLoadingCallback.OverrideUrlLoading(url);
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                super.shouldOverrideUrlLoading(view, request);
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Uri url = request.getUrl();
                    LogUtil.logError("< url : "+url.getPath());
                    if (urlLoadingCallback != null)
                        urlLoadingCallback.OverrideUrlLoading(url.getPath());
                }
                return true;
            }

            @Override
            public void onReceivedClientCertRequest(WebView view, ClientCertRequest request) {
                super.onReceivedClientCertRequest(view, request);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (error != null){
                    LogUtil.logError(error.toString());
                }
            }

            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (loadCallback != null)
                    loadCallback.OnPageStarted();
            }

            public void onPageCommitVisible(WebView view, String url) {
                super.onPageCommitVisible(view, url);
                LogUtil.logError("onPageCommitVisible");
                if (loadCallback != null)
                    loadCallback.OnFinish();
            }

            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                LogUtil.logError("onPageFinished");
                if (loadCallback != null)
                    loadCallback.OnFinish();
            }
        };
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setUpWebView() {
        webView.setVisibility(View.VISIBLE);
        webView.setWebViewClient(webViewCliente());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(javaScriptEnabled);
        settings.setBuiltInZoomControls(zoomControls);
    }
}
