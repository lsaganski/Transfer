package br.livetouch.livecom.itaubba.utils;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 27/10/2017.
 */

public class ImageUtil extends br.livetouch.livecom.utils.ImageUtil {

    public static void setImage(Context context, String resImage, final ImageView imageView, final int visibility) {
        if (imageView != null && StringUtils.isNotEmpty(resImage)) {
            Picasso.with(context).load(resImage).into(imageView, new Callback() {
                @Override
                public void onSuccess() {
                    imageView.setVisibility(View.VISIBLE);
                }

                @Override
                public void onError() {
                    imageView.setVisibility(visibility);
                }
            });
        }
    }
}
