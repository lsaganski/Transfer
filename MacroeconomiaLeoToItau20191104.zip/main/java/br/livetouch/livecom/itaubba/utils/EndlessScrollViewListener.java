package br.livetouch.livecom.itaubba.utils;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.List;

import br.livetouch.activity.BaseActivity;
import br.livetouch.task.BaseTask;
import br.livetouch.utils.ListUtils;

/*
 * Created by livetouch on 17/08/17.
 */

public class EndlessScrollViewListener<T> extends RecyclerView.OnScrollListener {
    int firstVisibleItem;
    int visibleItemCount;
    int totalItemCount;
    int lastVisibleItem;
    private int page;
    int pageSize = 0;
    private boolean lastLoad;
    private boolean loading;
    private BaseActivity activity;
    private LinearLayoutManager layoutManager;
    private BaseRecyclerViewAdapter adapter;
    private List<T> list;

    private EndlessScrollViewListener.Callback delegate;
    private boolean showingProgress;
    private boolean showProgressDialog;
    private boolean offlineMode;

    public EndlessScrollViewListener(BaseActivity activity, List<T> list) {
        this.page = 0;
        this.lastLoad = false;
        this.activity = activity;
        this.list = list;
    }

    public EndlessScrollViewListener(BaseActivity activity, List<T> list, int firstPage) {
        this.page = 0;
        this.lastLoad = false;
        this.activity = activity;
        this.list = list;
        this.page = firstPage;
    }

    public EndlessScrollViewListener(BaseActivity activity, List<T> list, boolean showProgressDialog, BaseRecyclerViewAdapter adapter) {
        this(activity, list);
        this.showProgressDialog = showProgressDialog;
        this.adapter = adapter;
    }

    public EndlessScrollViewListener(BaseActivity activity, List<T> list, int firstPage, boolean showProgressDialog, BaseRecyclerViewAdapter adapter) {
        this(activity, list);
        this.showProgressDialog = showProgressDialog;
        this.adapter = adapter;
        this.page = firstPage;
    }

    public void onScrolled(final RecyclerView recyclerView, int dx, int dy) {
        super.onScrolled(recyclerView, dx, dy);
        this.layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

        if (dy > 0) {
            this.visibleItemCount = this.layoutManager.getChildCount();
            this.totalItemCount = this.layoutManager.getItemCount();
            this.firstVisibleItem = this.layoutManager.findFirstVisibleItemPosition();
            this.lastVisibleItem = this.layoutManager.findLastVisibleItemPosition() + 1;

            if (this.lastLoad) {
                return;
            }

            if (this.lastVisibleItem == this.totalItemCount && !this.showingProgress) {
                this.showingProgress = true;
            }


            if (!this.loading && this.visibleItemCount + this.firstVisibleItem >= this.totalItemCount) {
                this.loading = true;

                BaseTask task = new BaseTask() {
                    List<T> itemsUpdate;

                    public void preExecute() throws Exception {
                        super.preExecute();
                    }

                    @Override
                    public void updateView() {
                        if (delegate != null) {
                            if (ListUtils.isEmpty(itemsUpdate)) {
                                if (adapter != null) {
                                    adapter.dismissProgress();
                                }
                                delegate.onScrollFinished();
                                lastLoad = true;
                            } else {
                                list.addAll(itemsUpdate);
                                recyclerView.getAdapter().notifyDataSetChanged();
                            }
                            loading = false;
                        }
                    }

                    @Override
                    public void execute() throws Exception {
                        if (delegate != null) {
                            itemsUpdate = delegate.onScrollGetNextList(++page);
                        }
                    }
                };
                if (this.offlineMode) {
                    if (this.showProgressDialog) {
                        this.activity.startTaskDialogOffline(task, br.livroandroid.utils.R.string.msg_aguarde, true);
                    } else {
                        this.activity.startTaskOffline(task, false);
                    }
                } else if (this.showProgressDialog) {
                    this.activity.startTaskDialog(task, br.livroandroid.utils.R.string.msg_aguarde, true);
                } else {
                    this.activity.startTask(task, false);
                }
            }
        }

    }

    public void clearPosition(){
        page = 0;
        lastLoad = false;
        adapter.isProgressVisisble = true;
    }

    public void setDelegate(EndlessScrollViewListener.Callback delegate) {
        this.delegate = delegate;
    }

    public void setOfflineMode(boolean offlineMode) {
        this.offlineMode = offlineMode;
    }

    public interface Callback<T> {
        void onScrollFinished();

        List<T> onScrollGetNextList(int var1) throws Exception;
    }
}
