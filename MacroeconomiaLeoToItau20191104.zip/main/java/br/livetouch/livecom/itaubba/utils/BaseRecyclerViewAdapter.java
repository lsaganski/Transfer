package br.livetouch.livecom.itaubba.utils;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.utils.LogUtil;

/**
 * Created by robson on 17/08/2017.
 */

public abstract class BaseRecyclerViewAdapter extends RecyclerView.Adapter<BaseRecyclerViewAdapter.BaseViewHolder> {
    private static final int VIEW_TYPE_PROGRESS = 9999;
    protected final Context context;
    private final LayoutInflater inflater;
    public boolean isProgressVisisble;
    private int pageSize;

    public BaseRecyclerViewAdapter(Context context) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.isProgressVisisble = true;
    }

    public BaseRecyclerViewAdapter(Context context, boolean isProgressVisisble, int pageSize) {
        this(context);
        this.isProgressVisisble = isProgressVisisble;
        this.pageSize = pageSize;
    }

    public LayoutInflater getInflater() {
        return this.inflater;
    }

    public Context getContext() {
        return this.context;
    }

    public final int getItemCount() {
        int p = this.isProgressVisisble && this.getCount() >= this.pageSize ? 1 : 0;
        return this.getCount() + p;
    }

    public int getItemViewType(int position) {
        boolean last = position == this.getCount();
        return last ? 9999 : 1;
    }

    public final BaseViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        if (viewType == 9999) {
            View view = this.getInflater().inflate(R.layout.adapter_view_progress, viewGroup, false);
            return new BaseRecyclerViewAdapter.ProgressViewHolder(view);
        } else {
            return this.onCreateBaseViewHolder(viewGroup, viewType);
        }
    }

    public final void onBindViewHolder(BaseViewHolder holder, int position) {
        if (holder instanceof BaseRecyclerViewAdapter.ProgressViewHolder) {
            LogUtil.log("onBindViewHolder progress position " + position);
        } else {
            this.onBindBaseViewHolder(holder, position);
        }

    }

    protected abstract void onBindBaseViewHolder(BaseViewHolder var1, int var2);

    public void dismissProgress() {
        this.isProgressVisisble = false;
        this.notifyDataSetChanged();
    }

    protected abstract BaseViewHolder onCreateBaseViewHolder(ViewGroup var1, int var2);

    public abstract int getCount();

    public static class BaseViewHolder extends RecyclerView.ViewHolder {
        public BaseViewHolder(View itemView) {
            super(itemView);
        }
    }

    public static class ProgressViewHolder extends BaseViewHolder {
        public View progress;

        public ProgressViewHolder(View view) {
            super(view);
            this.progress = view.findViewById(R.id.viewProgress);
            this.progress.setVisibility(View.VISIBLE);
        }
    }
}