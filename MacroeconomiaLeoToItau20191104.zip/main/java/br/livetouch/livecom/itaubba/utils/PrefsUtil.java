package br.livetouch.livecom.itaubba.utils;

import java.util.ArrayList;
import java.util.List;

import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.utils.Pref;

/**
 * Created by empresa on 19/07/2017.
 */

public class PrefsUtil {


    private static final String TUTORIAL_OK = "tutorial_ok";
    private static final String USER_LANGUAGE = "user_language";
    private static final String NOTIFICATION_ENABLED = "notification_enabled";

    public static boolean isTutorialCompleted() {
        return Pref.getBoolean(TUTORIAL_OK, false);
    }

    public static void setTutorialCompleted(boolean isCompleted) {
        Pref.setBoolean(TUTORIAL_OK, isCompleted);
    }

    public static String getUserLanguage(){
        return Pref.getString(USER_LANGUAGE);
    }

    public static void setUserLanguage(String language){
        Pref.setString(USER_LANGUAGE, language);
    }

    public static boolean getNotificationEnabled(){
        return Pref.getBoolean(NOTIFICATION_ENABLED, true);
    }

    public static void setNotificationEnabled(Boolean enabled){
        Pref.setBoolean(NOTIFICATION_ENABLED, enabled);
    }

    public static boolean isCategoriaInteresse(Long idCategoria){
        String id = String.valueOf(idCategoria);
        return Pref.getBoolean(id, true);
    }

    public static void setCategoriaInteresse(Long idCategoria, boolean ativa){
        String id = String.valueOf(idCategoria);
        Pref.setBoolean(id, ativa);
    }

    public static List<Categoria> getCategoriasInteresse(List<Categoria> categorias){
        List<Categoria> categoriasInteresse = new ArrayList<>();
        for (Categoria categoria : categorias) {
            boolean isInteresse = PrefsUtil.isCategoriaInteresse(categoria.getId());
            if (isInteresse) {
                categoriasInteresse.add(categoria);
            }
        }
        return categoriasInteresse;
    }
}
