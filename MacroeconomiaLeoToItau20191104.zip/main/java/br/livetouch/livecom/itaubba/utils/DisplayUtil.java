package br.livetouch.livecom.itaubba.utils;

import android.content.res.Resources;
import android.util.DisplayMetrics;

import br.livetouch.utils.LogUtil;

/**
 * Created by empresa on 16/08/2017.
 */

public class DisplayUtil {

    public static void logDisplayMetrics(){
        int densityDpi = (int) getMetrics().densityDpi;

        int widthPixels = getMetrics().widthPixels;
        float dp = widthPixels / getMetrics().density;

        float density = getMetrics().density;
        String densityToString = densityToString(density);

        LogUtil.logError("density = " + densityToString + " - dpi = " + densityDpi + " - dp = " + dp);
    }

    public static int convertDpToPixel(int dp){
        DisplayMetrics metrics = getMetrics();
        return (int) (dp * ((float)metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT));
    }

    public static int convertPixelsToDp(float px){
//        float scale = Resources.getSystem().getDisplayMetrics().density;
//        int padding_8dp = (int) (8 * scale + 0.5f);
//        LogUtil.logError(" padding : " + padding_8dp);

        DisplayMetrics metrics = getMetrics();
        return (int) (px / ((float)metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT));
    }

    private static DisplayMetrics getMetrics() {
        return Resources.getSystem().getDisplayMetrics();
    }

    private static String densityToString(float dp){
        if (dp == 0.75f) {
            return "ldpi";
        } else if (dp == 1.0f) {
            return "mdpi";
        } else if (dp == 1.5f){
            return "hdpi";
        } else if (dp == 2.0f){
            return "xhdpi";
        } else if (dp == 3.0f){
            return "xxhdpi";
        } else if (dp == 4.0f){
            return "xxxhdpi";
        }
        return "";
    }

}
