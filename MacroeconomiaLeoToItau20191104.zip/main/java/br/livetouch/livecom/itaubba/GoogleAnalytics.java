package br.livetouch.livecom.itaubba;

/*
 * Created by empresa on 23/10/2017.
 */

public class GoogleAnalytics {

    public static final String TAG = GoogleAnalytics.class.getSimpleName();

    /**
     *  Docs
     *  https://docs.google.com/spreadsheets/d/1zscKJqvTvAA4bs0Gmjj6lUXyZF2p650BMZnqZ9C8rL0/edit#gid=314366927
     *  http://lucida-brasil.github.io/clientes/template/implementacao_for_apps-GA-e-FA/
     */

    public static final String GA_KEY = "UA–107670323–1";

    //https://analytics.google.com/analytics/web/#embed/report-home/a109074403w162854502p163806735/
    public static final String GA_KEY_DEBUG = "UA-109074403-1";


    /* Track Type : ScreenView */

    public static final String HOME_PAGE = "home-page";

    public static final String PRE_HOME = "pre-home";

    public static final String CATEGORIAS = "categorias";

    public static final String BUSCA = "busca";

    public static final String PESQUISAR = "pesquisar";

    public static final String MAIS = "mais";

    public static final String BOOKMARKS = "bookmarks";


    /* Track Type : Event */

    public static final String CATEGORY_APP_MENU = "app:menu";

    public static final String CATEGORY_APP_HOME = "app:home";

    public static final String CATEGORY_APP_CONTEUDO = "app:conteudo";


    public static final String CLICK_NAVEGACAO = "click:navegacao";

    public static final String CLICK_CATEGORIA = "click:categoria";

    public static final String CLICK_DESTAQUE = "click:destaque";

    public static final String CLICK_BOOKMARK = "click:bookmark";


    /* customMetric */

    public static final int INDEX_METRIC_VIEW_CONTEND = 1;

    public static final int METRIC_CLICK_BOOKMARK = 2;

    public static final int METRIC_SHARE = 3;
}
