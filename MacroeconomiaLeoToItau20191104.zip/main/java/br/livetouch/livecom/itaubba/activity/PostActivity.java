package br.livetouch.livecom.itaubba.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.squareup.otto.Subscribe;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import br.livetouch.lib.viewpagerindicator.CirclePageIndicator;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.ItaubbaAplication;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.adapter.ArquivoPostAdapter;
import br.livetouch.livecom.itaubba.adapter.ImagesAdapter;
import br.livetouch.livecom.itaubba.adapter.PostAdapter;
import br.livetouch.livecom.itaubba.adapter.VideosAdapter;
import br.livetouch.livecom.itaubba.domain.Mural;
import br.livetouch.livecom.itaubba.domain.Post;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.domain.event.BusEvent;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.livecom.itaubba.utils.LivecomUtils;
import br.livetouch.livecom.itaubba.utils.ShareIntentUtils;
import br.livetouch.livecom.itaubba.utils.WebViewLoader;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;
import br.livetouch.utils.ListUtils;
import br.livetouch.utils.ListViewUtils;
import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 23/08/2017.
 */

public class PostActivity extends BaseActivity {
    private Long idPost;
    private int adapterType;
    private Post post;
    private List<Post> posts;
    private PostAdapter postAdapter;
    private PostInfo postInfo;

    private VideosAdapter videosAdapter;
    private ImagesAdapter imagensAdapter;
    private List<Arquivo> listImagens;
    private List<Arquivo> listVideos;
    private ViewPager pagerImagens;
    private CirclePageIndicator pageView;
    private RecyclerView recyclerVideos;

    private RecyclerView recyclerViewPosts;
    private MenuItem itemMenuFavorito;
    private ActionBar actionBar;
    private ListView listViewArquivos;
    private WebView webViewMensagem;
    private LinearLayout lnTxt;

    private boolean postByDeepIntent;
    Uri fileToShareUri;

    private FirebaseAnalytics firebaseAnalytics;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_post);

        Bundle extras = getIntent().getExtras();
        if (extras != null){
            idPost = extras.getLong(PostInfo.POST_ID, 0);
            adapterType = extras.getInt(PostInfo.TYPE_ADAPTER);
            postInfo = (PostInfo) extras.getSerializable(PostInfo.KEY);
        }

        firebaseAnalytics = FirebaseAnalytics.getInstance(getContext());

        // Post by share
        handleDeepIntent(getIntent());

        actionBar = setupToolbar();

        lnTxt = findViewById(R.id.lnTxt);
        listViewArquivos = findViewById(R.id.listViewArquivos);
        webViewMensagem = findViewById(R.id.webView);

        webViewMensagem.getSettings().setBuiltInZoomControls(false);
        webViewMensagem.getSettings().setDisplayZoomControls(false);

        pagerImagens = findViewById(R.id.pagerImagens);
        pageView = findViewById(R.id.pageView);

        // Recycler videos
        recyclerVideos = findViewById(R.id.recyclerVideo);
        setupRecyclerView(recyclerVideos);

        // Recycler posts leia também
        recyclerViewPosts = findViewById(R.id.recyclerView);
        setupRecyclerView(recyclerViewPosts);

        registerBus(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (post == null) {
            startTask(taskGetpost(), R.id.progress);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_post_activity, menu);
        itemMenuFavorito = menu.findItem(R.id.action_favorito);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_favorito) {
            favoritarPost(post, null, -1, true);
        } else if (id == R.id.action_share) {
            preparePDFToShare();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 43:
                preparePDFToShare();
        }
    }

    private void favoritarPost(Post post, ProgressBar progress, int adapterPosition, boolean showDialog) {
        if (showDialog) {
            startTask(taskFavoritar(post, progress, adapterPosition), R.id.progress);
        } else {
            startTask(taskFavoritar(post, progress, adapterPosition), false);
        }
    }

    private Task taskSharePost() {
        return new BaseTask() {

            String url;


            @Override
            public void execute() {
                if (post != null) {

//                    url = ItaubbaAplication.getInstance().getConfig().getUrlServer() + "/pages/post.htm?id=" + post.id + "&share=1";
//                    url = ItaubbaService.getUrlShortner(url);
                }
            }

            @Override
            public void updateView() {
                if (fileToShareUri != null && StringUtils.isNotEmpty(fileToShareUri.getPath())) {
                    ShareIntentUtils
                            .with(getBaseActivity())
                            .share(post.titulo, fileToShareUri);
                }
            }

            @Override
            public boolean onError(Throwable e) {
                updateView();
                return true;
            }

        };
    }

    protected boolean handleDeepIntent(Intent intent) {
        String action = intent.getAction();
        String data = intent.getDataString();
        postByDeepIntent = hasPostByIntent(intent);

        if (Intent.ACTION_VIEW.equals(action) && data != null && postByDeepIntent) {
            String postId;
            if (data.contains("&share=1")) {
                postId = data.substring(data.lastIndexOf("id=") + 3, data.indexOf("&"));
            } else {
                postId = data.substring(data.lastIndexOf("id=") + 3);
            }
            if (StringUtils.isNotEmpty(postId)) {
                this.idPost = Long.valueOf(postId);
                this.adapterType = -1;
                return true;
            }
        }
        return false;
    }


    private Task taskGetpost() {
        return new BaseTask() {

            @Override
            public void preExecute() throws Exception {
                super.preExecute();
                goneView(R.id.tSemResultado);
            }

            @Override
            public void execute() throws Exception {
                if (idPost != null && idPost > 0) {
                    post = ItaubbaService.getPost(getContext(), postInfo, idPost.toString());
                    if (post != null) {
                        ItaubbaService.savePostLido(post);
                        setImagesAndVideos();
                    }
                }
            }

            @Override
            public void updateView() {
                if (post != null) {
                    showView(R.id.rootView);

                    // titulo actionbar
                    setTitleActionBar();

                    // icone favorito na actionbar
                    setIconeFavoritoToolBar();

                    // strings do post
                    setText(R.id.tData, post.dateddMMYYYY);
                    setText(R.id.tCategoria, post.getCategoriaNome());
                    setText(R.id.tTitulo, post.titulo);
                    setText(R.id.tResumo, post.getResumo());

                    // carrega mensagem em html
                    WebViewLoader.with(webViewMensagem)
                            .setUrlLoadingCallback(openPodCastUrl)
                            .loadFromData(post.mensagem);

                    // documentos Anexados
                    showArquivosAnexados();

                    // Imagens anexadas
                    showImagensAnexadas();

                    // Videos anexados
                    showVideosAnexados();

                    String urlPodCast = post.getUrlPodCast();
                    if (post.isPodcast() && urlPodCast != null) {
                        showView(R.id.imgPodcast);
                        setOnClickListener(R.id.imgPodcast, openPodcast);
                    }

                    // Carrega 'leia tambem'
                    startTask(taskGetPosts(), R.id.progressLeiaTambem);

                    // GA
                    analyticstrackEvent();
                } else {
                    showView(R.id.tSemResultado);
                }
            }

            @Override
            public boolean onError(Throwable e) {
                Crashlytics.logException(e);
                showAlertAndFinish(e);
                return true;
            }
        };
    }

    private WebViewLoader.UrlLoadingCallback openPodCastUrl = url ->
            ShareIntentUtils
                    .with(getBaseActivity())
                    .setIntentCallBack(this::toast)
                    .openPodcastIntent(url);

    private View.OnClickListener openPodcast = view ->
            ShareIntentUtils
                    .with(getBaseActivity())
                    .setIntentCallBack(this::toast)
                    .openPodcastIntent(post.getUrlPodCast());


    private VideosAdapter.VideosAdapterCallback onClickVideo() {
        return new VideosAdapter.VideosAdapterCallback() {
            @Override
            public void onClickVideo(Arquivo video) {
                Bundle bundle = new Bundle();
                bundle.putSerializable(Arquivo.TAG, video);
                show(VideoViewActivity.class, bundle);
            }
        };
    }

    private ImagesAdapter.ImageAdapterListener onClickImagem() {
        return new ImagesAdapter.ImageAdapterListener() {
            @Override
            public void onClick(Arquivo imagem, int position) {
                Bundle b = new Bundle();
                b.putSerializable("ListaArquivos", (Serializable) listImagens);
                b.putInt("idxImagem",position);
                b.putSerializable(Arquivo.TAG,imagem);
                b.putString("PostTitle",post.titulo);
                show(GaleriaActivity.class, b);
            }
        };
    }

    private Task taskFavoritar(final Post post, @Nullable final ProgressBar progress, final int position) {
        return new BaseTask() {

            @Override
            public void preExecute() throws Exception {
                super.preExecute();
                if (progress != null) {
                    progress.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void execute() throws Exception {
                ItaubbaService.savePostFavorito(post);
            }

            @Override
            public void updateView() {
                if (progress != null) {
                    postAdapter.notifyItemChanged(position, post);
                    progress.setVisibility(View.INVISIBLE);
                } else {
                    setIconeFavoritoToolBar();
                }

                // nao envia eventos do "leia tambem"
                if (post.isfavorito && position == -1) {
                    trackEvent(GoogleAnalytics.CATEGORY_APP_CONTEUDO, GoogleAnalytics.CLICK_BOOKMARK, post.titulo, GoogleAnalytics.METRIC_CLICK_BOOKMARK);
                    firebaseTrackEvent(firebaseAnalytics, GoogleAnalytics.CATEGORY_APP_CONTEUDO, GoogleAnalytics.CLICK_BOOKMARK, post.titulo);
                }
            }

            @Override
            public boolean onError(Throwable e) {
                if (progress != null) {
                    progress.setVisibility(View.INVISIBLE);
                }
                if (e != null) {
                    Crashlytics.logException(e);
                }
                return super.onError(e);
            }
        };
    }

    // posts Leia tambem
    private Task taskGetPosts() {
        return new BaseTask() {
            Mural muralPosts;

            @Override
            public void preExecute() throws Exception {
                super.preExecute();
                showView(R.id.leiaTambem);
            }

            @Override
            public void execute() throws Exception {

                PostInfo postInfo = new PostInfo();
                postInfo.setExcludePostId(post.id);
                postInfo.setCategoria(post.categoria);
                postInfo.setMaxRows(3);

                muralPosts = ItaubbaService.getPosts(postInfo);
                posts = muralPosts != null ? muralPosts.posts : null;
            }

            @Override
            public void updateView() {
                if (ListUtils.isNotEmpty(posts)) {
                    if (postAdapter == null) {
                        postAdapter = new PostAdapter(getContext(), onClickPost(), posts, null, null, false, false);
                        recyclerViewPosts.setAdapter(postAdapter);
                    } else {
                        postAdapter.updateAdapter(posts);
                    }
                    showView(R.id.leiaTambem);
                } else {
                    hideView(R.id.leiaTambem);
                }
            }

            @Override
            public boolean onError(Throwable e) {
                hideView(R.id.leiaTambem);
                return true;
            }
        };
    }

    private PostAdapter.PostCallback onClickPost() {
        return new PostAdapter.PostCallback() {
            @Override
            public void onClickFavorito(Post post, ProgressBar progress, int adapterPosition) {
                favoritarPost(post, progress, adapterPosition, false);
            }

            @Override
            public void onClickPost(Post post, int adapterPosition) {
                Bundle bundle = new Bundle();
                bundle.putLong(PostInfo.POST_ID, post.id);
                bundle.putInt(PostInfo.TYPE_ADAPTER, post.adapterType);
                show(PostActivity.class, bundle);
            }

            @Override
            public void onClickVideo(Post post, int adapterPosition) {
                Arquivo arquivo = post.getFirstVideo();
                if (arquivo != null) {
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(Arquivo.TAG, arquivo);
                    show(VideoViewActivity.class, bundle);
                }
            }

            @Override
            public void openPodCast(String url) {
                ShareIntentUtils
                        .with(getBaseActivity())
                        .setIntentCallBack(message -> toast(message))
                        .openPodcastIntent(post.getUrlPodCast());
            }
        };
    }

    // Busca arquivos de imagens e vídeos no post e popula as listas
    private void setImagesAndVideos() {
        if(post!=null) {
            this.listImagens = post.getArquivosImagens();
            this.listVideos = post.getArquivosVideos();
        }
    }

    // documentos Anexados
    private void showArquivosAnexados() {
        if (post != null && ListUtils.isNotEmpty(post.getArquivosDoc())) {
            findViewById(R.id.layoutAnexos).setVisibility(View.VISIBLE);
            ArquivoPostAdapter arquivoPostAdapter = new ArquivoPostAdapter(getBaseActivity(), post.getArquivosDoc(), onClickAnexo());
            listViewArquivos.setAdapter(arquivoPostAdapter);
            ListViewUtils.setListViewHeightBasedOnChildren(listViewArquivos);
        } else {
            findViewById(R.id.layoutAnexos).setVisibility(View.GONE);
        }
    }

    private void showVideosAnexados() {
        if (ListUtils.isNotEmpty(listVideos)) {
            showView(recyclerVideos);
            if (videosAdapter == null) {
                videosAdapter = new VideosAdapter(getContext(), listVideos, onClickVideo());
                recyclerVideos.setAdapter(videosAdapter);
            }
        } else {
            goneView(recyclerVideos);
        }
    }

    private void showImagensAnexadas() {
        if (ListUtils.isNotEmpty(listImagens)) {
            showView(R.id.viewImagens);
            if (imagensAdapter == null) {
                imagensAdapter = new ImagesAdapter(getContext(), listImagens, onClickImagem());
                // Cria e popula o View Pager
                pagerImagens.setAdapter(imagensAdapter);
                pageView.setViewPager(pagerImagens);
                // Exibe indicador de paginação com 2 imagens ou mais
                if (ListUtils.isEmpty(listImagens) || listImagens.size() == 1) {
                    pageView.setVisibility(View.GONE);
                }
            }
        } else {
            goneView(R.id.viewImagens);
        }
    }

    private ArquivoPostAdapter.callbackArquivo onClickAnexo() {
        return new ArquivoPostAdapter.callbackArquivo() {
            @Override
            public void onClickAnexo(Arquivo arquivo) {
                LivecomUtils.tryOpenAnexoOnApp(getBaseActivity(), arquivo);
            }
        };
    }

    private void setIconeFavoritoToolBar() {
        if (itemMenuFavorito != null) {
            int resIcon = post != null && post.isfavorito ? R.drawable.icn_favorito_on : R.drawable.icn_favorito_off;
            itemMenuFavorito.setIcon(resIcon);
        }
    }

    private void setTitleActionBar() {
        if (post != null && actionBar != null) {
            String categoriaPai = post.getCategoriaPaiName();
            actionBar.setTitle(categoriaPai);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void analyticstrackEvent() {
        String data = post.dateddMMYYYY.replaceAll("/", "-");
        trackEventScreenView(GoogleAnalytics.INDEX_METRIC_VIEW_CONTEND, post.getCategoriaPaiName(), post.getCategoriaNome(), data, post.titulo);
        firebaseTrackEventScreen(firebaseAnalytics, post.getCategoriaPaiName(), post.getCategoriaNome(), data, post.titulo);
    }

    @Subscribe
    public void ActivityShareClicked(BusEvent.ActivityShareClicked event) {
        String appName = "compartilhamento:" + event.appName;
        if (StringUtils.isNotEmpty(appName)) {
            trackEvent(GoogleAnalytics.CATEGORY_APP_CONTEUDO, appName, post.titulo, GoogleAnalytics.METRIC_SHARE);
            firebaseTrackEvent(firebaseAnalytics, GoogleAnalytics.CATEGORY_APP_CONTEUDO, appName, post.titulo);
        }
    }

    @Override
    protected void onActionBarHomePressed() {
        onBackPressed();
    }

    public void setBusPostResult() {
        if (post != null && this.adapterType != -1) {
            post.adapterType = this.adapterType;
            postBus(new BusEvent.PostUpdateEvent(post));

            // Bus GA
            setBusGAResult();
        }
    }

    private void setBusGAResult() {
        if (postInfo != null) {
            BusEvent.trackGAEvent trackGAEvent = new BusEvent.trackGAEvent();
            trackGAEvent.isResultFragment = StringUtils.isNotEmpty(postInfo.getQuery());
            trackGAEvent.isBookmarkFragment = postInfo.isMenuFavorito();
            trackGAEvent.isHomePage = isHomePage(trackGAEvent);
            postBus(trackGAEvent);
        }
    }

    private boolean isHomePage(BusEvent.trackGAEvent trackGAEvent) {
        return !trackGAEvent.isBookmarkFragment && !trackGAEvent.isResultFragment
                && !postInfo.isMenuCategorias() && postInfo.getCategoria() == null;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (webViewMensagem != null) {
            webViewMensagem.destroy();
        }

        unregisterBus(this);
    }

    @Override
    public void finish() {
        setBusPostResult();

        if (postByDeepIntent) {
            navigateToUp();
        }

        super.finish();
    }

    private void preparePDFToShare() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Bitmap bitmap = drawBitmapFromView(lnTxt, lnTxt.getWidth(), lnTxt.getHeight());
            File outputFile = createPdfFromBitmap(bitmap);

            fileToShareUri = Uri.fromFile(outputFile);

            startTask(taskSharePost(), true);
        } else {
            // Request permission from the user
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 43);
        }
    }

    private Bitmap drawBitmapFromView(View view, int width, int height) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.setBackgroundColor(Color.rgb(255, 255, 255));
        view.draw(canvas);
        return bitmap;
    }

    private File createPdfFromBitmap(Bitmap bitmap) {
        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(bitmap.getWidth(), bitmap.getHeight(), 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        canvas.drawPaint(paint);
        bitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight(), true);
        paint.setColor(Color.BLUE);
        canvas.drawBitmap(bitmap, 0, 0, null);
        document.finishPage(page);

        String directory_path = Environment.getExternalStorageDirectory().getPath() + "/itauBba/";
        File file = new File(directory_path);
        if (!file.exists()) {
            file.mkdirs();
        }
        String targetPdf = directory_path+"post.pdf";
        File filePath = new File(targetPdf);
        try {
            document.writeTo(new FileOutputStream(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // close the document
        document.close();

        return filePath;
    }
}
