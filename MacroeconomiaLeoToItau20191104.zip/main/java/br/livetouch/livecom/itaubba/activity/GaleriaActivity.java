package br.livetouch.livecom.itaubba.activity;

import android.os.Bundle;
import android.support.v7.app.ActionBar;

import java.util.ArrayList;
import java.util.List;

import br.livetouch.lib.viewpagerindicator.CirclePageIndicator;
import br.livetouch.livecom.adapters.GaleriaImagensAdapter;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.domain.view.ViewPager;
import br.livetouch.livecom.itaubba.R;

/*
 * Created by livetouch on 03/10/17.
 */

public class GaleriaActivity extends BaseActivity {

    private GaleriaImagensAdapter imagensAdapter;

    /* Componentes */
    private ViewPager viewPager;
    private CirclePageIndicator pageIndicator;

    /* Objetos */
    private List<Arquivo> imagens;
    private List<String> listUrls;
    private int fotoPosition = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_galeria);

        ActionBar actionBar = setupToolbar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        String title;
        Bundle extras = this.getIntent().getExtras();
        if (extras!=null){
            imagens = (List<Arquivo>) extras.getSerializable("ListaArquivos");
            fotoPosition = extras.getInt("idxImagem", 0);
            title = extras.getString("PostTitle");
            actionBar.setTitle(title);
        }

        viewPager = this.findViewById(R.id.viewer);
        viewPager.setOffscreenPageLimit(3);

        if(imagens != null) {
            pageIndicator = this.findViewById(R.id.pageView);
            listUrls = new ArrayList<>();
            for(Arquivo a: imagens){
                listUrls.add(a.url);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (imagensAdapter == null) {
            setUpGaleriaAdapter();
        }
    }

    private void setUpGaleriaAdapter() {
        imagensAdapter = new GaleriaImagensAdapter(getContext(), listUrls);
        viewPager.setAdapter(imagensAdapter);
        viewPager.setCurrentItem(fotoPosition);
        if(imagens != null) {
            pageIndicator.setViewPager(viewPager);
            pageIndicator.setCurrentItem(fotoPosition);
        }
    }
}
