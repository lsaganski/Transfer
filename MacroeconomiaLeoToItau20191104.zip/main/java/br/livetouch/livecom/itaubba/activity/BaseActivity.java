package br.livetouch.livecom.itaubba.activity;

import android.annotation.SuppressLint;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.NavUtils;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.List;

import br.livetouch.adapter.BaseRecyclerViewAdapter;
import br.livetouch.exception.DomainException;
import br.livetouch.livecom.fragment.LivecomFragment;
import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.domain.SubCategoria;
import br.livetouch.livecom.itaubba.fragment.BaseFragment;
import br.livetouch.livecom.itaubba.utils.LocaleUtils;
import br.livetouch.livecom.view.EndlessScrollViewListener;
import br.livetouch.utils.AlertUtils;
import br.livetouch.utils.ListUtils;
import br.livetouch.utils.LogUtil;
import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 21/07/2017.
 */

@SuppressLint("Registered")
public class BaseActivity extends br.livetouch.activity.BaseActivity{

    private ViewHolder viewHolder;

    public BaseActivity() {
        LocaleUtils.updateConfig(this);
        setUpOnBackStackChangedListener();
    }

    public void trackEventScreenView(String... args) {
        trackEventScreenView(-1, args);
    }

    public void trackEventScreenView(int indexCustomMetric, String... args) {
        String description = getSreenName(args);
        trackScreenMultipleHit(description, indexCustomMetric);
    }

    public void trackScreenMultipleHit(String screenName, int indexCustomMetric) {
        Tracker t = getTracker();
        if (t != null) {
            HitBuilders.EventBuilder builder = new HitBuilders.EventBuilder();
            t.setScreenName(screenName);
            if (indexCustomMetric != -1) {
                builder.setCustomMetric(indexCustomMetric, 1);
                LogUtil.log(GoogleAnalytics.TAG,"SCREEN_VIEW: " + screenName + " | metric [" + indexCustomMetric + ":1]");
            } else {
                LogUtil.log(GoogleAnalytics.TAG,"SCREEN_VIEW: " + screenName);
            }
            t.send(builder.build());
        }
    }

    public void trackEvent(String category, String action, final String label) {
        trackEvent(category, action, label, -1);
    }

    public void trackEvent(String category, String action, final String label, int indexCustomMetric) {
        Tracker t = getTracker();
        if (t != null) {
            HitBuilders.EventBuilder builder = new HitBuilders.EventBuilder();
            builder.setCategory(category).setAction(action).setLabel(label).setValue(1);
            if (indexCustomMetric != -1) {
                builder.setCustomMetric(indexCustomMetric, 1);
                LogUtil.log(GoogleAnalytics.TAG,"category : " + category + " | action: " + action + " | label: " + label + " | metric [" + indexCustomMetric + ":1]");
            } else {
                LogUtil.log(GoogleAnalytics.TAG,"category : " + category + " | action: " + action + " | label: " + label);
            }
            t.send(builder.build());
        }
    }

    public void firebaseTrackEvent(FirebaseAnalytics mFirebaseAnalytics, String category, String action, String label) {
        if (mFirebaseAnalytics != null) {
//            LogUtil.log("GoogleAnalytics firebase: category: " + category + " | action: " + action + " | label: " + label);
            setUpFirebase(mFirebaseAnalytics);
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, category);
            bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, action);
            bundle.putString(FirebaseAnalytics.Param.ITEM_ID, label);
            mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        } else {
            LogUtil.logError("Obtain the FirebaseAnalytics instance in onCreate().");
        }
    }

    public void firebaseTrackEventScreen(FirebaseAnalytics mFirebaseAnalytics, String... args) {
        String sreenName = getSreenName(args);
        if (mFirebaseAnalytics != null) {
            setUpFirebase(mFirebaseAnalytics);
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, sreenName);
            mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        } else {
            LogUtil.logError("Obtain the FirebaseAnalytics instance in onCreate().");
        }
    }

    private void setUpFirebase(FirebaseAnalytics mFirebaseAnalytics) {
        //Sets whether analytics collection is enabled for this app on this device.
        mFirebaseAnalytics.setAnalyticsCollectionEnabled(true);

        //Sets the minimum engagement time required before starting a session. The default value is 10000 (10 seconds).
        mFirebaseAnalytics.setMinimumSessionDuration(20000);

        //Sets the duration of inactivity that terminates the current session. The default value is 1800000 (30 minutes).
        mFirebaseAnalytics.setSessionTimeoutDuration(500);
    }

    @NonNull
    private String getSreenName(String[] args) {
        StringBuilder screenName = new StringBuilder();
        if (args != null) {
            if (args.length == 1) {
                screenName = new StringBuilder("/" + args[0] + "/");
            } else {
                for (String value : args) {
                    screenName.append("/").append(value);
                }
            }
        }
        return screenName.toString();
    }

    protected ActionBar setupToolbar() {
        ActionBar actionBar = this.getSupportActionBar();
        if(actionBar == null) {
            Toolbar toolbarPost = findViewById(R.id.toolbar_post);
            if(toolbarPost != null) {
                this.setSupportActionBar(toolbarPost);
            } else {
                Toolbar toolbar = findViewById(R.id.toolbar);
                if(toolbar != null) {
                    this.setSupportActionBar(toolbar);
                }
            }
        }
        return this.getSupportActionBar();
    }

    protected void onActionBarHomePressed() {
		supportFinishAfterTransition();
    }

    public void setUpOnBackStackChangedListener() {
        final FragmentManager fragmentManager = getSupportFragmentManager();
        if (fragmentManager != null) {
            fragmentManager.addOnBackStackChangedListener(() -> {
                FragmentManager fm = getSupportFragmentManager();
                ActionBar actionBar = getSupportActionBar();
                if (fm != null && actionBar != null) {
                    int backStackCount = fm.getBackStackEntryCount();
                    actionBar.setDisplayHomeAsUpEnabled(backStackCount != 0);
                    fragmentUpdateTitle();
                }
            });
        }
    }

    public void clearBackStack(){
        FragmentManager fm = getSupportFragmentManager();
        int count = fm.getBackStackEntryCount();
        for (int i = 0; i < count; ++i) {
            fm.popBackStack();
        }
    }

    private BaseFragment getCurrentFragment() {
        BaseFragment baseFragment = getCurrentFragmentFromBackStack();
        if (baseFragment != null){
            return baseFragment;
        } else {
            FragmentManager fm = getSupportFragmentManager();
            BaseFragment f = (BaseFragment) fm.findFragmentById(R.id.content_frame);
            if (f != null) {
                return f;
            }
        }
        return null;
    }

    private BaseFragment getCurrentFragmentFromBackStack(){
        FragmentManager fm = getSupportFragmentManager();
        int index = fm.getBackStackEntryCount();
        if (index > 0) {
//          BaseFragment currFrag = (BaseFragment) fm.getFragments().get(backStackCount);
//          String tag = currFrag.getTag();
            FragmentManager.BackStackEntry backStack = fm.getBackStackEntryAt(index -1);
            String tag = backStack.getName();
            LogUtil.log("last frag : " + tag);
            return (BaseFragment) fm.findFragmentByTag(tag);
        }
        return null;
    }

    protected int getFragmentsSize() {
        List<Fragment> fragmentList = getSupportFragmentManager().getFragments();
        if (ListUtils.isNotEmpty(fragmentList)) {
            return fragmentList.size();
        }
        return 0;
    }

    protected int removeFragmentsByTag(String tag) {
        List<Fragment> fragmentList = getSupportFragmentManager().getFragments();
        if (ListUtils.isNotEmpty(fragmentList)) {
            for (Fragment fragment : fragmentList) {
                LogUtil.log("fragment tag : " + fragment.getTag());
                if (!StringUtils.equalsIgnoreCase(fragment.getTag(), tag)) {
                    getSupportFragmentManager().beginTransaction().remove(fragment).commit();
                }
            }
            return fragmentList.size();
        }

        return 0;
    }

    public void setTitle(PostInfo postInfo) {
        Categoria categoria = postInfo.getCategoria();
        SubCategoria subCategoria = postInfo.getSubCategoria();

        setUpViewHolderToolbar();

        if (this.viewHolder != null) {
            if (subCategoria != null) {
                String categoriaPaiName = subCategoria.categoriaPai != null ? subCategoria.categoriaPai.nome : "";
                String categoriaName;

                if (subCategoria.isEditoria) {
                    categoriaName = subCategoria.categoria != null ? categoriaPaiName + " - " + subCategoria.categoria.nome : categoriaPaiName;
                } else {
                    categoriaName = categoriaPaiName;
                }

                setText(viewHolder.tSubTitulo, categoriaName);
                setText(viewHolder.tTitulo, subCategoria.nome);
                showView(viewHolder.rootView);
            } else if (categoria != null) {
                setText(viewHolder.textcategoria, categoria.nome);
                showView(viewHolder.rootView);
            }
        }
    }

    private void setUpViewHolderToolbar() {
        Toolbar toolbarPost = (Toolbar) findViewById(R.id.toolbar_post);
        if (viewHolder == null && toolbarPost != null) {
            viewHolder = new ViewHolder(toolbarPost);
        }
    }

    public void restoreToolbar() {
        if (viewHolder != null){
            goneView(viewHolder.rootView);
            goneView(viewHolder.tTitulo);
            goneView(viewHolder.tSubTitulo);
            goneView(viewHolder.textcategoria);
        }
    }

    protected void showAlertAndFinish(@NonNull String message) {
        AlertUtils.alert(getActivity(), message, new Runnable() {
            @Override
            public void run() {
                finish();
            }
        });
    }

    protected void showAlertAndFinish(Throwable e) {
        String msg = e != null && StringUtils.isNotEmpty(e.getMessage()) ? e.getMessage() : getString(R.string.servidor_nao_respodeu_verifique_conexao);
        msg = e instanceof DomainException ? msg : getString(R.string.servidor_nao_respodeu_verifique_conexao);
        showAlertAndFinish(msg);
    }

    protected void setText(int resId, String text) {
        TextView t = (TextView)this.findViewById(resId);
        if(t != null && StringUtils.isNotEmpty(text)) {
            t.setText(text);
            t.setVisibility(View.VISIBLE);
        }
    }

    protected void setupRecyclerView(RecyclerView recyclerView) {
        setupRecyclerView(recyclerView, null);
    }

    protected SwipeRefreshLayout setupRecyclerView(RecyclerView recyclerView, SwipeRefreshLayout.OnRefreshListener onRefreshListener) {
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this.getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        SwipeRefreshLayout swipeLayout = findViewById(R.id.swipe_container);
        if (onRefreshListener != null && swipeLayout != null) {
            swipeLayout.setColorSchemeResources(R.color.brownish_orange_two);
            swipeLayout.setOnRefreshListener(onRefreshListener);
            return swipeLayout;
        }
        return null;
    }

    public EndlessScrollViewListener addEndlessScrollViewListener(RecyclerView recyclerView, List<?> list, EndlessScrollViewListener.Callback scrollCallback, boolean showProgress, BaseRecyclerViewAdapter adapter) {
        EndlessScrollViewListener endScroll = new EndlessScrollViewListener(this, list, showProgress, adapter);
        endScroll.setDelegate(scrollCallback);
        recyclerView.addOnScrollListener(endScroll);
        return endScroll;
    }

    public void addFragment(Fragment fragment) {
        if (fragment != null) {
            // add
            android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();

            LivecomFragment oldFragment = (LivecomFragment) fragmentManager.findFragmentByTag("homeFragment");
            if (oldFragment != null) {
                oldFragment.release();
            }

            String tag = ((Object) fragment).getClass().getSimpleName();
            fragmentManager.beginTransaction().add(br.livetouch.livecom.lib.R.id.content_frame, fragment, tag).addToBackStack(tag).commit();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        fragmentUpdateTitle();
    }

    private void fragmentUpdateTitle() {
        BaseFragment currentFragment = getCurrentFragment();
        if (currentFragment != null){
            currentFragment.restoreTitle();
        }
    }

    void setText(TextView textView, String text){
        if (textView != null){
            if (StringUtils.isNotEmpty(text)){
                textView.setText(text);
                textView.setVisibility(View.VISIBLE);
            } else {
                textView.setVisibility(View.GONE);
            }
        }
    }

    public void handleIntent(Intent deepLinkIntent, Class<? extends BaseActivity> activity){
        Intent intent = new Intent(this, activity);
        Uri data = deepLinkIntent.getData();
        intent.setData(data);
        intent.setAction(deepLinkIntent.getAction());
        startActivity(intent);
        finish();
    }

    public boolean hasPostByIntent(Intent intent) {
        String dataString = intent != null ? intent.getDataString() : "";
        if (StringUtils.isNotEmpty(dataString) && dataString.contains("pages/")) {
            String page = dataString.substring(dataString.lastIndexOf("pages/") + 6, dataString.lastIndexOf(".htm"));
            if (StringUtils.equalsIgnoreCase(page, "post")){
                return true;
            }
        }
        return false;
    }

    public void navigateToUp() {
        final Intent upIntent = getParentActivityIntent(this);
        if (NavUtils.shouldUpRecreateTask(this, upIntent) || isTaskRoot()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                TaskStackBuilder.create(this).addNextIntentWithParentStack(upIntent).startActivities();
            }
        } else {
            NavUtils.navigateUpTo(this, upIntent);
        }
    }

    public static Intent getParentActivityIntent(Context context){
        return new Intent(context, HomeActivity.class);
    }

    public BaseActivity getBaseActivity() {
        return (BaseActivity) getActivity();
    }

    private class ViewHolder{
        TextView tTitulo;
        TextView tSubTitulo;
        TextView textcategoria;
        View rootView;

        public ViewHolder(View toolbarPost) {
            tTitulo = toolbarPost.findViewById(R.id.tTitulo);
            tSubTitulo = toolbarPost.findViewById(R.id.tSubTitulo);
            textcategoria = toolbarPost.findViewById(R.id.tCategoria);
            rootView = toolbarPost.findViewById(R.id.rootView);
        }
    }
}
