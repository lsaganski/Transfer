package br.livetouch.livecom.itaubba.activity;

/*
 * Created by empresa on 06/10/2017.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.livecom.itaubba.utils.LivecomUtils;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;

public class ShareActivity extends BaseActivity {

    Intent intent;
    boolean hasPostByIntent;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        intent = getIntent();

        if (intent != null){
            handleIntent(intent);
        }
    }

    private void handleIntent(Intent intent) {
        String action = intent.getAction();
        String data = intent.getDataString();

        if (Intent.ACTION_VIEW.equals(action) && data != null) {
            hasPostByIntent = hasPostByIntent(intent);
            if (hasPostByIntent) {
                handleDeepLink(intent);
            } else {
                // url from shorter api
                startTask(taskHandleIntent(), true);
            }
        } else {
            showSplashActivity();
        }
    }

    private void showSplashActivity() {
        show(SplashActivity.class);
        finish();
    }

    private Task taskHandleIntent() {
        return new BaseTask() {

            @Override
            public void execute() throws Exception {
                String url = ItaubbaService.getExpandUrlShortner(intent.getDataString());
                intent.setData(Uri.parse(url));
                hasPostByIntent = hasPostByIntent(intent);
            }

            @Override
            public void updateView() {
                if (hasPostByIntent) {
                    handleDeepLink(intent);
                } else {
                    showSplashActivity();
                }
            }
        };
    }

    public void handleDeepLink(Intent deepLinkIntent) {
        boolean isOpen = LivecomUtils.isMyApplicationTaskOpen(getContext());
        handleIntent(deepLinkIntent, isOpen ? PostActivity.class : SplashActivity.class);
    }
}