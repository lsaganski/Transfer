package br.livetouch.livecom.itaubba.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.webkit.WebView;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.livecom.itaubba.utils.WebViewLoader;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;

/*
 * Created by livetouch on 25/07/17.
 */

public class TermosUsoActivity extends BaseActivity {

    private WebView webView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_termos_uso);

        ActionBar actionBar = setupToolbar();
        if (actionBar != null) {
            actionBar.setTitle(R.string.termos_de_uso);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        webView = (WebView) findViewById(R.id.webView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startTask(taskLoadAssets(), false);
    }

    private Task taskLoadAssets() {
        return new BaseTask() {

            String url;

            @Override
            public void execute() throws Exception {
                url = ItaubbaService.getUrlTermosDeUso();
            }

            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void updateView() {
                WebViewLoader.with(webView)
                        .setJavaScriptEnabled(true)
                        .setZoomControls(true)
                        .setLoadCallback(onLoad)
                        .loadFromURl(url);
            }

            @Override
            public boolean onError(Throwable e) {
                goneView(R.id.progress);
                showAlertAndFinish(e);
                return true;
            }

            @Override
            public boolean onErrorNetworkUnavailable() {
                goneView(R.id.progress);
                return super.onErrorNetworkUnavailable();
            }
        };
    }

    private WebViewLoader.LoadCallback onLoad = new WebViewLoader.LoadCallback() {

        @Override
        public void OnPageStarted() {
            showView(R.id.progress);
        }

        @Override
        public void OnError(Exception e) {
            goneView(R.id.progress);
        }

        @Override
        public void OnFinish() {
            goneView(R.id.progress);
        }
    };
}
