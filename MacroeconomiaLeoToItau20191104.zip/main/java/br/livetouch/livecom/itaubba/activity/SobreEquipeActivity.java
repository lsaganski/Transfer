package br.livetouch.livecom.itaubba.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.webkit.WebView;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.adapter.EquipeAdapter;
import br.livetouch.livecom.itaubba.domain.Equipe;
import br.livetouch.livecom.itaubba.utils.WebViewLoader;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;

/*
 * Created by livetouch on 25/07/17.
 */

public class SobreEquipeActivity extends BaseActivity {

//    private WebView webView;
//    private ProgressBar progressBar;
    private RecyclerView recyclerView;

    private List<Equipe> team;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        setContentView(R.layout.activity_sobre_equipe);

        ActionBar actionBar = setupToolbar();
        if (actionBar != null) {
            actionBar.setTitle(R.string.sobre_a_equipe);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        LoadTeams();

        recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this.getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(new EquipeAdapter(team));

//        webView = (WebView) findViewById(R.id.webView);
//        progressBar = findViewById(R.id.progress);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        startTask(taskLoadSobreEquipe(), false);
    }

    private void LoadTeams() {
        if (Locale.getDefault().getLanguage().equals("en")) {
            team = new ArrayList<Equipe>();
            team.add(new Equipe("Mario Mesquita", "Dr. Mário Mesquita is Chief Economist at Itaú Unibanco, Brazil’s largest private-sector bank. He holds a doctorate degree in Economics from Oxford University. Mário has served as a senior partner at Banco Brasil Plural, a Deputy Governor for the Central Bank of Brazil, the Chief Economist at ABN AMRO Brazil and LATAM, the Economics Director at FEBRABAN (the Brazilian Bankers Federation) and an economist for the IMF."));
            team.add(new Equipe("Alexandre Gomes Da Cunha", "Joined Itaú’s macro team in August 2016. Alexandre is one of the economists responsible for the coverage of Brazilian economic activity and, previously, has also worked with commodities analysis. Alexandre holds a bachelor degree in Economics from Insper."));
            team.add(new Equipe("André Cardoso Barbeiro Matcin", "André Matcin holds a bachelor degree in Economics from Insper and is a master's degree student of Economics at the same institution. He joined Itaú's Macro Research sell-side team in 2015, and is responsible for reports, meetings and conference calls with clients."));
            team.add(new Equipe("Diego Ciongo", "He covers Argentina, Paraguay and Uruguay economies based in Itaú Unibanco Argentina. He previoulsy worked at the central bank of Argentina as senior economist in macroecononic research. Diego holds a degree from UNQ and a postgraduate degree from UCA."));
            team.add(new Equipe("Felipe Salles", "Is the economist in charge of modeling and designing scenarios for the Brazilian economy. He was a partner at Ciano Investimentos (2007-2008) and a partner at Axio Investimentos (2009-2010), responsible for macroeconomic research. He holds a bachelor’s degree in Economics from UFRJ, a master’s degree from PUC-Rio and was in the PhD program in Economics at the London School of Economics."));
            team.add(new Equipe("Fernando M. Gonçalves", "Fernando M. Gonçalves holds a Ph.D. in Economics from the University of California at Berkeley, an M.A. in Economics from FGV-RJ and a B.A. in Industrial Engineering from the Federal University of Rio de Janeiro (UFRJ). Before joining Itaú, Fernando was head of economic research at Vinci Partners, worked at two other asset management firms in Brazil – JGP and Ventor Investimentos – and was an economist at the International Monetary Fund (IMF). In 2015 and 2016, Fernando was also a professor at the Professional Master Program in Economics and Finance of PUC-RJ. His vast experience includes the coverage of Brazilian and international economies, including various presentations and road shows for institutional clients. He is currently head of the sell-side area in the Macroeconomic research team at Itaú."));
            team.add(new Equipe("Guilherme B. Martins", "Dr. Martins has been an economist at Itaú Unibanco since 2011. He holds a Ph.D. in Economics from Columbia University. Mr. Martins is the economist of the treasury desk of Itaú Unibanco and he is in charge of macroeconomic analysis for international economies excluding Latin America. Previously he was based in London and in charge of macroeconomic analysis for Europe. Mr. Martins also worked as a strategist for emerging markets at Deutsche Bank in New York, in the investment banking area of Itaú BBA and as a fixed income manager at Unibanco Asset Management."));
            team.add(new Equipe("Igor Barreto Rose", "Igor Rose joined the economic research team at Itaú BBA in 2018, integrating the Sell-Side team as one of the responsible for studies, reports, meetings and conference calls with clients. He holds a master's and bachelor’s degree in Economics from the University of São Paulo and has experience in the financial and in the real sector."));
            team.add(new Equipe("João Pedro Bumachar Resende", "Is responsible for covering Latin American economies, ex-Brazil. He holds a Business Management degree from FGV-SP (2003) and a master’s degree in Economics from PUC-RJ (2006). He worked in the economics department of Banco BBM for two years before joining Unibanco, also in the economics department, in October 2008."));
            team.add(new Equipe("Juan C. Barboza", "Is responsible for covering Argentina, Paraguay and Uruguay based in Itaú Unibanco Argentina. He previously he worked Argentina`s Central Bank as principal reserve manager. He started his career at the Ministry of Economy, where he worked in several positions, such as finance undersecretary, financial representative for Europe based in London and director of financial information. Juan holds a bachelor’s degree from Universidad de Buenos Aires and a master’s degree from Universidad del CEMA, and was in the executive finance program at the London Business School."));
            team.add(new Equipe("Julia Passabom Araujo", "Julia Passabom Araujo holds a Ph.D in Economics from the University of São Paulo (USP), and an M.A. and B.A. from the same institution. Julia is responsible for inflation forecasts at Itaú. Before joining Itaú, Julia has worked in an asset management firm (M Safra 2016-2017) in which she was responsible for inflation forecasts for Brazil and analysis of economies in the Euro Zone. She also worked at Banco Fator (2014-2016) and was an assistant professor of macroeconomics at Insper (2014-2018)."));
            team.add(new Equipe("Julia Wrobel Folescu Gottlieb", "Has been an economist at Itaú Unibanco since May 2014, responsible for covering external accounts and exchange rate. Previously, she worked as an analyst at the Chief Economist Office for Latin America at the World Bank in Washington DC (2013-2014) and as an intern at Galanto Consultoria (2008-2010). She holds an Economics degree from PUC-Rio (2010) and a master’s degree in Economics also from PUC-Rio (2013)."));
            team.add(new Equipe("Julio Cesar Ruiz Alvarez", "Is responsible for covering the economies of Mexico and Peru. Previously worked at the Chief economist office in Mexico’s Ministry of Finance in several positions, such as Deputy General Director of Economic Policy, Director of Financial Planning and Head of the Investor Relations Office. He started his career as an economist in Mexico’s Central Bank and holds a bachelor degree in economics from ITAM (Mexico) and a master degree in public administration (MPA) with a specialization in economic policy and international finance from Columbia University (New York)."));
            team.add(new Equipe("Laura Candido de Souza Pitta", "Has been an economist at Itaú Unibanco since March 2015. Previously, she was an Economics professor at PUC-Rio (2014) and worked as an intern at Ventor Investimentos. At Itaú, she was a part of the Macro Research sell-side team, developing proprietary indicators, writing regular reports and participating in meetings and conference calls with clients. Laura is now responsible for covering China and metals and energy commodities. She holds a Ph.D. in Economics (2010-2015) and a bachelor degree (2009) from PUC-Rio."));
            team.add(new Equipe("Luiz Gustavo Cherman", "Luiz Cherman has worked with economic and political research for 17 years. He has been with Itaú since 2008, dedicated to analyses for the bank’s institutional clients. Currently, his focus is on Brazilian political analysis and events. Previously, he was a senior economist at Citigroup in Brazil and at Telefonica Group. Luiz graduated in economics from the Pontifical Catholic University of Rio de Janeiro, pursued an MSc in Economic Theory from the University of São Paulo and a specialization in Economic Law from Getulio Vargas Foundation in São Paulo."));
            team.add(new Equipe("Luka Barbosa", "Joined Itaú´s macro team in 2010, and has engaged in multiple challenges inside the department. Spent several years in the sell-side team, with primary focus on fixed income clients in Brazil, U.S., Europe and Asia. This coverage involved macroeconomic analysis and fixed income investment recommendations in the main Latam countries. In the macro research and forecasting department, Luka spent several years focused on fiscal policy, and now is responsible for the coverage of economic activity in Brazil. Luka has an Economics degree from PUC-SP and a master’s degree in Economics from Insper."));
            team.add(new Equipe("Paula Mayumi de Oliveira Yamaguti", "Has been an economist at Itaú Unibanco since April 2013, responsible for sectorial and commodities analysis. Before joining the Economics Team, she worked for five years in other segments of Itaú Unibanco, focusing on credit risk and sectorial analysis. Paula holds a bachelor degree and a master degree in Economics from Insper."));
            team.add(new Equipe("Pedro Castanheira Schneider", "Pedro Schneider has been an economist in Itaú since July 2014. Started as a trainee when was responsible for Japan's analysis, expanded the coverage of the global macroeconomic aggregates and was assistant economist in the commodities coverage. Pedro is now the responsible for the analysis of Brazil's fiscal policy with focus on forecasts for the primary result and public debt. Pedro holds a master degree on economics from USP."));
            team.add(new Equipe("Pedro Victor Renault", "Senior economist working at Itaú since 2012, Pedro holds a bachelor in Economics from UFMG and a master’s degree from Universitat Pompeu Fabra. He is currently in the Sell Side team, responsible for covering institutional and corporate clients. Before that, he worked on the modeling of alternative and stress scenarios, inflation and monetary policy forecasting."));
            team.add(new Equipe("Roberto Prado", "Is responsible for analyzing developed economies, focusing on the U.S. and Europe. He has studied these economies since 2007, when he joined Itaú. Mr. Prado has developed short and medium-term models for key economic variables for the U.S. and Europe. His main research interests are monetary policy, international economics and economic history. He holds a master’s degree in Economics from EESP/FGV-SP."));
        } else {
            team = new ArrayList<Equipe>();
            team.add(new Equipe("Mario Mesquita", "Dr. Mario Mesquita é o economista-chefe do Itaú Unibanco, maior banco do setor privado do Brasil. Mário Mesquita, tem doutorado em economia pela Universidade de Oxford e foi sócio no Banco Brasil Plural, diretor de Política Econômica no Banco Central do Brasil, economista-chefe do ABN AMRO para Brasil e América Latina, diretor de economia da FEBRABAN (Federação Brasileira de Bancos) e atuou também no FMI."));
            team.add(new Equipe("Alexandre Gomes Da Cunha", "Juntou-se à área econômica do Itaú Unibanco em Agosto de 2016. É um dos responsáveis pela análise da atividade econômica do Brasil e, anteriormente, atuou na cobertura de commodities agrícolas. Alexandre é formando em economia pelo Insper."));
            team.add(new Equipe("André Cardoso Barbeiro Matcin", "André Matcin é formado em economia pelo Insper e mestrando em economia pela mesma instituição. Ingressou na pesquisa econômica do Itaú em 2015, e trabalha na equipe de Sell-Side como um dos responsáveis por relatórios, reuniões e conference calls com clientes."));
            team.add(new Equipe("Diego Ciongo", "Faz a cobertura das economias de Argentina, Paraguai e Uruguai com base em Itaú Unibanco Argentina. Antes foi economista senior no Banco Central da Argentina. Diego foi formado pela UNQ e cursou mestrado em economía na UCA."));
            team.add(new Equipe("Felipe Salles", "Economista responsável pela modelagem e elaboração de cenários para a economia brasileira. Foi sócio da Ciano Investimentos (2007-2008) e sócio da Axio Investimentos (2009-2010) responsável pela pesquisa macroeconômica. Graduou-se em economia pela UFRJ. Obteve seu mestrado em economia pela PUC-Rio e cursou o programa de doutorado em economia na LSE."));
            team.add(new Equipe("Fernando M. Gonçalves", "Possui doutorado em economia pela Universidade da Califórnia, em Berkeley, mestrado em Economia pela Fundação Getulio Vargas e graduação em Engenharia de Produção pela Universidade Federal do Rio de Janeiro. Antes de se juntar ao time do Itaú, Fernando foi chefe de Pesquisa Econômica da Vinci Partners, atuou em outras duas gestoras de recursos brasileiras – JGP e Ventor Investimentos – e foi economista do Fundo Monetário Internacional (FMI). Fernando também foi professor do Mestrado Profissional em Economia e Finanças da PUC-RJ em 2015 e 2016. Sua vasta experiência abrange a cobertura das economias brasileira e internacional, incluindo diversas apresentações e road shows para clientes institucionais. Atualmente ele é responsável pela área de Sell Side no time de pesquisa econômica do Itaú."));
            team.add(new Equipe("Guilherme B. Martins", "Dr. Martins é economista do Itaú Unibanco desde 2011. Guilherme possui Ph.D. em economia pela Columbia University. É responsável pela cobertura de economia para a tesouraria institucional do Itaú Unibanco e pela análise de economias internacionais excluindo América Latina. Anteriormente, era baseado em Londres e responsável pela análise macroeconômica da Europa. Trabalhou também como estrategista para mercados emergentes no Deutsche Bank em Nova Iorque, na área de banco de investimento do Itaú BBA e como administrador de fundos de renda fixa no Unibanco Asset Management."));
            team.add(new Equipe("Igor Barreto Rose", "Igor Rose ingressou na equipe de pesquisa econômica do Itaú BBA em 2018, integrando a equipe de economistas do Sell-Side como um dos responsáveis por estudos, relatórios, reuniões e conference calls com clientes. Possui mestrado e bacharelado em economia pela Universidade de São Paulo e experiência no mercado financeiro e no setor real."));
            team.add(new Equipe("João Pedro Bumachar Resende", "É responsável pela cobertura das economias da América Latina, exceto Brasil. É formado em administração de empresas pela FGV-SP (2003) e mestre em economia pela PUC-RJ (2006). Trabalhou na área econômica do Banco BBM por dois anos, antes de ingressar no Unibanco, também na área econômica, em outubro de 2008."));
            team.add(new Equipe("Juan C. Barboza", "É responsável pela cobertura de Argentina, Paraguai e Uruguai com base em Itaú Unibanco Argentina. Antes, foi Gerente principal de administração de reservas no Banco Central de la República Argentina. Iniciou sua carreira no Ministério de Economia onde desenvolveu diversas atividades com destaque para Subsecretario de Financiamento, Representante Financeiro para Europa em Londres e Diretor de informações financeiras. Juan é formado em economia pela universidade de Buenos Aires e com mestrado pela Universidade de CEMA, cursou também o programa executivo de finanças da London Business School."));
            team.add(new Equipe("Julia Passabom Araujo", "Julia Passabom Araujo possui doutorado em economia pela Universidade de São Paulo (USP), além de mestrado e graduação pela mesma instituição. No Itaú é responsável pela projeção e análise de dados de inflação. Anteriormente, trabalhou no M Safra (2016-2017) sendo responsável por projeções de inflação para o Brasil e análise de economias na Zona do Euro. Trabalhou também no Banco Fator (2014-2016), atuando como analista de atividade e de inflação para Brasil e economias do G10, e foi professora assistente no curso de macroeconomia do Insper (2014-2018)."));
            team.add(new Equipe("Julia Wrobel Folescu Gottlieb", "É economista do Itaú Unibanco desde maio de 2014, responsável pela análise de contas externas e taxa de câmbio. Antes, foi analista no Chief Economist Office de América Latina do Banco Mundial em Washingto DC (2013–2014) e estagiária da Galanto Consultoria (2008-2010). É formada em economia pela PUC-Rio (2010) e mestre em economia também pela PUC-Rio (2013)."));
            team.add(new Equipe("Julio Cesar Ruiz Alvarez", "É responsável pela cobertura das economias de México e Peru. Antes atuou no escritório do economista-chefe do Ministério da Fazenda do México em diversas posições, como vice-diretor geral de Política Econômica, diretor de Planejamento Financeiro e chefe da área de Relações com Investidores. Iniciou a carreira como economista no banco central do México (Banxico). Tem graduação em Economia pelo ITAM (México) e mestrado em Administração Pública (MPA) com especialização em Política Econômica e Finanças Internacionais pela Columbia University (Nova York )."));
            team.add(new Equipe("Laura Candido de Souza Pitta", "É economista do Itaú Unibanco desde março de 2015. Antes, lecionou na graduação da PUC-Rio (2014) e foi estagiária na Ventor Investimentos (2009). No Itáu, foi integrante na equipe de Sell-Side da Pesquisa Macroeconômica, sendo uma das responsáveis pelo desenvolvimento de indicadores proprietários, por escrever relatórios regulares e reunião/conference calls com clientes. A partir de 2017, Laura passou a ser responsável pela análise de China e commodities energéticas e metálicas. É formada em economia pela PUC-Rio (2009) e doutora em economia também pela PUC-Rio (2015)."));
            team.add(new Equipe("Luiz Gustavo Cherman", "Luiz Cherman trabalha com pesquisa econômica e política há 17 anos. Está no Itaú desde 2008, dedicando-se às análises para os clientes institucionais do banco. Atualmente, concentra-se no acompanhamento da conjuntura e dos eventos políticos. Anteriormente, foi economista-senior do Citigroup no Brasil e do Grupo Telefônica. Luiz graduou-se em Economia pela Pontifícia Universidade Católica do Rio de Janeiro, cursou o mestrado em Teoria Econômica pela Universidade de São Paulo, e a especialização em Direito Econômico pela Fundação Getúlio Vargas de São Paulo."));
            team.add(new Equipe("Luka Barbosa", "Passou a integrar a equipe econômica do Itaú em 2010, e já desempenhou múltiplas funções dentro da área. Passou diversos anos no sell-side, com foco principal nos clientes de renda fixa no Brasil, Estados Unidos, Europa e Ásia. Esta posição envolveu análise macroeconômica e recomendações de investimento em renda fixa nos principais países da América Latina. No núcleo de conjuntura, Luka passou diversos anos focado na cobertura da política fiscal, e hoje é responsável pela cobertura de atividade econômica no Brasil. Luka é economista formado pela PUC-SP e mestre em economia pelo Insper."));
            team.add(new Equipe("Paula Mayumi de Oliveira Yamaguti", "É economista do Itaú desde abril de 2013, onde é responsável pela análise setorial e de commodities. Antes de se juntar à equipe de Pesquisa Macroeconômica, trabalhou por cinco anos em outras áreas do Itaú Unibanco, com foco em risco de crédito e análise setorial. Paula possui graduação e mestrado em economia pelo Insper."));
            team.add(new Equipe("Pedro Castanheira Schneider", "É economista do Itaú desde julho de 2014. Inicialmente trainee, foi responsável pela analise de Japão, ampliou a cobertura dos agregados macroeconômicos globais, além de ter sido economista assistente de commodities. Atualmente, é responsável pela análise de política fiscal no Brasil, com foco em projeções do resultado primário e da dívida pública. Pedro é mestre em economia pela USP e bacharel em economia pela UFRJ."));
            team.add(new Equipe("Pedro Victor Renault", "Pedro Victor Renault é economista sênior e trabalha na pesquisa econômica do Itaú desde 2012. Formado em economia pela Universidade Federal de Minas Gerais e mestre em economia pela Universitat Pompeu Fabra, é responsável pela cobertura de clientes institucionais e corporativos, realizando reuniões, conference calls e publicação de relatórios para o mercado. Anteriormente, trabalhou na elaboração de cenários alternativos e de stress, projeções de inflação de médio prazo e análise de política monetária."));
            team.add(new Equipe("Roberto Prado", "É responsável pela análise de economias desenvolvidas, com foco principal em EUA e Europa. Estuda os temas desde 2007, quando se juntou ao Itaú. Roberto tem desenvolvido modelos de curto e médio prazo para as principais variáveis econômicas norte-americanas e europeias. Seus interesses principais são política monetária, economia internacional e história econômica. É mestre em economia pela EESP/FGV-SP."));
        }
    }

    /*
    private Task taskLoadSobreEquipe() {
        return new BaseTask() {

            private String url;

            @Override
            public void execute() {
                url = getString(R.string.sobre_equipe);
            }

            @SuppressLint("SetJavaScriptEnabled")
            @Override
            public void updateView() {
                WebViewLoader.with(webView)
                        .setJavaScriptEnabled(true)
                        .setZoomControls(true)
                        .setLoadCallback(onLoad)
                        .loadFromURl(url);

                trackEventScreenView(GoogleAnalytics.MAIS, "equipe");
            }

            @Override
            public boolean onError(Throwable e) {
                progressBar.setVisibility(View.GONE);
                return super.onError(e);
            }

            @Override
            public boolean onErrorNetworkUnavailable() {
                progressBar.setVisibility(View.GONE);
                return super.onErrorNetworkUnavailable();
            }
        };
    }

    private WebViewLoader.LoadCallback onLoad = new WebViewLoader.LoadCallback() {

        @Override
        public void OnPageStarted() {
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        public void OnError(Exception e) {
            progressBar.setVisibility(View.GONE);
        }

        @Override
        public void OnFinish() {
            progressBar.setVisibility(View.GONE);
        }
    };
    */
}
