package br.livetouch.livecom.itaubba.activity;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.RecyclerView;

import java.util.List;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.adapter.CategoriaInteresseAdapter;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;
import br.livetouch.utils.ListUtils;

/**
 * Created by livetouch on 26/07/17.
 */

public class CategoriasInteresseActivity extends BaseActivity {

    List<Categoria> categorias;
    RecyclerView recycler;
    CategoriaInteresseAdapter adapter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_categorias_interesse);

        ActionBar actionBar = setupToolbar();
        if (actionBar != null) {
            actionBar.setTitle(R.string.categorias_de_interese);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        recycler = (RecyclerView) findViewById(R.id.recycler);
        setupRecyclerView(recycler);

    }

    @Override
    protected void onResume() {
        super.onResume();

        if (ListUtils.isEmpty(categorias)) {
            startTask(taskGetCategorias(), R.id.progress);
        }
    }

    private Task taskGetCategorias() {
        return new BaseTask() {
            @Override
            public void execute() throws Exception {
                categorias = ItaubbaService.getCategorias(getContext());
            }

            @Override
            public void updateView() {
                if (ListUtils.isNotEmpty(categorias)){
                    adapter = new CategoriaInteresseAdapter(getContext(),categorias);
                    recycler.setAdapter(adapter);
                }
            }
        };
    }
}
