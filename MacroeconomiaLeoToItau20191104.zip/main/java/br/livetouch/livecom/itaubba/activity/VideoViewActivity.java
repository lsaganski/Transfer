package br.livetouch.livecom.itaubba.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.VideoView;

import com.crashlytics.android.Crashlytics;

import java.io.IOException;

import br.livetouch.exception.DomainException;
import br.livetouch.livecom.activity.LivecomActivity;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.livecom.task.LivecomTask;
import br.livetouch.livecom.utils.DownloadManagerUtil;
import br.livetouch.task.Task;
import br.livetouch.utils.AlertErrorUtils;
import br.livetouch.utils.StringUtils;

public class VideoViewActivity extends LivecomActivity {
    private Arquivo arquivo;
    private Uri uri;
    private VideoView videoView;
    private MediaPlayer mediaPlayer;
    private int pos = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(br.livetouch.livecom.lib.R.layout.activity_video_view);

        ActionBar actionBar = setupToolbar();

        Intent intent = getIntent();
        if (intent != null) {
            arquivo = (Arquivo) intent.getSerializableExtra(Arquivo.TAG);
            if (arquivo != null && StringUtils.isNotEmpty(arquivo.nome)){
                setTitle(arquivo.nome);
            }
        }

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        videoView = findViewById(br.livetouch.livecom.lib.R.id.videoView);
        mediaPlayer = new MediaPlayer();

        MediaController controller = new MediaController(this);
        videoView.setMediaController(controller);
        controller.setAnchorView(videoView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startTaskOffline(taskLoadVideo(), false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(br.livetouch.livecom.lib.R.menu.menu_video_view, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == br.livetouch.livecom.lib.R.id.baixar) {
            DownloadManagerUtil.startDownloadManager(arquivo);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setFullScreen();
        } else {
            setNormalScreen();
        }
        super.onConfigurationChanged(newConfig);
    }

    private void setNormalScreen() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().show();
            this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
            this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    private void setFullScreen() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
            this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (videoView.isPlaying()) {
            outState.putInt("pos", videoView.getCurrentPosition());
            videoView.pause();
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        pos = savedInstanceState.getInt("pos");
    }

    private Task taskLoadVideo() {
        return new LivecomTask() {

            @Override
            public void execute() throws DomainException {
                if (arquivo != null) {
                    uri = ItaubbaService.getArquivoUri(getContext(), arquivo);
                }
            }

            @Override
            public void updateView() {
                if (uri != null && videoView != null) {
                    try {
                        videoView.setVideoURI(uri);
                        videoView.setOnCompletionListener(OnCompletionListener());
                        videoView.setOnPreparedListener(OnPrepareVideo());
                        videoView.setOnErrorListener(OnErroListener());
                    } catch (Exception e) {
                        Crashlytics.logException(e);
                    }
                }
            }

            @Override
            public boolean onError(Throwable e) {
                AlertErrorUtils.alert(getActivity(), e.getMessage());
                return true;
            }
        };
    }

    private MediaPlayer.OnCompletionListener OnCompletionListener() {
        return new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                try {
                    videoView.seekTo(0);
                } catch (Exception e) {
                    Crashlytics.logException(e);
                }
            }
        };
    }

    private MediaPlayer.OnErrorListener OnErroListener() {
        return new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int i, int i1) {
                mediaPlayer = mp;
                switch (i1) {
                    case MediaPlayer.MEDIA_ERROR_IO:
                        try {
                            pos = mediaPlayer.getCurrentPosition();
                            mediaPlayer.stop();
                            mediaPlayer.reset();
                            mediaPlayer.setDataSource(arquivo.url);
                            mediaPlayer.prepare();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        break;
                }
                return true;
            }
        };
    }

    private MediaPlayer.OnPreparedListener OnPrepareVideo() {
        return new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                try {
                    goneView(br.livetouch.livecom.lib.R.id.progressVideo);
                    if (mediaPlayer != null) {
                        mediaPlayer.start();
                        mediaPlayer.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                            @Override
                            public boolean onInfo(MediaPlayer mediaPlayer, int i, int i1) {
                                if (i == MediaPlayer.MEDIA_INFO_BUFFERING_START)
                                    showView(br.livetouch.livecom.lib.R.id.progressVideo);
                                if (i == MediaPlayer.MEDIA_INFO_BUFFERING_END)
                                    goneView(br.livetouch.livecom.lib.R.id.progressVideo);
                                return false;
                            }
                        });
                    }
                } catch (Exception e) {
                    Crashlytics.logException(e);
                }
            }
        };
    }

    private void playVideoFromPos(int pos) {
        videoView.seekTo(pos);
        videoView.start();
    }

    @Override
    public void onPause() {
        if (videoView != null) {
            pos = videoView.getCurrentPosition();
            videoView.pause();
        }
        super.onPause();
    }
}

