package br.livetouch.livecom.itaubba.activity;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.RecyclerView;
import android.widget.CompoundButton;

import java.util.List;

import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.adapter.IdiomaAdapter;
import br.livetouch.livecom.itaubba.domain.Idioma;
import br.livetouch.livecom.itaubba.domain.event.BusEvent;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.livecom.itaubba.utils.LocaleUtils;
import br.livetouch.livecom.itaubba.utils.PrefsUtil;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;
import br.livetouch.utils.ListUtils;

/*
 * Created by livetouch on 02/08/17.
 */

public class ConfiguracoesActivity extends BaseActivity {

    RecyclerView recycler;
    IdiomaAdapter adapter;
    List<Idioma> idiomas;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_configuracoes);

        ActionBar actionBar = setupToolbar();
        if (actionBar != null) {
            actionBar.setTitle(R.string.configuracoes);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

//        SwitchCompat btnSwitch = ((SwitchCompat)findViewById(R.id.btnSwitch));
//        btnSwitch.setOnCheckedChangeListener(onChangeeSwitch());
//
//        boolean isNotificationEnabled = PrefsUtil.getNotificationEnabled();
//        if(isNotificationEnabled){
//            btnSwitch.setChecked(isNotificationEnabled);
//        }

        recycler = (RecyclerView) findViewById(R.id.recycler);
        setupRecyclerView(recycler);

    }

    @Override
    protected void onResume() {
        super.onResume();

        if (ListUtils.isEmpty(idiomas)){
            startTaskOffline(taskGetIdiomas(), R.id.progress);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        overridePendingTransition(0, 0);
    }

    private CompoundButton.OnCheckedChangeListener onChangeeSwitch() {
        return new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                PrefsUtil.setNotificationEnabled(b);
            }
        };
    }

    private Task taskGetIdiomas() {
        return new BaseTask() {
            @Override
            public void execute() throws Exception {
                idiomas = ItaubbaService.getIdiomas(getContext());
            }

            @Override
            public void updateView() {
                if (ListUtils.isNotEmpty(idiomas)){
                    adapter = new IdiomaAdapter(getContext(), idiomas, onClickIdioma());
                    recycler.setAdapter(adapter);
                }

                trackEventScreenView(GoogleAnalytics.MAIS, "configuracoes");

            }
        };
    }

    private IdiomaAdapter.IdiomaAdapterCallback onClickIdioma() {
        return new IdiomaAdapter.IdiomaAdapterCallback() {
            @Override
            public void onClickIdioma(Idioma idioma) {
                adapter.notifyDataSetChanged();

                LocaleUtils.setPrefsLanguage(idioma.code);
                postBus(new BusEvent.UpdateLanguageEvent());

                startActivity(getIntent());
                finish();
            }
        };
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}
