package br.livetouch.livecom.itaubba.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.text.Html;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.listener.OnLoadCompleteListener;
import com.github.barteksc.pdfviewer.listener.OnPageChangeListener;
import com.github.barteksc.pdfviewer.listener.OnPageScrollListener;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import br.livetouch.livecom.activity.LivecomActivity;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;
import br.livetouch.utils.AnimationUtils;
import br.livetouch.utils.BrowserUtils;

public class PdfActivity extends LivecomActivity {

    private String urlFile;
    private String fileName;
    private PDFView pdfView;
    private int mPage = 0;
    private LinearLayout lPagesCount;
    private TextView tCurrentPage;
    private TextView tTotalPage;
    private CountDownTimer timer;
    private int totalPages;
    private Arquivo arquivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf);

        setupToolbar();

        pdfView = findViewById(br.livetouch.livecom.lib.R.id.pdfView);
        pdfView.setEnabled(false);

        lPagesCount = findViewById(br.livetouch.livecom.lib.R.id.lPagesCount);
        tCurrentPage = findViewById(br.livetouch.livecom.lib.R.id.tCurrentPage);
        tTotalPage = findViewById(br.livetouch.livecom.lib.R.id.tTotalPage);

        Intent intent = getIntent();
        if (intent != null) {
            arquivo = (Arquivo) intent.getSerializableExtra(Arquivo.TAG);
            if (arquivo != null) {
                urlFile = arquivo.url;
                fileName = arquivo.getNomeArquivo();
            }
        }

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            String smalltext = String.format(getContext().getString(br.livetouch.livecom.lib.R.string.small_text), fileName);
            actionBar.setTitle(Html.fromHtml(smalltext));
        }

        timer = getTimer();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mPage == 0) {
            startTask(taskShowPdf(), R.id.progressLoad);
        }
    }

    private CountDownTimer getTimer() {
        return new CountDownTimer(5000, 1000) {

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {
                AnimationUtils.alphaAnimOut(lPagesCount, 500);
                lPagesCount.setVisibility(View.GONE);
            }

        };
    }

    private View.OnClickListener onClickAbrirBrowser() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BrowserUtils.openUrl(getContext(), urlFile);
            }
        };
    }

    private Task taskShowPdf() {
        return new BaseTask() {
            private File file = null;
            private InputStream inputStream;

            @Override
            public void preExecute() throws Exception {
                super.preExecute();
                goneView(R.id.lErro);
            }

            @Override
            public void execute() throws IOException {
                if (arquivo != null){
                    inputStream = new URL(arquivo.url).openStream();
                }
            }

            @Override
            public void updateView() {
                pdfView.fromStream(inputStream)
                        .enableSwipe(true) // allows to block changing pages using swipe
                        .swipeHorizontal(false)
                        .enableDoubletap(true)
                        .defaultPage(mPage)
                        .spacing(16)
                        .onLoad(onLoadComplete())
                        .onPageChange(onPageChange())
                        .onPageScroll(onPageScroll())
                        .onError(t -> {
                            t.printStackTrace();
                            showView(R.id.lErro);
                        })
                        .load();
            }

            @NonNull
            private OnPageScrollListener onPageScroll() {
                return new OnPageScrollListener() {
                    @Override
                    public void onPageScrolled(int page, float positionOffset) {
                        mPage = page;
                        tCurrentPage.setText(String.valueOf(page+1));
                        showPageCounter();
                    }
                };
            }

            @NonNull
            private OnPageChangeListener onPageChange() {
                return new OnPageChangeListener() {
                    @Override
                    public void onPageChanged(int page, int pageCount) {
                        if (totalPages == 0) {
                            totalPages = pageCount;
                        }
                        tCurrentPage.setText(String.valueOf(page+1));
                        showPageCounter();
                    }
                };
            }

            @NonNull
            private OnLoadCompleteListener onLoadComplete() {
                return new OnLoadCompleteListener() {
                    @Override
                    public void loadComplete(int nbPages) {
                        tTotalPage.setText(String.valueOf(nbPages));
                        pdfView.setEnabled(true);
                        showPageCounter();
                    }
                };
            }

            @Override
            public boolean onError(Throwable e) {
                showView(R.id.lErro);
                return true;
            }
        };
    }

    private void showPageCounter() {
        if (lPagesCount.getVisibility() == View.GONE) {
            getTimer().cancel();
            AnimationUtils.alphaAnimIn(lPagesCount, 500, new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    getTimer().start();
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
            lPagesCount.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setFullScreen();
        } else {
            setNormalScreen();
        }
        super.onConfigurationChanged(newConfig);
    }

    private void setNormalScreen() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().show();
            this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
            this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    private void setFullScreen() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
            this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        }
    }
}

