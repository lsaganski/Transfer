package br.livetouch.livecom.itaubba.activity;

import android.arch.lifecycle.Lifecycle;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.util.Pair;
import android.view.View;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;
import com.squareup.otto.Subscribe;

import br.livetouch.exception.DomainException;
import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.domain.SubCategoria;
import br.livetouch.livecom.itaubba.domain.event.BusEvent;
import br.livetouch.livecom.itaubba.fragment.BaseFragment;
import br.livetouch.livecom.itaubba.fragment.CategoriasFragment;
import br.livetouch.livecom.itaubba.fragment.MenuMaisFragment;
import br.livetouch.livecom.itaubba.fragment.PostsFragment;
import br.livetouch.livecom.itaubba.fragment.SelecionarIdiomaFragment;
import br.livetouch.livecom.itaubba.fragment.TutorialFragment;
import br.livetouch.livecom.itaubba.fragment.midias.MediaFragment;
import br.livetouch.livecom.itaubba.utils.BundleUtils;
import br.livetouch.livecom.itaubba.utils.PrefsUtil;
import br.livetouch.utils.LogUtil;
import br.livetouch.utils.ThreadUtils;

/*
 * Created by empresa on 19/07/2017.
 */

public class HomeActivity extends BaseActivity implements SelecionarIdiomaFragment.callback, TutorialFragment.callback {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ActionBar actionBar = setupToolbar();
        if (actionBar != null) {
            actionBar.setTitle(R.string.home_toolbar_title);
        }

        BottomNavigationViewEx bottomNav = findViewById(R.id.navigation);
        bottomNav.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener());
        bottomNav.setIconSize(21, 21);
        bottomNav.enableAnimation(false);
        bottomNav.enableItemShiftingMode(false);
        bottomNav.enableShiftingMode(false);

        // Primeiro item de menu selecionado
        if (savedInstanceState == null) {
            showPostsfragment();
        }

        startTutorial();

        registerBus(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        overridePendingTransition(0, 0);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener onNavigationItemSelectedListener() {
        return item -> {
            PostInfo postInfo = new PostInfo();
            int itemId = item.getItemId();
            item.setChecked(true);
            switch (itemId) {
                case R.id.menu_inicio:
                    trackEvent(GoogleAnalytics.CATEGORY_APP_MENU, GoogleAnalytics.CLICK_NAVEGACAO, GoogleAnalytics.HOME_PAGE);
                    showPostsfragment();
                    break;
                case R.id.menu_midias:
                    updateFragment(new MediaFragment());
                    break;
                case R.id.menu_categorias:
                    trackEvent(GoogleAnalytics.CATEGORY_APP_MENU, GoogleAnalytics.CLICK_NAVEGACAO, GoogleAnalytics.CATEGORIAS);
                    updateFragment(new CategoriasFragment());
                    break;
                case R.id.menu_favoritos:
                    trackEvent(GoogleAnalytics.CATEGORY_APP_MENU, GoogleAnalytics.CLICK_NAVEGACAO, GoogleAnalytics.BOOKMARKS);
                    postInfo.setMenuFavorito(true);
                    postInfo.setTitle(getString(R.string.favoritos_toolbar_title));
                    updateFragment(new PostsFragment(), new Pair<>(PostInfo.KEY, postInfo));
                    break;
                case R.id.menu_mais:
                    trackEvent(GoogleAnalytics.CATEGORY_APP_MENU, GoogleAnalytics.CLICK_NAVEGACAO, GoogleAnalytics.MAIS);
                    updateFragment(new MenuMaisFragment());
                    break;
            }
            return false;
        };
    }

    private void showPostsfragment() {
        PostInfo postInfo = new PostInfo();
        postInfo.setMenuHome(true);
        postInfo.setTitle(getString(R.string.home_toolbar_title));
        updateFragment(new PostsFragment(), new Pair<>(PostInfo.KEY, postInfo));
    }

    private void updateFragment(BaseFragment fragment) {
        updateFragment(fragment, null);
    }

    private void updateFragment(BaseFragment fragment, Pair<String, Object> arg) {
        Bundle bundle = new Bundle();
        fillBundle(arg, bundle);

        if (fragment != null) {
            fragment.setArguments(bundle);

            // Limpo fragments no backstack.
            clearBackStack();

            // Carrego o fragment
            replaceFragment(R.id.content_frame, fragment, fragment.getClass().getSimpleName());
        }
    }

    private void fillBundle(Pair<String, Object> arg, Bundle bundle) {
        if (arg != null){
            BundleUtils.fillBundle(bundle, arg);
        }
    }

    //Inicia tutorial com a tela de Idioma
    private void startTutorial() {
        boolean tutorialCompleted = PrefsUtil.isTutorialCompleted();
        if (!tutorialCompleted) {
            replaceFragment(R.id.fragLayoutTutorial, new SelecionarIdiomaFragment());
        }
    }

    private void showTutorialFragment() {
        replaceFragment(R.id.fragLayoutTutorial, new TutorialFragment());
    }

    @Override
    public void onClickIniciarTutorial() {
        showTutorialFragment();
    }

    @Override
    public void onClickCloseTutorial() {
        getSupportFragmentManager().beginTransaction().remove(getSupportFragmentManager().findFragmentById(R.id.fragLayoutTutorial)).commit();
        PrefsUtil.setTutorialCompleted(true);
    }

    // Evento chamado no click de categorias na tela CategoriasFragment
    // Evento chamado no click das sugestoes da busca
    @Subscribe
    public void onBusFiltroPostCategoriaEvent(BusEvent.FiltroPostEvent event) {
        try {
            validateLifecycle();

            BaseFragment baseFragment = null;
            Bundle bundle = new Bundle();
            PostInfo postInfo = new PostInfo();

            Categoria categoria = event.categoria;
            SubCategoria subCategoria = event.subCategoria;
            PostInfo info = event.postInfo;

            if (info != null) {
                postInfo = info;
                baseFragment = new PostsFragment();
            } else if (categoria != null) {
                postInfo.setMenuCategorias(true);
                postInfo.setCategoria(categoria);
                baseFragment = new PostsFragment();
            } else if (subCategoria != null) {
                if (subCategoria.hasEditoria()) {
                    postInfo.setSubCategoria(subCategoria);
                    baseFragment = new CategoriasFragment();
                } else {
                    postInfo.setMenuCategorias(true);
                    postInfo.setSubCategoria(subCategoria);
                    baseFragment = new PostsFragment();
                }
            }

            fillBundle(new Pair<>(PostInfo.KEY, postInfo), bundle);

            if (baseFragment != null) {
                baseFragment.setArguments(bundle);
                addFragment(baseFragment);
            }
        } catch (Exception e) {
            LogUtil.logError(e.getMessage(), e);
        }
    }

    private void validateLifecycle() throws DomainException {
        Lifecycle lifecycle = this.getLifecycle();
        boolean isResumed = lifecycle.getCurrentState().isAtLeast(Lifecycle.State.RESUMED);
        if (!isResumed){
            throw new DomainException("Activity destroyed");
        }
    }

    @Subscribe
    public void onBusStartTutorial(BusEvent.StartTutorialEvent event) {
        showTutorialFragment();
    }

    @Subscribe
    public void onUpdateLanguageEvent(BusEvent.UpdateLanguageEvent event) {
        recreate();
    }

    // RadioButton de selecao de idioma
    public void onRadioButtonClicked(View view) {
        ThreadUtils.start(new Runnable() {
            @Override
            public void run() {
                ThreadUtils.sleep(250);
                startActivity(getIntent());
                finish();
            }
        });
    }

    @Override
    protected void onActionBarHomePressed() {
        onBackPressed();
    }

    @Override
    public void onBackPressed() {
        if (hasTutorial()) {
            onClickCloseTutorial();
        } else {
            super.onBackPressed();
        }
    }

    private boolean hasTutorial() {
        Fragment fragmentById = getSupportFragmentManager().findFragmentById(R.id.fragLayoutTutorial);
        return fragmentById != null;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterBus(this);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}
