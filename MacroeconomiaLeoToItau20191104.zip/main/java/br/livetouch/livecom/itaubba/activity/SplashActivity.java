package br.livetouch.livecom.itaubba.activity;

import android.content.Intent;
import android.os.Bundle;

import com.crashlytics.android.Crashlytics;
import com.google.firebase.analytics.FirebaseAnalytics;

import br.livetouch.livecom.domain.User;
import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.ItaubbaAplication;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;
import br.livetouch.utils.DialogUtis;
import br.livetouch.utils.NetworkUtils;
import br.livetouch.utils.StringUtils;

public class SplashActivity extends BaseActivity {

    private Intent deepLinkIntent;
    private FirebaseAnalytics firebaseAnalytics;

    private String login;
    private String senha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        firebaseAnalytics = FirebaseAnalytics.getInstance(getContext());

        login = User.getLoginPrefs();
        senha = User.getSenhaPrefs();

        boolean autoLogin = isCheckAutoLogin();
        if (autoLogin){
            goneView(R.id.imgSplash);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        analyticsTrackEvent();
        showHomeActivity();
//        if (NetworkUtils.isNetworkAvailable(this)) {
//            startTask(taskLogin(), R.id.progress);
//        } else {
//            showConnectionErrorDialog();
//        }
    }

    private boolean isCheckAutoLogin() {
        return StringUtils.isNotEmpty(login) && StringUtils.isNotEmpty(senha);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        String action = intent.getAction();
        String data = intent.getDataString();
        if (Intent.ACTION_VIEW.equals(action) && data != null && hasPostByIntent(intent)) {
            deepLinkIntent = intent;
        }
    }

    private void showConnectionErrorDialog() {
        String msg = getString(R.string.msg_erro_rede);
        DialogUtis.alertDialogConfirm(this, msg, "Ok", this::finish, "", null);
    }

    private Task taskLogin() {
        return new BaseTask() {
            User user;

            @Override
            public void execute() throws Exception {
                user = ItaubbaService.login(getContext());
            }

            @Override
            public void updateView() {
                if (user != null){
                    ItaubbaAplication.getInstance().setUserLogado(user);
                    showHomeActivity();
                }
            }

            @Override
            public boolean onError(Throwable e) {
                Crashlytics.logException(e);
                showAlertAndFinish(e);
                return true;
            }
        };
    }

    private void analyticsTrackEvent() {
        trackEventScreenView(GoogleAnalytics.PRE_HOME);
        firebaseTrackEventScreen(firebaseAnalytics, GoogleAnalytics.PRE_HOME);
    }

    private void showHomeActivity() {

        onNewIntent(getIntent());

        if (deepLinkIntent != null){
            handleIntent(deepLinkIntent, PostActivity.class);
        } else {
            show(HomeActivity.class);
            finish();
        }
    }
}
