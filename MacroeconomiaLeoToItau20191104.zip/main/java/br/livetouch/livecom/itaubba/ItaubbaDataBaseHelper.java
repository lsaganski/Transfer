package br.livetouch.livecom.itaubba;

import android.database.sqlite.SQLiteDatabase;

import java.util.Arrays;
import java.util.List;

import br.livetouch.db.DatabaseHelper;
import br.livetouch.db.Entity;
import br.livetouch.db.SqlUtils;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.domain.Destaque;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.Post;

/*
 * Created by empresa on 06/09/2017.
 */

public class ItaubbaDataBaseHelper extends DatabaseHelper {

    public List<Long> postFavoritosIds;
    public List<Long> postLidosIds;

    ItaubbaDataBaseHelper() {
        super("itaubba.sqlite", 8);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        List<String> sql = SqlUtils.getSqlCreateDatabase();
        SqlUtils.execSQL(db, sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (newVersion > 5) {
            executeCreateTableSQL(db, Destaque.class);
            executeSQL(db, String.valueOf("ALTER TABLE " + SqlUtils.toSQLName(Categoria.class) + " ADD COLUMN " + "ID_PAI" + " INTEGER"));
            executeSQL(db, String.valueOf("ALTER TABLE " + SqlUtils.toSQLName(Post.class) + " ADD COLUMN " + "CURRENT_TIMESTAMP" + " INTEGER"));
        } else {
            // V.5
            // DROP
            List<String> sql = SqlUtils.getSqlDropDatabase();
            SqlUtils.execSQL(db, sql);

            // CREATE
            sql = SqlUtils.getSqlCreateDatabase();
            SqlUtils.execSQL(db, sql);
        }
    }

    @Override
    public List<Class<? extends Entity>> getDomainClasses() {
        return Arrays.asList(
                Post.class,
                Arquivo.class,
                Destaque.class,
                Categoria.class);
    }

    private synchronized void executeSQL(SQLiteDatabase db, String sql) {
        try {
            SqlUtils.execSQL(db, sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private synchronized void executeCreateTableSQL(SQLiteDatabase db, Class<? extends Entity> table) {
        try {
            String sqlCreateTable = SqlUtils.getSqlCreateTable(table);
            SqlUtils.execSQL(db, sqlCreateTable);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
