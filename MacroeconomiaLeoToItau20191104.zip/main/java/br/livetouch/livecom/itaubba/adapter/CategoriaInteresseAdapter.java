package br.livetouch.livecom.itaubba.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.List;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.utils.PrefsUtil;
import br.livetouch.utils.ListUtils;

/**
 * Created by livetouch on 01/08/17.
 */

public class CategoriaInteresseAdapter extends RecyclerView.Adapter<CategoriaInteresseAdapter.ViewHolder> {

    List<Categoria> list;

    public CategoriaInteresseAdapter(Context context, List<Categoria> list){
        this.list = list;
    }

    @Override
    public CategoriaInteresseAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_categoria_interesse, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CategoriaInteresseAdapter.ViewHolder holder, int position) {
        if (ListUtils.isNotEmpty(list)) {
            Categoria categoria = list.get(position);
            holder.tCategoria.setText(categoria.nome);
            boolean isCategoriaSelecionada = PrefsUtil.isCategoriaInteresse(categoria.getId());
            holder.btnSwitch.setChecked(isCategoriaSelecionada);
            holder.btnSwitch.setOnCheckedChangeListener(onChangeSwitch(categoria));
        }
    }

    private CompoundButton.OnCheckedChangeListener onChangeSwitch(final Categoria categoria) {
        return new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                PrefsUtil.setCategoriaInteresse(categoria.getId(), b);
            }
        };
    }

    @Override
    public int getItemCount() {
        return ListUtils.size(list);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tCategoria;
        SwitchCompat btnSwitch;

        public ViewHolder(View itemView) {
            super(itemView);
            tCategoria = (TextView) itemView.findViewById(R.id.tCategoria);
            btnSwitch = (SwitchCompat) itemView.findViewById(R.id.btnSwitch);
        }
    }
}
