package br.livetouch.livecom.itaubba.adapter;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.crashlytics.android.Crashlytics;

import java.util.List;

import br.livetouch.lib.viewpagerindicator.CirclePageIndicator;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.Post;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.utils.BaseRecyclerViewAdapter;
import br.livetouch.livecom.itaubba.utils.DisplayUtil;
import br.livetouch.livecom.itaubba.utils.ImageUtil;
import br.livetouch.livecom.utils.TextViewUtils;
import br.livetouch.utils.AutoSlideViewPager;
import br.livetouch.utils.ListUtils;
import br.livetouch.utils.StringUtils;

/*
 * Created by livetouch on 08/08/17.
 */

public class PostAdapter extends BaseRecyclerViewAdapter {

    private static final int VIEW_TYPE_DESTAQUE = 1;
    private static final int VIEW_TYPE_CATEGORIAS = 2;
    private static final int VIEW_TYPE_POSTS = 3;
    private static final int VIEW_TYPE_FIM_NOTICIAS = 4;
    private static final int VIEW_TYPE_SEM_NOTICIAS = 5;

    private AutoSlideViewPager autoSlideViewPager;

    private TabLayout.OnTabSelectedListener onTabSelectedListener;
    private PostCallback callback;

    private Context context;
    private List<Post> posts;
    private List<Post> destaques;
    private List<Categoria> categorias;
    private DestaqueAdapter destaqueAdapter;

    private Boolean sliderStarted = false;
    private boolean showCategorias;
    private boolean showDestaque;
    private boolean finishedLoad = false;
    private int extraRowsPostAdapter;
    private boolean isFavoritos = false;
    private boolean isMidias = false;

    public void setFinishedLoad(boolean value) {
        finishedLoad = value;
    }

    public interface PostCallback {
        void onClickFavorito(Post post, ProgressBar progress, int adapterPosition);
        void onClickPost(Post post, int adapterPosition);
        void onClickVideo(Post post, int adapterPosition);
        void openPodCast(String url);
    }

    public PostAdapter(Context context, PostCallback callback, List<Post> posts, @Nullable List<Post> destaques, @Nullable List<Categoria> categorias, boolean isFavoritos, boolean isMidias) {
        super(context, true, PostInfo.PAGE_SIZE);
        this.context = context;
        this.callback = callback;
        this.categorias = categorias;
        this.posts = posts;
        this.destaques = destaques;
        this.showDestaque = ListUtils.isNotEmpty(destaques);
        this.showCategorias = ListUtils.isNotEmpty(categorias);
        this.isFavoritos = isFavoritos;
        this.isMidias = isMidias;
        this.finishedLoad = ListUtils.size(posts) < PostInfo.PAGE_SIZE;
        this.extraRowsPostAdapter = setExtraRowsPostAdapter();
    }

    @Override
    public int getItemViewType(int position) {
        super.getItemViewType(position);
        if (showDestaque && showCategorias) {
            return viewTypeDestaqueCategorias(position);
        } else if (!showDestaque && showCategorias){
            return viewTypePostCategorias(position);
        } else {
            return viewTypePosts(position);
        }
    }

    @Override
    protected void onBindBaseViewHolder(final BaseViewHolder baseViewHolder, final int position) {
        int itemViewType = getItemViewType(position);

        switch (itemViewType) {
            case VIEW_TYPE_DESTAQUE:

                ViewHolderDestaque viewHolderDestaque = (ViewHolderDestaque) baseViewHolder;
                if (destaqueAdapter == null) {
                    destaqueAdapter = new DestaqueAdapter(context, destaques, callback);
                }

                viewHolderDestaque.viewPager.setAdapter(destaqueAdapter);
                viewHolderDestaque.pageView.setViewPager(viewHolderDestaque.viewPager);

                if (ListUtils.isEmpty(destaques) || destaques.size() == 1) {
                    viewHolderDestaque.pageView.setVisibility(View.GONE);
                }

                if (!sliderStarted) {
                    autoSlideViewPager.start();
                    sliderStarted = true;
                }
                break;

            case VIEW_TYPE_CATEGORIAS:

                ViewHolderCategorias holderCategorias = (ViewHolderCategorias) baseViewHolder;
                holderCategorias.tabLayout.addOnTabSelectedListener(getOnTabSelectedListener());
                createTabs(holderCategorias);
                break;

            case VIEW_TYPE_POSTS:

                final ViewHolder holder = (ViewHolder) baseViewHolder;
                if (ListUtils.isNotEmpty(posts)) {

                    int idx = position - extraRowsPostAdapter;
                    Post post = null;

                    try {
                        post = posts.get(idx);
                    }catch (Exception e){
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }

                    if (post != null) {
                        holder.tCategoria.setText(post.getCategoriaNome());
                        holder.tTitulo.setText(post.titulo);

                        if (post.hasVideo()){
                            holder.tResumo.setVisibility(View.GONE);
                            holder.thumbVideoContainer.setVisibility(View.VISIBLE);
                            String urlThumbVideo = post.getThumbVideo();
                            ImageUtil.setImage(getContext(), urlThumbVideo, holder.imgThumb, View.VISIBLE);
                        } else {
                            TextViewUtils.setTextView(holder.tResumo, post.getResumo(), View.GONE);
                            holder.thumbVideoContainer.setVisibility(View.GONE);
                        }

                        holder.podcast.setVisibility(View.GONE);
                        String urlPodCast = post.getUrlPodCast();
                        if (post.isPodcast() && urlPodCast != null) {
                            holder.podcast.setVisibility(View.VISIBLE);
                            holder.podcast.setOnClickListener(v -> {
                                if (callback != null)
                                    callback.openPodCast(urlPodCast);
                            });
                        }

                        holder.tData.setText(post.dateddMMYYYY);

                        // Post favoritado
                        int imgFavorito = post.isfavorito ? R.drawable.icn_favorito_on : R.drawable.icn_favorito_off;
                        holder.imgFavorito.setImageResource(imgFavorito);

                        // Post visualizado
                        if (post.lido){
                            holder.tTitulo.setTextColor(ContextCompat.getColor(context, R.color.warm_grey_three));
                            holder.tCategoria.setTextColor(ContextCompat.getColor(context, R.color.warm_grey_three));
                            holder.imgOlho.setVisibility(View.VISIBLE);
                            holder.podcast.setImageAlpha(128);
                        } else {
                            holder.tTitulo.setTextColor(ContextCompat.getColor(context, R.color.greyish_brown));
                            holder.tCategoria.setTextColor(ContextCompat.getColor(context, R.color.light_navy_blue));
                            holder.imgOlho.setVisibility(View.INVISIBLE);
                            holder.podcast.setImageAlpha(255);
                        }
                    }

                    final Post p = post;
                    holder.thumbVideoContainer.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (callback != null){
                                callback.onClickVideo(p, holder.getAdapterPosition());
                            }
                        }
                    });

                    holder.btnFavorito.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (callback != null) {
                                callback.onClickFavorito(p, holder.progress, holder.getAdapterPosition());
                            }
                        }
                    });

                    holder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (callback != null){
                                callback.onClickPost(p, holder.getAdapterPosition());
                            }
                        }
                    });

                }
                break;

            case VIEW_TYPE_FIM_NOTICIAS:
                break;

            case VIEW_TYPE_SEM_NOTICIAS:
                ViewHolderSemNoticias holderSemNoticias = (ViewHolderSemNoticias) baseViewHolder;

                if (isFavoritos) {
                    holderSemNoticias.tMsg.setText(getContext().getString(R.string.voce_nao_salvou_favoritos));
                } else {
                    holderSemNoticias.tMsg.setText(getContext().getString(R.string.sem_noticias));
                }

                break;
        }
    }

    @Override
    protected BaseViewHolder onCreateBaseViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case VIEW_TYPE_DESTAQUE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.container_destaque, parent, false);
                return new ViewHolderDestaque(context, view);
            case VIEW_TYPE_CATEGORIAS:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_tab_categorias, parent, false);
                return new ViewHolderCategorias(context, view);
            case VIEW_TYPE_POSTS:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_post, parent, false);
                return new ViewHolder(context, view);
            case VIEW_TYPE_FIM_NOTICIAS:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_fim_noticias, parent, false);
                return new ViewHolderFimNoticias(context, view);
            case VIEW_TYPE_SEM_NOTICIAS:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_sem_noticias, parent, false);
                return new ViewHolderSemNoticias(context, view);
        }
        return null;
    }

    @Override
    public int getCount() {
        int countRows = ListUtils.size(posts) + extraRowsPostAdapter;

        if (ListUtils.isEmpty(posts) || finishedLoad) {
            countRows += 1;
        }

        return countRows;
    }

    // add tabs
    private void createTabs(ViewHolderCategorias holderCategorias) {
        int tabCount = holderCategorias.tabLayout.getTabCount();
        if (tabCount == 0 && ListUtils.isNotEmpty(categorias)) {
            for (Categoria c : categorias) {
                if (StringUtils.isNotEmpty(c.nome)) {
                    holderCategorias.tabLayout.addTab(holderCategorias.tabLayout.newTab().setText(c.nome));
                }
            }
        }
    }

    // update posts ao trocar tab
    public void updateAdapter(List<Post> newPosts) {
        int oldSize = this.posts.size();
        this.finishedLoad = false;

        // atualiza lista
        updatePostsList(newPosts);

        if (extraRowsPostAdapter == 0) {
            notifyDataSetChanged();
        } else  {
            if (oldSize > 0) {
                notifyItemRangeRemoved(extraRowsPostAdapter, oldSize);
            } else {
                notifyItemChanged(extraRowsPostAdapter, newPosts);
            }
        }
    }

    private void updatePostsList(List<Post> newPosts) {
        if (posts != null && newPosts != null) {
            this.posts.clear();
            this.posts.addAll(newPosts);
        }
    }

    public void updatePost(Post post, int position) {
        if (post != null) {
            post.updatePostInList(posts);
            int indexOf = extraRowsPostAdapter + position;
            notifyItemChanged(indexOf, post);
        }
    }

    public void notifyAdapterDestaque(int position, Post post) {
        if (destaqueAdapter != null && destaques != null) {
            post.updatePostInList(destaques);
            notifyItemChanged(0, post);
            destaqueAdapter.notifyDataSetChanged();
        } else {
            position = position > 1 ? extraRowsPostAdapter + position : position;
            post.updatePostInList(posts);
            notifyItemChanged(position, post);
        }
    }

    public void removeAt(int position) {
        posts.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, posts.size());
    }

    private int setExtraRowsPostAdapter() {
        int idx = showCategorias && showDestaque ? 2 : 0;
        idx = showCategorias && !showDestaque ? 1 : idx;
        idx = !showCategorias && !showDestaque ? 0 : idx;
        extraRowsPostAdapter = idx;
        return idx;
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);

        // set padding top recycler
        int dpToPixel = DisplayUtil.convertDpToPixel(8);
        if ((showCategorias && showDestaque) || isMidias){
            recyclerView.setPadding(0, 0, 0, 0);
        } else {
            recyclerView.setPadding(0, dpToPixel, 0, 0);
        }
    }

    private int viewTypeDestaqueCategorias(int position) {
        int finidshedModifier = finishedLoad ? 1 : 0;
        if (position == 0) {
            return VIEW_TYPE_DESTAQUE;
        } else if (position == 1) {
            return VIEW_TYPE_CATEGORIAS;
        } else if (ListUtils.isEmpty(posts)) {
            return VIEW_TYPE_SEM_NOTICIAS;
        } else if (position < getCount() - finidshedModifier) {
            return VIEW_TYPE_POSTS;
        } else if (finishedLoad) {
            return VIEW_TYPE_FIM_NOTICIAS;
        } else {
            return 9999;
        }
    }

    private int viewTypePosts(int position) {
        int finidshedModifier = finishedLoad ? 1 : 0;
        if (ListUtils.isEmpty(posts)) {
            return VIEW_TYPE_SEM_NOTICIAS;
        } else if (position < getCount() - finidshedModifier) {
            return VIEW_TYPE_POSTS;
        } else if (finishedLoad) {
            return VIEW_TYPE_FIM_NOTICIAS;
        } else {
            return 9999;
        }
    }

    private int viewTypePostCategorias(int position) {
        int finidshedModifier = finishedLoad ? 1 : 0;
        if (position == 0) {
            return VIEW_TYPE_CATEGORIAS;
        } else if (ListUtils.isEmpty(posts)) {
            return VIEW_TYPE_SEM_NOTICIAS;
        } else if (position < getCount() - finidshedModifier) {
            return VIEW_TYPE_POSTS;
        } else if (finishedLoad) {
            return VIEW_TYPE_FIM_NOTICIAS;
        } else {
            return 9999;
        }
    }

    /**
     * View Holders
     */
    public class ViewHolderCategorias extends ViewHolder {
        TabLayout tabLayout;

        ViewHolderCategorias(Context c, View itemView) {
            super(c, itemView);
            tabLayout = itemView.findViewById(R.id.tabs);
        }
    }

    // Post comum
    class ViewHolder extends BaseViewHolder {

        TextView tCategoria;
        ImageView imgFavorito;
        TextView tTitulo;
        TextView tResumo;
        TextView tData;
        FrameLayout btnFavorito;
        FrameLayout thumbVideoContainer;
        ImageView imgThumb;
        ImageView podcast;
        ProgressBar progress;
        ImageView imgOlho;

        ViewHolder(final Context context, View itemView) {
            super(itemView);

            tTitulo = (TextView) itemView.findViewById(R.id.tTitulo);
            if (tTitulo != null) {
                tCategoria = (TextView) itemView.findViewById(R.id.tCategoria);
                imgFavorito = (ImageView) itemView.findViewById(R.id.imgFavorito);
                tTitulo = (TextView) itemView.findViewById(R.id.tTitulo);
                tResumo = (TextView) itemView.findViewById(R.id.tResumo);
                tData = (TextView) itemView.findViewById(R.id.tData);
                btnFavorito = (FrameLayout) itemView.findViewById(R.id.btnFavorito);
                thumbVideoContainer = (FrameLayout) itemView.findViewById(R.id.thumbVideoContainer);
                imgThumb = itemView.findViewById(R.id.thumb);
                podcast = itemView.findViewById(R.id.imgPodcast);
                progress = (ProgressBar) itemView.findViewById(R.id.progressFav);
                imgOlho = (ImageView) itemView.findViewById(R.id.imgOlho);
            }
        }
    }

    // Post Destaque
    private class ViewHolderDestaque extends ViewHolder {
        static final int VIEWPAGER_TIME_DELAY = 8000;
        ViewPager viewPager;
        CirclePageIndicator pageView;

        ViewHolderDestaque(Context context, View itemView) {
            super(context, itemView);
            viewPager = (ViewPager) itemView.findViewById(R.id.viewPager);
            pageView = (CirclePageIndicator) itemView.findViewById(R.id.pageView);
            if (autoSlideViewPager == null) {
                autoSlideViewPager = new AutoSlideViewPager(viewPager, VIEWPAGER_TIME_DELAY);
            }
        }
    }

    // Fim das notícias encontradas
    private class ViewHolderFimNoticias extends ViewHolder {
        ViewHolderFimNoticias(Context context, View view) {
            super(context, view);

        }
    }

    // Nenhuma notícia encontrada
    private class ViewHolderSemNoticias extends ViewHolder {

        TextView tMsg;

        ViewHolderSemNoticias(Context context, View view) {
            super(context, view);
            tMsg = (TextView) view.findViewById(R.id.tMsg);
        }
    }

    private TabLayout.OnTabSelectedListener getOnTabSelectedListener() {
        return onTabSelectedListener;
    }

    public void setOnTabSelectedListener(TabLayout.OnTabSelectedListener onTabSelectedListener) {
        this.onTabSelectedListener = onTabSelectedListener;
    }

}
