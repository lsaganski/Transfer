package br.livetouch.livecom.itaubba.adapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import br.livetouch.livecom.itaubba.R;

/**
 * Created by empresa on 06/07/2016.
 */
public class TutorialPagerAdapter extends PagerAdapter {
    private static int[] resIds = new int[0];
    private LayoutInflater inflater;

    public TutorialPagerAdapter(Context context) {
        inflater = LayoutInflater.from(context);
        resIds = getResIds();
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        int res = resIds[position];
        View view = inflater.inflate(res, container, false);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return resIds.length;
    }

    public static int getMaxItens(){
       return resIds.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    private int[] getResIds() {
        return resIds = new int[]
        {R.layout.tutorial_publicacoes,R.layout.tutorial_config_categorias, R.layout.tutorial_visualizar_categorias,
                R.layout.tutorial_favoritos, R.layout.tutorial_busca };
    }
}
