package br.livetouch.livecom.itaubba.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Equipe;
import br.livetouch.utils.ListUtils;

public class EquipeAdapter extends RecyclerView.Adapter<EquipeAdapter.ViewHolder> {

    private List<Equipe> team;

    public EquipeAdapter(List<Equipe> team) {
        this.team = team;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_equipe, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Equipe member = team.get(position);
        if (member!= null) {
            holder.txtName.setText(member.getName());
            holder.txtDescription.setText(member.getDescription());
        }
    }

    @Override
    public int getItemCount() {
        return ListUtils.isNotEmpty(team) ? team.size() : 0;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtName;
        TextView txtDescription;

        ViewHolder(View itemView) {
            super(itemView);

            txtName = itemView.findViewById(R.id.txtName);
            txtDescription = itemView.findViewById(R.id.txtDescription);
        }
    }


}
