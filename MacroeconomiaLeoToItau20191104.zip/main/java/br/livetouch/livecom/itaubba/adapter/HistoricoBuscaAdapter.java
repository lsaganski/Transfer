package br.livetouch.livecom.itaubba.adapter;

import android.app.SearchManager;
import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import br.livetouch.livecom.itaubba.R;

/*
 * Created by empresa on 19/09/2017.
 */

public class HistoricoBuscaAdapter extends CursorAdapter {

    public HistoricoBuscaAdapter(Context context, Cursor c, boolean autoRequery) {
        super(context, c, autoRequery);
    }


    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        return inflater.inflate(R.layout.adapter_historico_busca, parent, false);
    }


    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        FrameLayout root = (FrameLayout) view;
        TextView tHistorico = (TextView) root.findViewById(R.id.item);

        final int index1 = cursor.getColumnIndex(SearchManager.SUGGEST_COLUMN_TEXT_1);
        tHistorico.setText(cursor.getString(index1));
    }


    public void refill(Cursor cursor) {
        changeCursor(cursor);
    }
}
