package br.livetouch.livecom.itaubba.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.List;

import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.utils.ListUtils;

/**
 * Created by livetouch on 02/10/17.
 */

public class VideosAdapter extends RecyclerView.Adapter<VideosAdapter.ViewHolder> {

    private Context context;
    private List<Arquivo> videos;
    private VideosAdapterCallback callback;

    public interface VideosAdapterCallback{
        void onClickVideo(Arquivo video);
    }

    public VideosAdapter(Context context, List<Arquivo> videos, VideosAdapterCallback callback) {
        this.context = context;
        this.videos = videos;
        this.callback = callback;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_video, viewGroup, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        Arquivo video =  videos.get(i);
        if(video!=null){
            Picasso.with(context).load(video.urlThumb).into(viewHolder.thumb);
            viewHolder.thumbVideoContainer.setOnClickListener(onClickVideo(video));
        }
    }

    private View.OnClickListener onClickVideo(final Arquivo video) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(callback!=null){
                    callback.onClickVideo(video);
                }
            }
        };
    }

    @Override
    public int getItemCount() {
        return ListUtils.size(videos);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView thumb;
        ImageView videoOverlay;
        FrameLayout thumbVideoContainer;


        public ViewHolder(View itemView) {
            super(itemView);
            thumb = itemView.findViewById(R.id.thumb);
            videoOverlay = itemView.findViewById(R.id.videoOverlay);
            thumbVideoContainer = itemView.findViewById(R.id.thumbVideoContainer);
        }
    }
}
