package br.livetouch.livecom.itaubba.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.menu.MenuVO;
import br.livetouch.utils.ListUtils;

/**
 * Created by empresa on 19/07/2017.
 */

public class MenuMaisAdapter extends RecyclerView.Adapter<MenuMaisAdapter.ViewHolder> {

    private List<MenuVO> menuVOList;
    private callback callback;

    public interface callback {
        void onClickMenu(MenuVO menuVO, int index);
    }

    public MenuMaisAdapter(List<MenuVO> menuVOList, MenuMaisAdapter.callback callback) {
        this.menuVOList = menuVOList;
        this.callback = callback;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_menu_mais, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final MenuVO menuVO = menuVOList.get(position);
        if (menuVO != null) {
            holder.tCategoria.setText(menuVO.nome);
            holder.imgCategoria.setImageResource(menuVO.icone);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (callback != null) {
                    callback.onClickMenu(menuVO, holder.getAdapterPosition());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return ListUtils.isNotEmpty(menuVOList) ? menuVOList.size() : 0;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCategoria;
        TextView tCategoria;

        ViewHolder(View itemView) {
            super(itemView);

            imgCategoria = itemView.findViewById(R.id.imgCategoria);
            tCategoria = itemView.findViewById(R.id.tCategoria);
        }
    }
}
