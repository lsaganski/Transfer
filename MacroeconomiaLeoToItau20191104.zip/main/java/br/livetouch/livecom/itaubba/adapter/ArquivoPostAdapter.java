package br.livetouch.livecom.itaubba.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.activity.BaseActivity;
import br.livetouch.utils.ListUtils;
import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 24/08/2017.
 */

public class ArquivoPostAdapter extends BaseAdapter {

    private final List<Arquivo> arquivos;
    private LayoutInflater inflater;
    private callbackArquivo callbackArquivo;

    public interface callbackArquivo{
        void onClickAnexo(Arquivo arquivo);
    }

    public ArquivoPostAdapter(BaseActivity context, List<Arquivo> arquivos, callbackArquivo callbackArquivo) {
        this.arquivos = arquivos;
        this.callbackArquivo = callbackArquivo;
        inflater = LayoutInflater.from(context);
    }

    public int getCount() {
        return ListUtils.isNotEmpty(arquivos) ? arquivos.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.adapter_arquivos_post, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        final Arquivo arquivo = arquivos.get(position);
        if (arquivo != null) {

            String fileName = StringUtils.isNotEmpty(arquivo.nome) ? arquivo.nome : arquivo.file;
            setTextView(viewHolder.tNomeArquivo, fileName, View.INVISIBLE);
            int imgRes = arquivo.getDrawable();
            viewHolder.imgIconeArquivo.setImageResource(imgRes);

            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (callbackArquivo != null){
                        callbackArquivo.onClickAnexo(arquivo);
                    }
                }
            });
        }

        return convertView;
    }

    private void setTextView(TextView tView, String string, int visibility) {
        if (StringUtils.isNotEmpty(string)) {
            tView.setText(string);
            tView.setVisibility(View.VISIBLE);
        } else {
            tView.setVisibility(visibility);
        }
    }

    private class ViewHolder {
        TextView tNomeArquivo;
        ImageView imgIconeArquivo;

        ViewHolder(View view) {
            tNomeArquivo = (TextView) view.findViewById(R.id.tNomeArquivo);
            imgIconeArquivo = (ImageView) view.findViewById(R.id.imgIconeArquivo);
        }
    }
}