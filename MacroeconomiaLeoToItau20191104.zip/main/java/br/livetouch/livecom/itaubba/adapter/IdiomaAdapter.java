package br.livetouch.livecom.itaubba.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Idioma;
import br.livetouch.livecom.itaubba.utils.LocaleUtils;
import br.livetouch.utils.ListUtils;

/**
 * Created by livetouch on 02/08/17.
 */



public class IdiomaAdapter extends RecyclerView.Adapter<IdiomaAdapter.ViewHolder> {

    public interface IdiomaAdapterCallback{
        void onClickIdioma(Idioma idioma);
    }

    private Context context;
    private List<Idioma> list;
    public IdiomaAdapterCallback callback;

    public IdiomaAdapter(Context context, List<Idioma> idiomas, IdiomaAdapterCallback callback) {
        this.context = context;
        this.list = idiomas;
        this.callback = callback;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_idioma, parent, false);
        return new IdiomaAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (ListUtils.isNotEmpty(list)){

            Idioma idioma = list.get(position);
            if (idioma != null) {

                holder.tIdioma.setText(idioma.nome);
                String idiomaSelecionado = LocaleUtils.getDefaultLanguage();

                if (idioma.code.contains(idiomaSelecionado)) {
                    holder.imgCheck.setVisibility(View.VISIBLE);
                } else {
                    holder.imgCheck.setVisibility(View.INVISIBLE);
                }

                holder.itemView.setOnClickListener(onClickIdioma(idioma));
            }
        }
    }

    private View.OnClickListener onClickIdioma(final Idioma idioma) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (callback != null) {
                    callback.onClickIdioma(idioma);
                }
            }
        };
    }

    @Override
    public int getItemCount() {
        return ListUtils.size(list);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tIdioma;
        ImageView imgCheck;

        public ViewHolder(View itemView) {
            super(itemView);
            tIdioma = (TextView) itemView.findViewById(R.id.tIdioma);
            imgCheck = (ImageView) itemView.findViewById(R.id.imgCheck);
        }
    }
}
