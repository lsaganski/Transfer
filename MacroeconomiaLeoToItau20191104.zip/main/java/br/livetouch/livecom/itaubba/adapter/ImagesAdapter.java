package br.livetouch.livecom.itaubba.adapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.List;

import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.utils.ListUtils;

/**
 * Created by livetouch on 02/10/17.
 */

public class ImagesAdapter extends PagerAdapter{

    private final LayoutInflater inflater;
    private final List<Arquivo> imagens;
    private Context context;
    private ImageAdapterListener callback;

    public interface ImageAdapterListener {
        void onClick(Arquivo imagem, int position);
    }

    public ImagesAdapter(Context context, List<Arquivo> imagens, ImageAdapterListener callback) {
        this.inflater = LayoutInflater.from(context);
        this.imagens = imagens;
        this.context = context;
        this.callback = callback;
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        View view = inflater.inflate(R.layout.adapter_imagem, container, false);
        final Arquivo imagem = imagens.get(position);

        if (imagem!=null){
            ViewHolder holder = new ViewHolder(view);
            Picasso.with(context).load(imagem.url).into(holder.img);
            holder.img.setOnClickListener(onClickImagem(imagem, position));
        }

        container.addView(view);
        return view;
    }

    private View.OnClickListener onClickImagem(final Arquivo imagem, final int position) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(callback != null){
                    callback.onClick(imagem, position);
                }
            }
        };
    }

    @Override
    public int getCount() {
        return ListUtils.size(imagens);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    private class ViewHolder {

        ImageView img;

        ViewHolder(View itemView) {

            img = itemView.findViewById(R.id.img);

        }
    }
}
