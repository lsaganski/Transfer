package br.livetouch.livecom.itaubba.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.List;

import br.livetouch.adapter.BaseRecyclerViewAdapter;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.SubCategoria;
import br.livetouch.utils.ListUtils;

/*
 * Created by empresa on 04/09/2017.
 */

public class CategoriaAdapter extends BaseRecyclerViewAdapter {

    private static final int VIEW_TYPE_CATEGORIA = 1;
    private static final int VIEW_TYPE_SUBCATEGORIA = 2;

    private callback callback;

    private List<Object> objectList;

    public interface callback{
        void onClickCategoria(Categoria categoria);
        void onClickSubCategoria(SubCategoria subCategoria);
    }

    public CategoriaAdapter(Context context, List<Object> objectList, callback callback) {
        super(context, false, 50);
        this.objectList = objectList;
        this.callback = callback;
        setHasStableIds(true);
    }

    @Override
    public int getItemViewType(int position) {
        if (position < objectList.size()) {
            Object obj = objectList.get(position);
            if (obj != null) {
                if (obj instanceof Categoria) {
                    return VIEW_TYPE_CATEGORIA;
                } else {
                    return VIEW_TYPE_SUBCATEGORIA;
                }
            }
        }
        return super.getItemViewType(position);
    }

    @Override
    protected BaseViewHolder onCreateBaseViewHolder(ViewGroup viewGroup, int itemViewType) {
        View view;
        switch (itemViewType) {
            case VIEW_TYPE_CATEGORIA:
                view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_categoria_header, viewGroup, false);
                return new ViewHolder(view);

            case VIEW_TYPE_SUBCATEGORIA:
                view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_subcategoria, viewGroup, false);
                return new ViewHolderSubCategoria(view);
        }

        return null;
    }

    @Override
    protected void onBindBaseViewHolder(BaseViewHolder baseViewHolder, int i) {
        int itemViewType = baseViewHolder.getItemViewType();

        switch (itemViewType) {
            case VIEW_TYPE_CATEGORIA:
                final Categoria categoria = (Categoria) objectList.get(i);
                if (categoria != null) {
                    ViewHolder holder = (ViewHolder) baseViewHolder;
                    holder.tCategoria.setText(categoria.nome);

                    if (categoria.hasSubCategorias()){
                        holder.divider.setVisibility(View.GONE);
                    } else {
                        holder.divider.setVisibility(View.VISIBLE);
                    }

                    holder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (callback != null){
                                callback.onClickCategoria(categoria);
                            }
                        }
                    });
                }
                break;

            case VIEW_TYPE_SUBCATEGORIA:
                final SubCategoria subCategoria = (SubCategoria) objectList.get(i);
                if (subCategoria != null) {
                    ViewHolderSubCategoria holder = (ViewHolderSubCategoria) baseViewHolder;
                    holder.tSubCategoria.setText(subCategoria.nome);

                    holder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (callback != null){
                                callback.onClickSubCategoria(subCategoria);
                            }
                        }
                    });
                }
                break;
        }
    }

    @Override
    public int getCount() {
        return ListUtils.size(objectList);
    }

    @Override
    public long getItemId(int position) {
        return objectList.get(position).hashCode();
    }

    private class ViewHolder extends BaseViewHolder {
        TextView tCategoria;
        FrameLayout divider;

        ViewHolder(View view) {
            super(view);
            tCategoria = view.findViewById(R.id.tCategoria);
            divider = view.findViewById(R.id.divider);
        }
    }

    private class ViewHolderSubCategoria extends BaseViewHolder {
        TextView tSubCategoria;

        ViewHolderSubCategoria(View view) {
            super(view);
            tSubCategoria = view.findViewById(R.id.tSubCategoria);
        }
    }
}
