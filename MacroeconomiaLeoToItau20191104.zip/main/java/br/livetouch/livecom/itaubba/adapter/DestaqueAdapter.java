package br.livetouch.livecom.itaubba.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.List;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Post;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.utils.ListUtils;

/*
 * Created by livetouch 08/08/17.
 */

class DestaqueAdapter extends PagerAdapter {

    private final LayoutInflater inflater;
    private final List<Post> destaques;
    private PostAdapter.PostCallback callback;
    private Context context;

    DestaqueAdapter(Context context, List<Post> destaques, PostAdapter.PostCallback callback) {
        this.inflater = LayoutInflater.from(context);
        this.destaques = destaques;
        this.callback = callback;
        this.context = context;
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        View view = inflater.inflate(R.layout.adapter_post_destaque, container, false);
        final Post post = destaques.get(position);

        if (post != null) {
            final ViewHolder holder = new ViewHolder(view);

            holder.tCategoria.setText(post.getCategoriaNome());
            holder.tTitulo.setText(post.titulo);
            holder.tData.setText(post.dateddMMYYYY);
            holder.tResumo.setText(post.getResumo());

            post.adapterType = PostInfo.TYPE_DESTAQUE_ADAPTER;

            // Post favoritado
            int imgFavorito = post.isfavorito ? R.drawable.icn_favorito_on : R.drawable.icn_favorito_off;
            holder.imgFavorito.setImageResource(imgFavorito);

            // Post lido
            if (post.lido) {
                holder.tTitulo.setTextColor(ContextCompat.getColor(context, R.color.warm_grey_three));
                holder.tCategoria.setTextColor(ContextCompat.getColor(context, R.color.warm_grey_three));
                holder.imgOlho.setVisibility(View.VISIBLE);
            } else {
                holder.tTitulo.setTextColor(ContextCompat.getColor(context, R.color.greyish_brown));
                holder.tCategoria.setTextColor(ContextCompat.getColor(context, R.color.light_navy_blue));
                holder.imgOlho.setVisibility(View.INVISIBLE);
            }

            holder.btnFavorito.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (callback != null) {
                        callback.onClickFavorito(post, holder.progress, position);
                    }
                }
            });

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (callback != null){
                        callback.onClickPost(post, position);
                    }
                }
            });
        }

        container.addView(view);
        return view;
    }

    @Override
    public int getCount() {
        return ListUtils.size(destaques);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    private class ViewHolder {

        TextView tCategoria;
        ImageView imgFavorito;
        TextView tTitulo;
        TextView tResumo;
        TextView tData;
        FrameLayout btnFavorito;
        FrameLayout thumbVideoContainer;
        ImageView imgThumb;
        ProgressBar progress;
        ImageView imgOlho;

        ViewHolder(View itemView) {

            tTitulo = (TextView) itemView.findViewById(R.id.tTitulo);
            tCategoria = (TextView) itemView.findViewById(R.id.tCategoria);
            imgFavorito = (ImageView) itemView.findViewById(R.id.imgFavorito);
            tTitulo = (TextView) itemView.findViewById(R.id.tTitulo);
            tResumo = (TextView) itemView.findViewById(R.id.tResumo);
            tData = (TextView) itemView.findViewById(R.id.tData);
            btnFavorito = (FrameLayout) itemView.findViewById(R.id.btnFavorito);
            thumbVideoContainer = (FrameLayout) itemView.findViewById(R.id.thumbVideoContainer);
            imgThumb = itemView.findViewById(R.id.thumb);
            progress = (ProgressBar) itemView.findViewById(R.id.progressFav);
            imgOlho = (ImageView) itemView.findViewById(R.id.imgOlho);
        }
    }
}
