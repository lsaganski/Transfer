package br.livetouch.livecom.itaubba.view;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Region;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.HashMap;
import java.util.Map;

import br.livetouch.livecom.itaubba.adapter.PostAdapter;
import br.livetouch.utils.LogUtil;

/**
 * ItemDecoration for Pinned Header.
 * <p>
 * porting from https://github.com/beworker/pinned-section-listview
 */
public class PinnedHeaderItemDecoration extends RecyclerView.ItemDecoration {
    private final static String TAG = PinnedHeaderItemDecoration.class.getSimpleName();

    public interface PinnedHeaderAdapter {
        boolean isPinnedViewType(int viewType);

        RecyclerView.ViewHolder getPinnedViewHolder();
    }

    private RecyclerView.Adapter mAdapter = null;

    // cached data
    // pinned header view
    private View mPinnedHeaderView = null;
    private int mHeaderPosition = -1;

    private Map<Integer, Boolean> mPinnedViewTypes = new HashMap<Integer, Boolean>();

    private int mPinnedHeaderTop;
    private Rect mClipBounds;

    @Override
    public void onDraw(Canvas c, RecyclerView recyclerView, RecyclerView.State state) {
        createPinnedHeader(recyclerView);

        if (mPinnedHeaderView != null) {

            final int headerEndAt = mPinnedHeaderView.getTop() + mPinnedHeaderView.getHeight();
            final View v = recyclerView.findChildViewUnder(c.getWidth() / 2, headerEndAt + 1);

            if (isHeaderView(recyclerView, v)) {
                mPinnedHeaderTop = v.getTop() - mPinnedHeaderView.getHeight();
            } else {
                mPinnedHeaderTop = 0;
            }

            mClipBounds = c.getClipBounds();
            mClipBounds.top = mPinnedHeaderTop + mPinnedHeaderView.getHeight();
            c.clipRect(mClipBounds);
        }
    }


    @Override
    public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
        if (mPinnedHeaderView != null) {
            c.save();

            mClipBounds.top = 0;
            c.clipRect(mClipBounds, Region.Op.UNION);
            c.translate(0, mPinnedHeaderTop);
            mPinnedHeaderView.draw(c);

            c.restore();
        }
    }

    private void createPinnedHeader(RecyclerView recyclerView) {
        checkCache(recyclerView);

        final LinearLayoutManager linearLayoutManager;
        final RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
        if (layoutManager instanceof LinearLayoutManager) {
            linearLayoutManager = (LinearLayoutManager) layoutManager;
        } else {
            return;
        }

        final int firstVisiblePosition = linearLayoutManager.findFirstVisibleItemPosition();
        final int headerPosition = findPinnedHeaderPosition(firstVisiblePosition);


        if (headerPosition >= 0 && mHeaderPosition != headerPosition) {
            mHeaderPosition = headerPosition;

            final int viewType = mAdapter.getItemViewType(headerPosition);

            PostAdapter.ViewHolderCategorias pinnedViewHolder = (PostAdapter.ViewHolderCategorias) ((PinnedHeaderAdapter) mAdapter).getPinnedViewHolder();
            if (pinnedViewHolder == null) {
                pinnedViewHolder = (PostAdapter.ViewHolderCategorias) mAdapter.createViewHolder(recyclerView, viewType);
                mAdapter.bindViewHolder(pinnedViewHolder, headerPosition);
            }

            mPinnedHeaderView = pinnedViewHolder.itemView;

        } else if (headerPosition == -1 && firstVisiblePosition == 0) {

            if (mPinnedHeaderView != null) {
                mPinnedHeaderView = null;
                mHeaderPosition = 0;
            }

        }

        LogUtil.logError("firstVisibleItemPosition : " + firstVisiblePosition + " headerPos : " + headerPosition + " mHeaderPosition : " + mHeaderPosition);

    }


    private int findPinnedHeaderPosition(int fromPosition) {
        if (fromPosition > mAdapter.getItemCount()) {
            return -1;
        }

        for (int position = fromPosition; position >= 0; position--) {
            final int viewType = mAdapter.getItemViewType(position);
            if (isPinnedViewType(viewType)) {
                return position;
            }
        }

        return -1;
    }

    private boolean isPinnedViewType(int viewType) {
        if (!mPinnedViewTypes.containsKey(viewType)) {
            mPinnedViewTypes.put(viewType, ((PinnedHeaderAdapter) mAdapter).isPinnedViewType(viewType));
        }

        return mPinnedViewTypes.get(viewType);
    }

    private boolean isHeaderView(RecyclerView parent, View v) {
        final int position = parent.getChildPosition(v);
        if (position == RecyclerView.NO_POSITION) {
            return false;
        }

        final int viewType = mAdapter.getItemViewType(position);

        return isPinnedViewType(viewType);
    }

    private void checkCache(RecyclerView parent) {
        RecyclerView.Adapter adapter = parent.getAdapter();
        if (mAdapter != adapter) {
            disableCache();
            if (adapter instanceof PinnedHeaderAdapter) {
                mAdapter = adapter;
            } else {
                mAdapter = null;
            }
        }
    }

    private void disableCache() {
        mPinnedHeaderView = null;
        mHeaderPosition = -1;
        mPinnedViewTypes.clear();
    }

}
