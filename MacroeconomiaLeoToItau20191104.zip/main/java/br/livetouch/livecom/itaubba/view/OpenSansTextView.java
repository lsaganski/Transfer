package br.livetouch.livecom.itaubba.view;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;

import br.livetouch.livecom.itaubba.utils.TypeFaceUtils;

/**
 * Created by livetouch on 10/6/16.
 */

public class OpenSansTextView extends android.support.v7.widget.AppCompatTextView {

    public static final int SEMI_BOLD = 110;


    public OpenSansTextView(Context context) {
        super(context);
        init(null);
    }

    public OpenSansTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    public OpenSansTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs);
    }

    private void init(AttributeSet attrs) {
        if (!isInEditMode()) {
            if (attrs == null) {
                Typeface tf = TypeFaceUtils.getTypeFace("OpenSans-Regular.ttf");
                setTypeface(tf);
            } else {
                String textStyle = attrs.getAttributeValue("http://schemas.android.com/apk/res/android", "textStyle");
                Typeface tf;
                if(textStyle == null){
                    tf = TypeFaceUtils.getTypeFace("OpenSans-Regular.ttf");
                    setTypeface(tf);
                } else {
                    switch (textStyle) {
                        case "0x"+ Typeface.BOLD:
                            tf = TypeFaceUtils.getTypeFace("OpenSans-Bold.ttf");
                            setTypeface(tf);
                            break;
                        case "0x"+ Typeface.NORMAL:
                            tf = TypeFaceUtils.getTypeFace("OpenSans-Regular.ttf");
                            setTypeface(tf);
                            break;
                        case "0x"+ SEMI_BOLD:
                            tf = TypeFaceUtils.getTypeFace("OpenSans-Semibold.ttf");
                            setTypeface(tf);
                            break;
                    }
                }
            }
        }
    }
}
