package br.livetouch.livecom.itaubba.view;

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.LinearLayout;

/*
 * Created by empresa on 18/10/2017.
 */

public class CustomLinearLayout extends LinearLayout implements ScaleGestureDetector.OnScaleGestureListener {

    private enum Mode {
        NONE,
        DRAG,
        ZOOM
    }

    private View imgZoomFit;

    private static final float MIN_ZOOM = 1.0f;
    private static final float MAX_ZOOM = 4.0f;

    private Mode mode = Mode.NONE;

    private ScaleGestureDetector scaleGestureDetector;

    // Where the finger first  touches the screen
    private float startX = 0f;
    private float startY = 0f;

    // How much to translate the canvas
    private float dx = 0f;
    private float dy = 0f;
    private float prevDx = 0f;
    private float prevDy = 0f;

    private float scaleFactor = 1;
    private float lastScaleFactor = 0f;

    public CustomLinearLayout(Context context) {
        super(context);
        init();
    }

    public CustomLinearLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomLinearLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public CustomLinearLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public void addViewToFitZoom(@NonNull View view){
        this.imgZoomFit = view;
        this.imgZoomFit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                scaleFactor = 1;
                dx = 0f;
                dy = 0f;
                applyScaleAndTranslation();
                showViewZoomFit();
            }
        });
    }

    public void init(){
        scaleGestureDetector = new ScaleGestureDetector(getContext(), this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        scaleGestureDetector.onTouchEvent(motionEvent);

        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                if (scaleFactor > MIN_ZOOM) {
                    mode = Mode.DRAG;
                    startX = motionEvent.getX() - prevDx;
                    startY = motionEvent.getY() - prevDy;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (mode == Mode.DRAG) {
                    dx = motionEvent.getX() - startX;
                    dy = motionEvent.getY() - startY;
                }
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                mode = Mode.ZOOM;
                break;
            case MotionEvent.ACTION_POINTER_UP:
                mode = Mode.DRAG;
                break;
            case MotionEvent.ACTION_UP:
                mode = Mode.NONE;
                prevDx = dx;
                prevDy = dy;
                break;
        }

        if ((mode == Mode.DRAG && scaleFactor >= MIN_ZOOM) || mode == Mode.ZOOM) {
            getParent().requestDisallowInterceptTouchEvent(true);
            float maxDx = (child().getWidth() - (child().getWidth() / scaleFactor)) / 2 * scaleFactor;
            float maxDy = (child().getHeight() - (child().getHeight() / scaleFactor))/ 2 * scaleFactor;
            dx = Math.min(Math.max(dx, -maxDx), maxDx);
            dy = Math.min(Math.max(dy, -maxDy), maxDy);

            applyScaleAndTranslation();
        }

        return true;
    }

    private void applyScaleAndTranslation() {
        child().setScaleX(scaleFactor);
        child().setScaleY(scaleFactor);
        child().setTranslationX(dx);
        child().setTranslationY(dy);
    }

    @Override
    public boolean onScale(ScaleGestureDetector detector) {
        float scale = detector.getScaleFactor();
        if (lastScaleFactor == 0 || (Math.signum(scale) == Math.signum(lastScaleFactor))) {
            scaleFactor *= scale;
            scaleFactor = Math.max(MIN_ZOOM, Math.min(scaleFactor, MAX_ZOOM));
            lastScaleFactor = scaleFactor;
        } else {
            lastScaleFactor = 0;
        }

        return true;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {
        showViewZoomFit();
    }

    private void showViewZoomFit() {
        if (imgZoomFit != null) {
            if (scaleFactor > MIN_ZOOM) {
                imgZoomFit.setVisibility(VISIBLE);
            } else {
                imgZoomFit.setVisibility(GONE);
            }
        }
    }

    private View child() {
        return getChildAt(0);
    }
}
