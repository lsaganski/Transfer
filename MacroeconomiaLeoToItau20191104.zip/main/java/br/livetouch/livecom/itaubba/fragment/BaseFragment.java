package br.livetouch.livecom.itaubba.fragment;

import android.app.SearchManager;
import android.content.ContentResolver;
import android.database.Cursor;
import android.graphics.Rect;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.View;
import android.widget.AutoCompleteTextView;

import java.util.List;

import br.livetouch.livecom.fragment.LivecomFragment;
import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.activity.BaseActivity;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.provider.SuggestionProvider;
import br.livetouch.livecom.itaubba.utils.BaseRecyclerViewAdapter;
import br.livetouch.livecom.itaubba.utils.EndlessScrollViewListener;
import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 19/07/2017.
 */

public abstract class BaseFragment extends LivecomFragment {

    protected void setupRecyclerView(View view, RecyclerView recyclerView, int drawableCustomDivider) {
        setupRecyclerView(view, recyclerView, null);

        if (drawableCustomDivider != 0) {
            DividerItemDecoration divider = getDividerItemDecoration(recyclerView);
            divider.setDrawable(ContextCompat.getDrawable(getContext(), drawableCustomDivider));
            recyclerView.addItemDecoration(divider);
        }
    }

    protected void setupRecyclerView(View view, RecyclerView recyclerView) {
        setupRecyclerView(view, recyclerView, null);
    }

    protected SwipeRefreshLayout setupRecyclerView(View view, RecyclerView recyclerView, SwipeRefreshLayout.OnRefreshListener onRefreshListener) {
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this.getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        SwipeRefreshLayout swipeLayout = view.findViewById(R.id.swipe_container);
        if(swipeLayout != null) {
            swipeLayout.setColorSchemeResources(R.color.brownish_orange_two);
            swipeLayout.setOnRefreshListener(onRefreshListener);
        }
        return swipeLayout;
    }

    // usado no onBackPressed da activity
    public void restoreTitle(){
        getBaseActivity().restoreToolbar();
        setTitle(getTitle());
    }

    public String getTitle() {
        return getString(R.string.app_name);
    }

    protected void setTitle(String title) {
        super.setTitle(title);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(title);
        }
    }

    protected void setDialogSuggestionsFullSize(@NonNull SearchView searchView){
        final AutoCompleteTextView searchText = searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        if (searchText != null) {
            View dropDownSuggestions = searchView.findViewById(searchText.getDropDownAnchor());
            dropDownSuggestions.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                @Override
                public void onLayoutChange(View view, int i, int i1, int i2, int i3, int i4, int i5, int i6, int i7) {
                    Rect screenSize = new Rect();
                    getBaseActivity().getWindowManager().getDefaultDisplay().getRectSize(screenSize);
                    int screenWidth = screenSize.width();
                    searchText.setDropDownWidth(screenWidth);
                }
            });
        }
    }

    @NonNull
    private DividerItemDecoration getDividerItemDecoration(final RecyclerView recyclerView) {
        return new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL) {
            @Override
            public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
                super.getItemOffsets(outRect, view, parent, state);
                int position = parent.getChildAdapterPosition(view);

                // hide the divider for the last child and first child
                if (position == 0 || position == parent.getAdapter().getItemCount() - 1) {
                    outRect.setEmpty();
                } else {
                    super.getItemOffsets(outRect, view, parent, state);
                }
            }
        };
    }

    public EndlessScrollViewListener addEndlessScrollViewListener(RecyclerView recyclerView, List<?> list, EndlessScrollViewListener.Callback scrollCallback, boolean showProgress, BaseRecyclerViewAdapter adapter) {
        EndlessScrollViewListener endScroll = new EndlessScrollViewListener(getBaseActivity(), list, showProgress, adapter);
        endScroll.setDelegate(scrollCallback);
        endScroll.setOfflineMode(false);
        recyclerView.addOnScrollListener(endScroll);
        return endScroll;
    }

    protected String getSuggestion(@NonNull SearchView searchView, int position) {
        CursorAdapter cursorAdapter = searchView.getSuggestionsAdapter();
        Cursor cursor = cursorAdapter != null ? cursorAdapter.getCursor() : null;
        if (cursor != null) {
            cursor.moveToPosition(position);
            return cursor.getString(Cursor.FIELD_TYPE_STRING);
        }
        return "";
    }

    protected Cursor getSuggestionProvider(String query){
        ContentResolver contentResolver = getBaseActivity().getContentResolver();
        String contentUri = "content://" + SuggestionProvider.AUTHORITY + '/' + SearchManager.SUGGEST_URI_PATH_QUERY;
        Uri uri = Uri.parse(contentUri);
        return contentResolver.query(uri, null, null, new String[]{query}, null);
    }

    public void trackEvent(String category, String action, String label) {
        this.getBaseActivity().trackEvent(category, action, label);
    }

    public void trackEvent(String category, String action, String label, int indexCustomMetric) {
        this.getBaseActivity().trackEvent(category, action, label, indexCustomMetric);
    }

    public void trackEventScreenView(int indexCustomMetric,String... args) {
        this.getBaseActivity().trackEventScreenView(indexCustomMetric, args);
    }

    public void trackEventScreenView(String... args) {
        this.getBaseActivity().trackEventScreenView(args);
    }

    protected void trackGA(PostInfo postInfo) {
        if (postInfo != null) {
            if (postInfo.isMenuHome()) {
                trackEventScreenView(GoogleAnalytics.HOME_PAGE);
            } else if (postInfo.isMenuFavorito()) {
                trackEventScreenView(GoogleAnalytics.BOOKMARKS);
            } else if (StringUtils.isNotEmpty(postInfo.getQuery())) {
                trackEventScreenView(GoogleAnalytics.BUSCA, postInfo.getQuery());
            }
        }
    }

    public BaseActivity getBaseActivity() {
        return (BaseActivity)this.getActivity();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
