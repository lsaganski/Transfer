package br.livetouch.livecom.itaubba.fragment;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatRadioButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.utils.LocaleUtils;
import br.livetouch.livecom.itaubba.utils.TypeFaceUtils;
import br.livetouch.utils.StringUtils;

/**
 * Created by empresa on 18/07/2017.
 */

public class SelecionarIdiomaFragment extends BaseFragment {

    private final String ENGLISH = "en-us";
    private final String PORTUGUES = "pt-br";
    private final String ESPANHOL = "es-es";

    private callback callback;

    private AppCompatRadioButton btnPortugues;
    private AppCompatRadioButton btnIngles;
    private AppCompatRadioButton btnEspanhol;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_selecionar_idioma, container, false);

        RadioGroup radioGroup = view.findViewById(R.id.radioGroup);
        btnPortugues = view.findViewById(R.id.btnPortugues);
        btnIngles = view.findViewById(R.id.btnIngles);
        btnEspanhol = view.findViewById(R.id.btnEspanhol);

        radioGroup.setOnCheckedChangeListener(onCheckChangeListener());
        setOnClickListener(view, R.id.btnContinuar, onclickcontinuar());

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        setDefaultRadioButton();

    }

    // seta radiobutton para idioma do device
    private void setDefaultRadioButton() {
        String language = LocaleUtils.getDefaultLanguage();
        if (StringUtils.equalsIgnoreCase(language, ENGLISH)) {
            btnIngles.setChecked(true);
        } else if (StringUtils.equalsIgnoreCase(language, PORTUGUES)) {
            btnPortugues.setChecked(true);
        } else if (StringUtils.equalsIgnoreCase(language, ESPANHOL)) {
            btnEspanhol.setChecked(true);
        }
    }

    private RadioGroup.OnCheckedChangeListener onCheckChangeListener() {
        return new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkedId) {
                setStyleRadioButton(checkedId);
            }
        };
    }

    private void setStyleRadioButton(int checkedId) {
        resetStyleRadioButtons();
        Typeface typeFaceSemiBold = TypeFaceUtils.getTypeFaceOpenSansSemiBold();
        switch (checkedId) {
            case R.id.btnPortugues:
                btnPortugues.setTypeface(typeFaceSemiBold);
                LocaleUtils.setPrefsLanguage(PORTUGUES);
                break;
            case R.id.btnIngles:
                btnIngles.setTypeface(typeFaceSemiBold);
                LocaleUtils.setPrefsLanguage(ENGLISH);
                break;
            case R.id.btnEspanhol:
                btnEspanhol.setTypeface(typeFaceSemiBold);
                LocaleUtils.setPrefsLanguage(ESPANHOL);
                break;
        }
    }

    private void resetStyleRadioButtons() {
        Typeface typeFace = TypeFaceUtils.getTypeFaceOpenSansLight();
        btnPortugues.setTypeface(typeFace);
        btnIngles.setTypeface(typeFace);
        btnEspanhol.setTypeface(typeFace);
    }

    private View.OnClickListener onclickcontinuar() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (callback != null){
                    callback.onClickIniciarTutorial();
                }
            }
        };
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            callback = (callback) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString());
        }
    }

    public interface callback {
        void onClickIniciarTutorial();
    }
}
