package br.livetouch.livecom.itaubba.fragment.midias;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.Pair;

import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.EnumCategoria;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.fragment.PostsFragment;
import br.livetouch.livecom.itaubba.utils.BundleUtils;

public class MediaPagerAdapter extends FragmentStatePagerAdapter {

    private Context context;

    MediaPagerAdapter(Context context, FragmentManager fm) {
        super(fm);
        this.context = context;
    }

    @Override
    public Fragment getItem(int position) {
        Bundle bundle = new Bundle();
        PostInfo postInfo = new PostInfo();
        postInfo.setTitle(context.getString(R.string.midia_upper));
        postInfo.setMidias(true);
        switch (position) {
            case 0:
                postInfo.setCategoria(new Categoria(EnumCategoria.VIDEO.getCod()));
                fillBundle(new Pair<>(PostInfo.KEY, postInfo), bundle);
                break;
            case 1:
                postInfo.setCategoria(new Categoria(EnumCategoria.PODCAST.getCod()));
                fillBundle(new Pair<>(PostInfo.KEY, postInfo), bundle);
                break;
        }
        PostsFragment postsFragment = new PostsFragment();
        postsFragment.setArguments(bundle);
        return postsFragment;
    }

    // This determines the title for each tab
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return context.getString(R.string.videos_toolbar_title);
            case 1:
                return context.getString(R.string.podcast_upper);
            default:
                return context.getString(R.string.videos_toolbar_title);
        }
    }

    @Override
    public int getCount() {
        return 2;
    }

    private void fillBundle(Pair<String, Object> arg, Bundle bundle) {
        if (arg != null){
            BundleUtils.fillBundle(bundle, arg);
        }
    }
}
