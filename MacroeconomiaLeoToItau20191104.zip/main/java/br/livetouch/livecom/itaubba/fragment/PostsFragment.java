package br.livetouch.livecom.itaubba.fragment;

import android.database.Cursor;
import android.os.Bundle;
import android.provider.SearchRecentSuggestions;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.crashlytics.android.Crashlytics;
import com.squareup.otto.Subscribe;

import java.util.List;

import br.livetouch.exception.DomainException;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.activity.PostActivity;
import br.livetouch.livecom.itaubba.activity.VideoViewActivity;
import br.livetouch.livecom.itaubba.adapter.HistoricoBuscaAdapter;
import br.livetouch.livecom.itaubba.adapter.PostAdapter;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.Mural;
import br.livetouch.livecom.itaubba.domain.Post;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.domain.event.BusEvent;
import br.livetouch.livecom.itaubba.provider.SuggestionProvider;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.livecom.itaubba.utils.BundleUtils;
import br.livetouch.livecom.itaubba.utils.EndlessScrollViewListener;
import br.livetouch.livecom.itaubba.utils.ShareIntentUtils;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;
import br.livetouch.utils.ListUtils;
import br.livetouch.utils.LogUtil;
import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 19/07/2017.
 */

public class PostsFragment extends BaseFragment {

    private HistoricoBuscaAdapter historicoBuscaAdapter;

    private PostInfo postInfo;
    private List<Post> posts;
    private List<Post> destaques;
    private List<Categoria> categorias;

    private SearchRecentSuggestions suggestions;

    private SearchView searchView;
    private PostAdapter adapter;
    private RecyclerView recyclerView;
    private EndlessScrollViewListener endless;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        registerBus(this);
        Bundle arguments = getArguments();
        if (arguments != null) {
            postInfo = (PostInfo) arguments.getSerializable(PostInfo.KEY);
            if (postInfo == null) {
                postInfo = new PostInfo();
            }
        }

        suggestions = new SearchRecentSuggestions(getContext(), SuggestionProvider.AUTHORITY, SuggestionProvider.MODE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_posts, container, false);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler);
        setupRecyclerView(view, recyclerView, onRefreshPosts());

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        setTitle(getTitle());
        if (ListUtils.isEmpty(posts)) {
            trackGA(postInfo);
            if (postInfo.isMenuFavorito()) {
                startTaskOfflineParallel(taskGetPosts(false), R.id.progress);
            } else {
                startTask(taskGetPosts(false), R.id.progress);
            }
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_posts, menu);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        boolean showSearchView = postInfo != null && !postInfo.isMenuFavorito() && StringUtils.isEmpty(postInfo.getQuery()) ;
        menu.findItem(R.id.buscar).setVisible(showSearchView);
        if (showSearchView) {
            setUpSearchView(menu);
        }
    }

    private void setUpSearchView(Menu menu) {
        MenuItem searchItem = menu.findItem(R.id.buscar);
        searchView = (SearchView) searchItem.getActionView();
        if (searchView != null) {
            searchView.setQueryHint(getResources().getString(R.string.pesquise_por_palavra_chave));
            searchView.setOnQueryTextListener(onQueryText());
            searchView.setOnSuggestionListener(onSuggestionListener());
            setDialogSuggestionsFullSize(searchView);

            searchItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
                @Override
                public boolean onMenuItemActionExpand(MenuItem menuItem) {
                    trackEventScreenView(GoogleAnalytics.BUSCA);
                    trackEvent(GoogleAnalytics.CATEGORY_APP_MENU, GoogleAnalytics.CLICK_NAVEGACAO, GoogleAnalytics.PESQUISAR);
                    return true;
                }

                @Override
                public boolean onMenuItemActionCollapse(MenuItem menuItem) {
                    return true;
                }
            });
        }
    }

    private SearchView.OnSuggestionListener onSuggestionListener() {
        return new SearchView.OnSuggestionListener() {
            @Override
            public boolean onSuggestionSelect(int position) {
                return true;
            }

            @Override
            public boolean onSuggestionClick(int position) {
                String query = getSuggestion(searchView, position);
                if (StringUtils.isNotEmpty(query)) {
                    searchView.setQuery(query, true);
                }
                return true;
            }
        };
    }

    private SearchView.OnQueryTextListener onQueryText() {
        return new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                suggestions.saveRecentQuery(query, null);
                PostInfo info = new PostInfo();
                info.setCategoria(postInfo.getCategoria());
                info.setSubCategoria(postInfo.getSubCategoria());
                info.setQuery(query);
                postBus(new BusEvent.FiltroPostEvent(info));
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                try {
                    showSuggetionsAdapter(query);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return true;
            }
        };
    }

    private void showSuggetionsAdapter(String query) {
        if (query == null){
            return;
        }

        if (query.length() > 0) {
            Cursor cursor = getSuggestionProvider(query);
            if (cursor != null && !cursor.isClosed()) {
                cursor.moveToFirst();
                if (historicoBuscaAdapter == null) {
                    historicoBuscaAdapter = new HistoricoBuscaAdapter(getContext(), cursor, true);
                } else {
                    historicoBuscaAdapter.refill(cursor);
                }
                searchView.setSuggestionsAdapter(historicoBuscaAdapter);
            }
        }
    }

    private Task taskGetPosts(final boolean refresh) {
        return new BaseTask() {
            Mural muralPosts;
            Mural muralDestaques;

            @Override
            public void execute() throws Exception {

                // get posts sem destaque;
                postInfo.setDestaque(false);
                muralPosts = ItaubbaService.getPosts(postInfo);
                posts = muralPosts != null ? muralPosts.posts : null;

                // get posts destaques e categorias;
                if (postInfo.isMenuHome()){
                    postInfo.setDestaque(true);
                    muralDestaques = ItaubbaService.getPosts(postInfo);
                    destaques = muralDestaques != null ? muralDestaques.posts : null;

                    if (ListUtils.isNotEmpty(posts) || ListUtils.isNotEmpty(destaques)) {
                        categorias = ItaubbaService.getCategorias(getContext(), true, true);
                    }
                }
            }

            @Override
            public void updateView() {
                if (refresh){
                    adapter = null;
                }

                if (adapter != null) {
                    adapter.updateAdapter(posts);
                } else {
                    adapter = new PostAdapter(getContext(), onClickPostCallback(), posts, destaques, categorias, postInfo.isMenuFavorito(), postInfo.isMidias());
                    adapter.setOnTabSelectedListener(onTabSelectedListener());
                    recyclerView.setAdapter(adapter);
                    endless = addEndlessScrollViewListener(recyclerView, posts, new EndlessScrollViewListener.Callback() {
                        @Override
                        public void onScrollFinished() {
                            adapter.setFinishedLoad(true);
                        }

                        @Override
                        public List onScrollGetNextList(int i) throws Exception {
                            postInfo.setDestaque(false);
                            Mural mural = ItaubbaService.getPosts(postInfo, i);
                            return mural.posts;
                        }
                    }, false, adapter);
                }

                // se tenho query de busca mostro view Resultados
                if (postInfo != null && StringUtils.isNotEmpty(postInfo.getQuery()) && ListUtils.isNotEmpty(posts)){
                    showView(R.id.viewResultados);
                }
            }

            @Override
            public boolean onError(Throwable e) {
                if (e != null){
                    Crashlytics.logException(e);
                }
                return super.onError(e);
            }
        };
    }

    private PostAdapter.PostCallback onClickPostCallback() {
        return new PostAdapter.PostCallback() {
            @Override
            public void onClickFavorito(Post post, ProgressBar progress, int adapterPosition) {
                startTask(taskFavoritar(post, progress, adapterPosition), false);
            }

            @Override
            public void onClickPost(Post post, int adapterPosition) {
                if (PostInfo.TYPE_DESTAQUE_ADAPTER == post.adapterType) {
                    trackEvent(GoogleAnalytics.CATEGORY_APP_HOME, GoogleAnalytics.CLICK_DESTAQUE, post.titulo);
                }
                Bundle bundle = new Bundle();
                BundleUtils.fillBundle(bundle, new Pair<>(PostInfo.POST_ID, post.id), new Pair<>(PostInfo.TYPE_ADAPTER, post.adapterType), new Pair<>(PostInfo.KEY, postInfo));
                show(PostActivity.class, bundle);
            }

            @Override
            public void onClickVideo(Post post, int adapterPosition) {
                Arquivo arquivo = post.getFirstVideo();
                if (arquivo != null) {
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(Arquivo.TAG, arquivo);
                    show(VideoViewActivity.class, bundle);
                }
            }

            @Override
            public void openPodCast(String url) {
                ShareIntentUtils
                        .with(getBaseActivity())
                        .setIntentCallBack(message -> toast(message))
                        .openPodcastIntent(url);
            }
        };
    }

    private Task taskFavoritar(final Post post, final ProgressBar progress, final int adapterPosition) {
        return new BaseTask() {

            @Override
            public void preExecute() throws Exception {
                super.preExecute();
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void execute() throws Exception {
                ItaubbaService.savePostFavorito(post);
            }

            @Override
            public void updateView() {
                progress.setVisibility(View.INVISIBLE);

                boolean fromDestaque = post.adapterType == PostInfo.TYPE_DESTAQUE_ADAPTER;

                if (fromDestaque){
                    adapter.notifyAdapterDestaque(adapterPosition, post);
                } else {
                    if (postInfo.isMenuFavorito() && !post.isfavorito) {
                        adapter.removeAt(adapterPosition);
                    } else {
                        adapter.notifyItemChanged(adapterPosition, post);
                    }
                }

                if (post.isfavorito) {
                    trackEvent(GoogleAnalytics.CATEGORY_APP_HOME, GoogleAnalytics.CLICK_BOOKMARK, post.titulo, GoogleAnalytics.METRIC_CLICK_BOOKMARK);
                }
            }

            @Override
            public boolean onError(Throwable e) {
                progress.setVisibility(View.INVISIBLE);
                return super.onError(e);
            }
        };
    }

    private TabLayout.OnTabSelectedListener onTabSelectedListener() {
        return new TabLayout.OnTabSelectedListener() {
            boolean istabChanged;
            Categoria categoria;

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (istabChanged) {
                    istabChanged = false;
                    try {
                        Categoria mCategoria = categorias.get(position);
                        categoria = mCategoria != null && mCategoria.id != null ? mCategoria : null;
                    } catch (Exception e) {
                        categoria = null;
                        e.printStackTrace();
                    }

                    if (endless != null) {
                        endless.clearPosition();
                    }

                    postInfo.setCategoria(categoria);
                    startTask(taskGetPosts(false), R.id.progress);

                    String categoriaNome = categoria != null ? categoria.nome : "todas";
                    trackEvent(GoogleAnalytics.CATEGORY_APP_HOME, GoogleAnalytics.CLICK_CATEGORIA, categoriaNome);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                istabChanged = true;
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                startTask(taskGetPosts(false), R.id.progress);
            }
        };
    }

    private SwipeRefreshLayout.OnRefreshListener onRefreshPosts() {
        return () -> {
            if (postInfo.isMenuHome()) {
                postInfo.setCategoria(null);
            }
            startTask(taskGetPosts(true), R.id.swipe_container);
        };
    }

    private void updatePost(Post postAtualizado) {
        try {
            boolean fromDestaque = postAtualizado.adapterType == PostInfo.TYPE_DESTAQUE_ADAPTER;
            int positionFromList = postAtualizado.getPositionFromList(posts);
            boolean unFavoritedPost = isUnFavoritedPost(postAtualizado);

            if (fromDestaque) {
                adapter.notifyAdapterDestaque(positionFromList, postAtualizado);
            } else if (postInfo.isMenuFavorito() && unFavoritedPost) {
                adapter.removeAt(positionFromList);
            } else {
                adapter.updatePost(postAtualizado, positionFromList);
            }
        } catch (Exception e) {
            LogUtil.logError(e.getMessage(), e);
            onRefreshPosts().onRefresh();
        }
    }

    // unFavorite
    public boolean isUnFavoritedPost(Post post) throws DomainException {
        if (ListUtils.isNotEmpty(posts)) {
            int indexOf = posts.indexOf(post);
            return indexOf != -1 && !post.isfavorito;
        }
        throw new DomainException("Não foi possível encontrar o Post na lista.");
    }

    @Override
    public String getTitle() {
        boolean hasQuery = StringUtils.isNotEmpty(postInfo.getQuery());
        if (postInfo.isMenuCategorias()) {
            getBaseActivity().setTitle(postInfo);
        } else {
            getBaseActivity().restoreToolbar();
        }
        if (hasQuery){
            return postInfo.getQuery();
        } else {
            return postInfo.getTitle();
        }
    }

    // Quando retorna do detalhe do post dispara esse evento.
    @Subscribe
    public void onBusUpdatepost(final BusEvent.PostUpdateEvent event) {
        if (event.post != null) {
            updatePost(event.post);
        }
    }

    @Subscribe
    public void onBusTrackGA(final BusEvent.trackGAEvent event) {
        if (event.isResultFragment && postInfo != null && postInfo.getQuery() != null) {
            trackEventScreenView(GoogleAnalytics.BUSCA, postInfo.getQuery());
        } else if (event.isBookmarkFragment){
            trackEventScreenView(GoogleAnalytics.BOOKMARKS);
        } else if (event.isHomePage){
            trackEventScreenView(GoogleAnalytics.HOME_PAGE);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterBus(this);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        setBusResult();
    }

    private void setBusResult() {
        if (postInfo != null) {
            BusEvent.trackGAEvent trackGAEvent = new BusEvent.trackGAEvent();
            if (postInfo.getQuery() != null) {
                trackGAEvent.isHomePage = true;
                postBus(trackGAEvent);
            } else if (postInfo.getSubCategoria() == null && postInfo.isMenuCategorias()) {
                trackGAEvent.isCategoryFragment = true;
                postBus(trackGAEvent);
            }
        }
    }
}
