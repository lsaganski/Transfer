package br.livetouch.livecom.itaubba.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.activity.CategoriasInteresseActivity;
import br.livetouch.livecom.itaubba.activity.ConfiguracoesActivity;
import br.livetouch.livecom.itaubba.activity.SobreAppActivity;
import br.livetouch.livecom.itaubba.activity.SobreEquipeActivity;
import br.livetouch.livecom.itaubba.activity.TermosUsoActivity;
import br.livetouch.livecom.itaubba.adapter.MenuMaisAdapter;
import br.livetouch.livecom.itaubba.domain.event.BusEvent;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.livecom.menu.MenuVO;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;
import br.livetouch.utils.ListUtils;

/*
 * Created by empresa on 19/07/2017.
 */

public class MenuMaisFragment extends BaseFragment {

    private RecyclerView recyclerView;
    private List<MenuVO> menuVOList;
    private MenuMaisAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_menu_mais, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        setupRecyclerView(view, recyclerView);

        setTitle(getTitle());

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        startTaskOfflineParallel(taskListMenu(), false);
        trackEventScreenView(GoogleAnalytics.MAIS);
    }

    private Task taskListMenu() {
        return new BaseTask() {

            @Override
            public void execute() throws Exception {
                menuVOList = ItaubbaService.getMenuMais(getContext());
            }

            @Override
            public void updateView() {
                if (ListUtils.isNotEmpty(menuVOList)){
                    adapter = new MenuMaisAdapter(menuVOList, onClickItemMenuMais());
                    recyclerView.setAdapter(adapter);
                }
            }
        };
    }

    private MenuMaisAdapter.callback onClickItemMenuMais() {
        return new MenuMaisAdapter.callback() {
            @Override
            public void onClickMenu(MenuVO menuVO, int index) {
                Class<? extends Activity> activity = getActivityForIndex(index);
                if (activity != null) {
                    show(activity);
                }
            }
        };
    }

    @Override
    public String getTitle() {
        return getString(R.string.mais_toolbar_title);
    }

    private Class<? extends Activity> getActivityForIndex(int index){
        switch (index){
            case 0:
                return CategoriasInteresseActivity.class;
            case 1:
                return SobreEquipeActivity.class;
            case 2:
                return SobreAppActivity.class;
            case 3:
                return TermosUsoActivity.class;
            case 4:
                postBus(new BusEvent.StartTutorialEvent());
                return null;
            case 5:
                return ConfiguracoesActivity.class;
            default:
                return null;
        }
    }
}
