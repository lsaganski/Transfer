package br.livetouch.livecom.itaubba.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.squareup.otto.Subscribe;

import java.util.List;

import br.livetouch.livecom.itaubba.GoogleAnalytics;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.adapter.CategoriaAdapter;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.domain.SubCategoria;
import br.livetouch.livecom.itaubba.domain.event.BusEvent;
import br.livetouch.livecom.itaubba.service.ItaubbaService;
import br.livetouch.task.BaseTask;
import br.livetouch.task.Task;
import br.livetouch.utils.ListUtils;

/*
 * Created by empresa on 21/07/2017.
 */

public class CategoriasFragment extends BaseFragment {

    private PostInfo postInfo;
    private List<Object> objectList;
    private CategoriaAdapter categoriaAdapter;

    private RecyclerView recyclerView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerBus(this);
        Bundle arguments = getArguments();
        if (arguments != null){
            postInfo = (PostInfo) arguments.getSerializable(PostInfo.KEY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_categorias, container, false);

        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        setupRecyclerView(view, recyclerView, onRefresh());

        setTitle(getTitle());

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (ListUtils.isEmpty(objectList)) {
            startTask(taskGetCategorias(), R.id.progress);
            if (postInfo == null)
                trackEventScreenView(GoogleAnalytics.CATEGORIAS);
        }
    }

    private Task taskGetCategorias() {
        return new BaseTask() {

            @Override
            public void execute() throws Exception {
                if (postInfo == null) {
                    // add Categorias e suas Sub Categorias
                    List<Categoria> categorias = ItaubbaService.getCategorias(getContext());
                    objectList = Categoria.addCategoriasToObjectList(categorias);
                } else {
                    // add Sub Categorias das Sub Categorias (Editorias)
                    objectList = Categoria.addAuditoriasToObjectList(getContext(), postInfo.getSubCategoria().editorias);
                }
            }

            @Override
            public void updateView() {
                categoriaAdapter = new CategoriaAdapter(getContext(), objectList, callBackCategoriaAdapter());
                recyclerView.setAdapter(categoriaAdapter);
            }
        };
    }

    private CategoriaAdapter.callback callBackCategoriaAdapter() {
        return new CategoriaAdapter.callback() {
            @Override
            public void onClickCategoria(Categoria categoria) {
                postBus(new BusEvent.FiltroPostEvent(categoria));
            }

            @Override
            public void onClickSubCategoria(SubCategoria subCategoria) {

                // salvo a categoria pai da subcategoria na Editoria para mostrar na toolbar.
                if (subCategoria.isEditoria && postInfo != null) {
                    SubCategoria categoria = postInfo.getSubCategoria();
                    subCategoria.categoria = categoria.categoriaPai;
                }

                // se seleciona a o item "todas" atribuo os valores.
                if (subCategoria.id == null && postInfo != null){
                    subCategoria.nome = postInfo.getSubCategoria().nome;
                    subCategoria.categoriaPai = postInfo.getSubCategoria().categoriaPai;
                }

                postBus(new BusEvent.FiltroPostEvent(subCategoria));
            }
        };
    }

    private SwipeRefreshLayout.OnRefreshListener onRefresh() {
        return new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                startTask(taskGetCategorias(), R.id.swipe_container);
            }
        };
    }

    @Override
    public String getTitle() {
        SubCategoria subCategoria = null;
        if (postInfo != null){
            subCategoria = postInfo.getSubCategoria();
        }
        return subCategoria != null ? subCategoria.nome : getString(R.string.categorias_toolbar_title);
    }

    @Subscribe
    public void onBusTrackGA(final BusEvent.trackGAEvent event) {
        if (event.isCategoryFragment) {
            trackEventScreenView(GoogleAnalytics.CATEGORIAS);
        }
    }

    public void setBusResult(){
        BusEvent.trackGAEvent trackGAEvent = new BusEvent.trackGAEvent();
        trackGAEvent.isCategoryFragment = postInfo != null;
        postBus(trackGAEvent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterBus(this);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        setBusResult();
    }
}
