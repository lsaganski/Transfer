package br.livetouch.livecom.itaubba.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import br.livetouch.fragment.BaseFragment;
import br.livetouch.lib.viewpagerindicator.CirclePageIndicator;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.activity.HomeActivity;
import br.livetouch.livecom.itaubba.adapter.TutorialPagerAdapter;

/**
 * Created by empresa on 18/07/2017.
 */

public class TutorialFragment extends BaseFragment {

    private callback callback;
    private ViewPager viewPager;
    private int pagePosition = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_tutorial, container, false);

        setUpViewPager(view);

        setOnClickListener(view, R.id.btnSair, onclickSair());
        setOnClickListener(view, R.id.tAnterior, onclickAnterior());
        setOnClickListener(view, R.id.tProximo, onclickProximo());

        showView(view, R.id.tAnterior);
        showView(view, R.id.indicator);

        return view;
    }

    private void setUpViewPager(View view) {
        viewPager = view.findViewById(R.id.viewPager);
        viewPager.setOffscreenPageLimit(TutorialPagerAdapter.getMaxItens());
        viewPager.setAdapter(new TutorialPagerAdapter(getContext()));
        viewPager.addOnPageChangeListener(onPageChangeListener());
        CirclePageIndicator indicator = view.findViewById(R.id.indicator);
        indicator.setViewPager(viewPager);
    }

    private ViewPager.OnPageChangeListener onPageChangeListener() {
        return new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (position == 0){
                    hideView(R.id.tAnterior);
                } else {
                    showView(R.id.tAnterior);
                }
            }

            @Override
            public void onPageSelected(int position) {
                pagePosition = position;
                if(position == TutorialPagerAdapter.getMaxItens() -1){
                    goneView(R.id.btnSair);
                    setText(R.id.tProximo, R.string.concluir_tutorial);
                }
                else{
                    showView(R.id.btnSair);
                    setText(R.id.tProximo, R.string.proximo);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {}
        };
    }

    private View.OnClickListener onclickProximo() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pagePosition == TutorialPagerAdapter.getMaxItens() -1){
                    if (callback != null){
                        callback.onClickCloseTutorial();
                    }
                } else {
                    viewPager.setCurrentItem(pagePosition +1);
                }

            }
        };
    }

    private View.OnClickListener onclickAnterior() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pagePosition != 0){
                    viewPager.setCurrentItem(pagePosition -1);
                }
            }
        };
    }

    private View.OnClickListener onclickSair() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (callback != null){
                    callback.onClickCloseTutorial();
                }
            }
        };
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            HomeActivity homeActivity = (HomeActivity) activity;
            callback =  homeActivity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString());
        }
    }

    public interface callback {
        void onClickCloseTutorial();
    }

}
