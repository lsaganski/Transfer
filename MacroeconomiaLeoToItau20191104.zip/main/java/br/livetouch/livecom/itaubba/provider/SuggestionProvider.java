package br.livetouch.livecom.itaubba.provider;

import android.content.SearchRecentSuggestionsProvider;

import br.livetouch.livecom.itaubba.BuildConfig;

;

/*
 * Created by empresa on 19/09/2017.
 */

public class SuggestionProvider extends SearchRecentSuggestionsProvider {

    public final static String AUTHORITY = BuildConfig.APPLICATION_ID + ".provider.SuggestionProvider";
    public final static int MODE = DATABASE_MODE_QUERIES;

    public SuggestionProvider() {
        setupSuggestions(AUTHORITY, MODE);
    }
}
