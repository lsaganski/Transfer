package br.livetouch.livecom.itaubba;

import android.content.Context;

import java.util.List;

import br.livetouch.livecom.Config;
import br.livetouch.livecom.activity.MainActivity;
import br.livetouch.livecom.domain.Post;
import br.livetouch.livecom.fragment.LivecomFragment;
import br.livetouch.livecom.menu.MenuVO;
import br.livetouch.livecom.tutorial.Tutorial;
import br.livetouch.utils.StringUtils;

/**
 * Created by empresa on 18/07/2017.
 */

public class ItaubbaConfig implements Config{

    @Override
    public String getUrlServer() {
        return BuildConfig.SERVER_URL;
    }

    @Override
    public String getPostTitle(Context context, Post post) {
        return null;
    }

    @Override
    public String getServerIP() {
        return null;
    }

    @Override
    public int getChatPort() {
        return 0;
    }

    @Override
    public List<MenuVO> createMenu(Context context) {
        return null;
    }

    @Override
    public LivecomFragment onClickMenu(MainActivity mainActivity, MenuVO menuVO) {
        return null;
    }

    @Override
    public Tutorial getTutorial() {
        return null;
    }

    @Override
    public int iconePadrao() {
        return 0;
    }
}
