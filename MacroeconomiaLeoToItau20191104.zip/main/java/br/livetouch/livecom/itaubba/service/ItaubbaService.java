package br.livetouch.livecom.itaubba.service;

import android.content.Context;
import android.net.Uri;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.livetouch.cript.CryptUtil;
import br.livetouch.db.SqlUtils;
import br.livetouch.exception.DomainException;
import br.livetouch.http.HttpHelper;
import br.livetouch.livecom.domain.Arquivo;
import br.livetouch.livecom.domain.Destaque;
import br.livetouch.livecom.domain.User;
import br.livetouch.livecom.itaubba.ItaubbaAplication;
import br.livetouch.livecom.itaubba.ItaubbaDataBaseHelper;
import br.livetouch.livecom.itaubba.R;
import br.livetouch.livecom.itaubba.activity.BaseActivity;
import br.livetouch.livecom.itaubba.domain.Categoria;
import br.livetouch.livecom.itaubba.domain.Idioma;
import br.livetouch.livecom.itaubba.domain.Mural;
import br.livetouch.livecom.itaubba.domain.Post;
import br.livetouch.livecom.itaubba.domain.PostInfo;
import br.livetouch.livecom.itaubba.domain.service.JSONResponse;
import br.livetouch.livecom.itaubba.utils.LocaleUtils;
import br.livetouch.livecom.itaubba.utils.PrefsUtil;
import br.livetouch.livecom.menu.MenuVO;
import br.livetouch.livecom.utils.FileUtils;
import br.livetouch.token.TokenHelper;
import br.livetouch.token.TokenSecret;
import br.livetouch.utils.AssetsUtils;
import br.livetouch.utils.ListUtils;
import br.livetouch.utils.LogUtil;
import br.livetouch.utils.NumberUtils;
import br.livetouch.utils.StringUtils;

/*
 * Created by empresa on 18/07/2017.
 */

public class ItaubbaService {
    private static final int WS_VERSION = 3;
    private static String URL_SERVER;
    private static final String SHORTNER_API = "https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAkRu-R6TUDRBjqE4UgbjEHZ6MSYF0tmsY";

    static {
        init();
    }

    private static void init() {

        URL_SERVER = ItaubbaAplication.getInstance().getConfig().getUrlServer();
        initDBLists();

        LogUtil.log("URL_SERVER: " + URL_SERVER);
    }

    private static HttpHelper getHttpHelper() throws DomainException {
        return getHttpHelper(120000);
    }

    private static HttpHelper getHttpHelper(int timeout) throws DomainException {
        HttpHelper http = new HttpHelper();
        http.setUserAgent("livecom-android");
        http.setConnectTimeout(timeout);
        http.setReadTimeout(timeout);
        return http;
    }

    private static String getWsToken() {
        User user = ItaubbaAplication.getInstance().getUser();
        if (user != null) {
            return user.wstoken;
        }
        return "";
    }

    private static Map<String, String> getHttpParams() {
        Map<String, String> params = new HashMap<>();
        params.put("idioma", LocaleUtils.getDefaultLanguage());
        params.put("form_name", "form");
        params.put("wsVersion", String.valueOf(WS_VERSION));
        params.put("mode", "json");

        String buildName = ItaubbaAplication.getInstance().getBuildType();
        params.put("buildType", buildName);

        User user = ItaubbaAplication.getInstance().getUser();
        if (user != null && user.id != null) {
            String usuarioId = user.id.toString();
            params.put("user_id", usuarioId);
            params.put("user_logado_id", usuarioId);
            params.put("timestampLogin", user.timestampLogin);
            params.put("wstoken", user.wstoken);
            params.put("wsotp", generateOtp());
        } else {
            String userId = String.valueOf(User.getUserId());
            if (StringUtils.isNotEmpty(userId)) {
                params.put("user_logado_id", userId);
            }
        }
        return params;
    }

    private static String generateOtp() {
        String wsToken = getWsToken();
        if(StringUtils.isEmpty(wsToken)) {
            return null;
        }
        String secret = TokenSecret.create(wsToken);
        long time = System.currentTimeMillis();
        return TokenHelper.generateTimeToken(secret, time, 30);
    }

    private static void initDBLists() {
        ItaubbaDataBaseHelper databaseHelper = (ItaubbaDataBaseHelper) ItaubbaAplication.getInstance().getDatabaseHelper();

        List<String[]> postFavorito = SqlUtils.queryList("select ID from POST where isfavorito = 1");
        databaseHelper.postFavoritosIds = new ArrayList<>();
        for (String[] v : postFavorito) {
            Long id = NumberUtils.toLong(v[0]);
            databaseHelper.postFavoritosIds.add(id);
        }

        List<String[]> postLido = SqlUtils.queryList("select ID from POST where lido = 1");
        databaseHelper.postLidosIds = new ArrayList<>();
        for (String[] v : postLido) {
            Long id = NumberUtils.toLong(v[0]);
            databaseHelper.postLidosIds.add(id);
        }
    }

    public static User login(Context context) throws DomainException, IOException {
        Map<String, String> params = getHttpParams();
        HttpHelper http = getHttpHelper();
        http.doPost(URL_SERVER + "/ws/login.htm", params);
        String json = http.getString();

        JSONResponse response = JSONResponse.create(json);

        if (response == null || response.user == null){
            throw new DomainException(context.getString(R.string.servidor_nao_respodeu_verifique_conexao));
        }

        ItaubbaAplication.getInstance().setUserLogado(response.user);

        return response.user;
    }

    public static List<MenuVO> getMenuMais(Context context) {
        List<MenuVO> menuVOList = new ArrayList<>();

        menuVOList.add(new MenuVO(context.getString(R.string.categorias_de_interese), R.drawable.icn_categorias_interesse));
        menuVOList.add(new MenuVO(context.getString(R.string.sobre_a_equipe), R.drawable.icn_sobre_equipe));
        menuVOList.add(new MenuVO(context.getString(R.string.sobre_o_aplicativo), R.drawable.icn_sobre_app));
        menuVOList.add(new MenuVO(context.getString(R.string.termos_de_uso), R.drawable.icn_termos_de_uso));
        menuVOList.add(new MenuVO(context.getString(R.string.tutorial), R.drawable.icn_tutorial));
        menuVOList.add(new MenuVO(context.getString(R.string.configuracoes), R.drawable.icn_configuracoes));

        return menuVOList;
    }

    public static List<Categoria> getCategorias(Context context) throws Exception {
        return getCategorias(context, false, false);
    }

    public static List<Categoria> getCategorias(Context context, boolean filtroInteresse, boolean isMenuHome) throws Exception {
        List<Categoria> categorias;
        Map<String, String> params = new HashMap<>();

        String json = post("/ws/categorias.htm", params);
        JSONResponse response = JSONResponse.create(json);
        categorias = response.categorias;

        // retorna categorias de interesse
        if (filtroInteresse) {
            categorias = PrefsUtil.getCategoriasInteresse(categorias);
        }

        if (isMenuHome) {
            categorias.add(0, new Categoria(context.getString(R.string.todas)));
        }

        return categorias;
    }

    public static List<Idioma> getIdiomas(Context context) {

        List<Idioma> idiomas = new ArrayList<>();

        Idioma pt = new Idioma();
        pt.nome = context.getString(R.string.portugues);
        pt.id = 1L;
        pt.code = "pt-br";

        Idioma en = new Idioma();
        en.nome = context.getString(R.string.ingles);
        en.id = 2L;
        en.code = "en-us";

//        Idioma es = new Idioma();
//        es.nome = getContext().getString(R.string.espanhol);
//        es.id = 3L;
//        es.code = "es-es";

        idiomas.add(pt);
        idiomas.add(en);
        //idiomas.add(es);

        return idiomas;
    }

    public static String getUrlTermosDeUso() throws DomainException, IOException, JSONException {
        String pathWs = String.format("/rest/v1/parametro/mobile/bba/termos/%s", getWsLanguage());
        return getUrlFromWs(pathWs);
    }

    public static String getUrlSobre() throws JSONException, IOException, DomainException {
        String pathWs = String.format("/rest/v1/parametro/mobile/bba/sobre/%s", getWsLanguage());
        return getUrlFromWs(pathWs);
    }

    private static String getUrlFromWs(String pathWs) throws DomainException, IOException, JSONException {
        HttpHelper httpHelper = getHttpHelper();
        httpHelper.doGet(URL_SERVER + pathWs);

        String json = httpHelper.getString();
        JSONObject object = new JSONObject(json);
        return object.getString("url");
    }

    private static String getWsLanguage() {
        String defaultLanguage = LocaleUtils.getDefaultLanguage();
        if (StringUtils.isEmpty(defaultLanguage))
            return "pt";
        return defaultLanguage.contains("en") || defaultLanguage.contains("us") ? "en" : "pt";
    }

    public static synchronized Post getPost(Context context, PostInfo postInfo, String postId) throws Exception {
        if (postInfo != null && postInfo.isMenuFavorito()){
            return getPostFavorito(context, postId);
        } else {
            return getPost(context, postId);
        }
    }

    private static Post getPostFavorito(Context context, String postId) throws DomainException {
        try {
            Post post = SqlUtils.find(Post.class, "id = ?", postId);
            fillPostFromDB(post);
            return post;
        } catch (Exception e) {
            throw new DomainException(context.getString(R.string.erro_ao_carregar_post));
        }
    }

    private static synchronized Post getPost(Context context, String postId) throws Exception {
        Map<String, String> params = getHttpParams();
        params.put("id", postId);
        params.put("audiencia", "1");

        String json = post("/ws/post.htm", params);
        JSONResponse response = JSONResponse.create(json);

        Post post = response.post;
        if (post == null) {
            post = response.result;
        }

        if (post != null) {

            post.gerarDadosLocais();
            post.isfavorito = isFavorito(post.id);
            post.lido = isLido(post.id);

            return post;
        } else {
            throw new DomainException(context.getString(R.string.erro_ao_carregar_post));
        }
    }

    /**
     * Posts
     */
    public static Mural getPosts(PostInfo postInfo) throws Exception {
        return getPosts(postInfo, 0);
    }

    public static Mural getPosts(PostInfo postInfo, int page) throws Exception {
        if (postInfo != null) {
            if (postInfo.isMenuFavorito()) {
                return getPostsFavoritos(postInfo, page);
            } else {
                return getPosts(postInfo, null, page);
            }
        }
        return null;
    }

    private static synchronized Mural getPosts(PostInfo postInfo, String query, int page) throws Exception {

        final Mural mural = new Mural();

        int maxItens = postInfo.getMaxRows() > 0 ? postInfo.getMaxRows() : PostInfo.PAGE_SIZE;

        Map<String, String> params = new HashMap<>();

        if (StringUtils.isNotEmpty(postInfo.getQuery())) {
            params.put("texto", postInfo.getQuery());
        }

        Categoria categoria = postInfo.getCategoria();
        if (categoria != null) {
            if (StringUtils.isNotEmpty(categoria.codigo)) {
                params.put("categoria_id", categoria.codigo);
            } else if (categoria.id != null) {
                params.put("categoria_id", categoria.id.toString());
            }
        }

        if (postInfo.getSubCategoria() != null) {
            if (postInfo.getSubCategoria().id != null) {
                params.put("categoria_id", postInfo.getSubCategoria().id.toString());
            } else if (postInfo.getSubCategoria().categoriaPai != null){
                params.put("categoria_id", postInfo.getSubCategoria().categoriaPai.id.toString());
            }
        }

        if (postInfo.isDestaque()) {
            params.put("destaque", "1");
            params.put("maxRows", String.valueOf(3));
        } else {
//            params.put("destaque", "2");
            params.put("maxRows", String.valueOf(maxItens));
        }

        params.put("buscaPosts", "1");

        if (page > 0) {
            params.put("page", String.valueOf(page));
        }

        if (postInfo.getExcludePostId() != null) {
            params.put("exclude_post_id", String.valueOf(postInfo.getExcludePostId()));
        }

        String json = post("/ws/mural.htm", params);
        JSONResponse response = JSONResponse.create(json);

        mural.badges = response.badges;
        List<Post> posts = response.posts;

        if (ListUtils.isNotEmpty(posts)) {
            for (Post post : posts) {
                if (post != null) {
                    post.gerarDadosLocais();
                    post.isfavorito = isFavorito(post.id);
                    post.lido = isLido(post.id);
                    mural.posts.add(post);
                }
            }
        }

        return mural;
    }

    private static boolean isFavorito(Long id) throws DomainException, IOException {
        ItaubbaDataBaseHelper databaseHelper = (ItaubbaDataBaseHelper) ItaubbaAplication.getInstance().getDatabaseHelper();
        return ListUtils.isNotEmpty(databaseHelper.postFavoritosIds) && databaseHelper.postFavoritosIds.contains(id);
    }

    private static boolean isLido(Long id) throws DomainException, IOException {
        ItaubbaDataBaseHelper databaseHelper = (ItaubbaDataBaseHelper) ItaubbaAplication.getInstance().getDatabaseHelper();
        return ListUtils.isNotEmpty(databaseHelper.postLidosIds) && databaseHelper.postLidosIds.contains(id);
    }

    private static Mural getPostsFavoritos(PostInfo postInfo, int page) {
        return getPostsFavoritos(page, postInfo.getQuery());
    }

    private static Mural getPostsFavoritos(int page, String query) {
        boolean search = StringUtils.isNotEmpty(query);
        final Mural mural = new Mural();
        List<Post> postList;

        // Busca no banco de dados
        if (search) {
            postList = SqlUtils.query(Post.class, "select * from POST where TITULO like '%" + query + "%'");
        } else {
            String limit = SqlUtils.getSqlLimit(page, PostInfo.PAGE_SIZE);
//            postList = SqlUtils.findAll(Post.class, "ISFAVORITO = '1'", null, null, "current_timestamp DESC", limit);
            postList = SqlUtils.query(Post.class, "select * from Post p where p.isfavorito = 1 ORDER BY p.current_timestamp DESC LIMIT " + limit);
        }

        if (ListUtils.isNotEmpty(postList)) {
            for (Post p : postList) {
                fillPostFromDB(p);
                mural.posts.add(p);
            }
        }

        return mural;
    }

    private static void fillPostFromDB(Post p) {
        // Busco Categoria do post
        findcategoriaFromDB(p);

        // Busco Categoria Pai da categoria
        findCategoriapaiFromDB(p.categoria);

        // Busco Arquivos do post
        findArquivosFromDB(p);

        // Busco Destaque do post
        findDestaqueFromDB(p);
    }

    private static void findArquivosFromDB(Post p) {
        try {
            final List<Arquivo> arquivos = SqlUtils.query(Arquivo.class, "select * from Arquivo where id_post = ?", p.id);
            if (ListUtils.isNotEmpty(arquivos)) {
                p.arquivos = arquivos;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void findDestaqueFromDB(Post p) {
        try {
            List<Destaque> destaques = SqlUtils.query(Destaque.class, "select * from Destaque where id_post = ?", p.id);
            if (ListUtils.isNotEmpty(destaques)) {
                p.destaque = destaques.get(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void findcategoriaFromDB(Post p) {
        try {
            p.categoria = SqlUtils.find(Categoria.class, "id = ?", p.idCategoria);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void findCategoriapaiFromDB(Categoria categoria) {
        if (categoria == null || categoria.idPai == null || categoria.idPai == 0){
            return;
        }
        try {
            Categoria categoriaPai = SqlUtils.find(Categoria.class, "id = ?", categoria.idPai);
            if (categoriaPai != null){
                categoria.categoriaPai = categoriaPai;
                findCategoriapaiFromDB(categoriaPai);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void savePostFavorito(Post post) throws DomainException, IOException {
        ItaubbaDataBaseHelper databaseHelper = (ItaubbaDataBaseHelper) ItaubbaAplication.getInstance().getDatabaseHelper();
        boolean isFavorito = isFavorito(post.id);

        // se post é favorito então "desfavorito" e deleto da base.
        if (isFavorito) {
            post.isfavorito = false;
            // Deleta apenas se não foi visto
            if(!post.lido) {
                deletePostFavorito(post);
            }
            else{
                // Atualiza post como visualizado porém não favoritado
                savePost(post);
            }
            databaseHelper.postFavoritosIds.remove(post.id);
        } else {
            post.isfavorito = true;
            post.currentTimestamp = System.currentTimeMillis() / 1000;
            savePost(post);
            databaseHelper.postFavoritosIds.add(post.id);
        }
    }

    public static void savePostLido(Post post) {
        ItaubbaDataBaseHelper databaseHelper = (ItaubbaDataBaseHelper) ItaubbaAplication.getInstance().getDatabaseHelper();
        if(post!=null){
            post.lido = true;
            savePost(post);
            databaseHelper.postLidosIds.add(post.id);
        }

    }

    private static void deletePostFavorito(Post post) {
        SqlUtils.delete(Post.class, post.id);
        SqlUtils.execSQL("delete from ARQUIVO where ID_POST = " + post.id);
    }

    private static void savePost(Post post) {
        saveCategoriaPost(post);
        saveArquivoPost(post);
        saveDestaquePost(post);

        // save post
        SqlUtils.saveInTx(post);
    }

    private static void saveCategoriaPost(Post post) {
        if (post.categoria == null) {
            return;
        }

        // salva categorai do post
        Categoria categoria = post.categoria;
        post.idCategoria = categoria.id;
        SqlUtils.saveInTx(categoria);

        // salva categorai pai da categoria
        saveCategoriaPai(categoria, categoria.categoriaPai);
    }

    private static void saveCategoriaPai(Categoria categoria, Categoria categoriaPai) {
        if (categoriaPai == null) {
            return;
        }
        categoria.idPai = categoriaPai.id;
        SqlUtils.saveInTx(categoria);
        SqlUtils.saveInTx(categoriaPai);
        saveCategoriaPai(categoriaPai, categoriaPai.categoriaPai);
    }

    private static void saveArquivoPost(Post post) {
        List<Arquivo> arquivos = post.arquivos;
        if (ListUtils.isNotEmpty(arquivos)) {
            for (Arquivo a : arquivos) {
                a.idPost = post.id;
//                fetchArquivo(a);
            }
            SqlUtils.saveInTx(arquivos);
        }
    }

    private static void saveDestaquePost(Post post) {
        Destaque destaque = post.destaque;
        if (destaque != null) {
            destaque.idPost = post.id;
            SqlUtils.saveInTx(destaque);
        }
    }

//    private static void fetchArquivo(Arquivo a) {
//        try {
//            String fileName = a.getNomeArquivo();
//            File file = AndroidUtils.getContext().getDir(fileName, Context.MODE_PRIVATE);
//            LogUtil.logError(">> : " + file.getPath());
//            if (!file.exists()) {
//                File download = DownloadUtils.download(AndroidUtils.getContext(), a.url, file, 60000);
//                a.filePath = download.getAbsolutePath();
//            } else {
//                a.filePath = file.getPath();
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    public static Uri getArquivoUri(Context context, Arquivo arquivo) throws DomainException {
        try {
            if (StringUtils.isNotEmpty(arquivo.url)){
                String ALLOWED_URI_CHARS = "@#&=*+-_.,:!?()/~'%";
                String arquivoUrl = Uri.encode(arquivo.url, ALLOWED_URI_CHARS);
                return Uri.parse(arquivoUrl);
            } else if (StringUtils.isNotEmpty(arquivo.filePath)){
                File file = new File(arquivo.filePath);
                if (FileUtils.exists(file)) {
                    return Uri.parse(file.getAbsolutePath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        throw new DomainException(context.getString(R.string.msg_erro_consulta));
    }

    public static String post(String pathWs, Map<String, String> params) throws DomainException, IOException {
        HttpHelper http = getHttpHelper();
        params.putAll(getHttpParams());

        http.doPost(URL_SERVER + pathWs, params);

        String json = http.getString();
        String ws_crypt_on = http.getHeader("WS_CRYPT_ON");
        boolean crypt = "1".equals(ws_crypt_on);
        if(crypt) {
            String key = getWsToken();
            json = CryptUtil.decryptAES(key, json);
            if(json == null) {
                throw new DomainException("Ocorreu um erro na critografia da mensagem");
            }
        }

        return json;
    }

    public static String getHtmlFromAssets(BaseActivity baseActivity, String filename) throws IOException {
        String defaultLanguage = LocaleUtils.getDefaultLanguage();
        try {
            return AssetsUtils.getFileString(baseActivity, defaultLanguage + "/" + filename, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return AssetsUtils.getFileString(baseActivity, "pt-br/" + filename, "UTF-8");
    }

    public static String getUrlShortner(String longUrl) throws DomainException, JSONException, IOException {
        HttpHelper http = getHttpHelper();
        http.setAddDefaultHttpParams(false);
        http.setContentType("application/json");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("longUrl", longUrl);
        http.doPost(SHORTNER_API, jsonObject.toString(), "utf-8");
        String response = http.getString();
        if (response != null) {
            JSONObject object = new JSONObject(response);
            String id = object.optString("id");
            String shortUrl = StringUtils.isNotEmpty(id) ? id : longUrl;
            return shortUrl;
        }
        return longUrl;
    }

    public static String getExpandUrlShortner(String shortUrl) throws DomainException, JSONException, IOException {
        HttpHelper http = getHttpHelper();
        http.setAddDefaultHttpParams(false);
        String urlApi = SHORTNER_API + "&shortUrl=%1s";
        http.doGet(String.format(urlApi, shortUrl));
        String response = http.getString();
        if (response != null) {
            JSONObject object = new JSONObject(response);
            return object.optString("longUrl");
        }

        return shortUrl;
    }
}
